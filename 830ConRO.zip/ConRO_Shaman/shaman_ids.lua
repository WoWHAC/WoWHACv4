local ConRO_Shaman, ids = ...;

--Generic
	ids.Racial = {
		Berserking = 26297,
		GiftoftheNaaru = 59548,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.Shaman_AzTrait = {

	}
	ids.Shaman_AzTraitBuff = {

	}
	ids.AzEssence = {
		ConcentratedFlame = 295373,
		MemoryofLucidDream = 298357,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}
	
--Elemental
	ids.Ele_Ability = {
		AncestralSpirit = 2008,
		AstralRecall = 556,
		AstralShift = 108271,
		CapacitorTotem = 192058,
		ChainLightning = 188443,
		CleanseSpirit = 51886,
		EarthElemental = 198103,
		EarthShock = 8042,
		EarthbindTotem = 2484,
		Earthquake = 61882,
		FarSight = 6196,
		FireElemental = 198067,
		FlameShock = 188389,
		FrostShock = 196840,
		GhostWolf = 2645,
		HealingSurge = 8004,
		Heroism = 32182,
		Hex = 51514,
		HaxRaptor = 210873,
		LavaBurst = 51505,
		LightningBolt = 188196,
		Purge = 370,
		Thunderstorm = 51490,
		TremorTotem = 8143,
		WaterWalking = 546,
		WindShear = 57994,
	}
	ids.Ele_Passive = {
		ElementalFury = 60188,
		LavaSurge = 77756,
		MasteryElementalOverload = 168534,
		Reincarnation = 20608,
	}
	ids.Ele_Talent = {
		--15
		EarthRage = 170374,
		EchooftheElements = 108283,
		ElementalBlast = 117014,
		--30
		Aftershock = 273221,
		CalltheThunder = 260897,
		TotemMastery = 210643,
		--45
		SpiritWolf = 260878,
		EarthShield = 974,
		StaticCharge = 265046,
		--60
		MasteroftheElements = 16166,
		StormElemental = 192249,
		LiquidMagmaTotem = 192222,
		--75
		NaturesGuardian = 30884,
		AncestralGuidance = 108281,
		WindRushTotem = 192077,
		--90
		SurgeofPower = 262303,
		PrimalElementalist = 117013,
		Icefury = 210714,
		--100
		UnlimitedPower = 260895,
		Stormkeeper = 191634,
		Ascendance = 114050,
			LavaBeam = 114074,
	}
	ids.Ele_Form = {
		TailwindTotem = 210659,
		WindGust = 263806,
	}
	ids.Ele_Buff = {
		Ascendance = 114050,
		EarthShield = 974,
		Icefury = 210714,
		LavaSurge = 77762,
		MasteroftheElements = 260734,
		Stormkeeper = 191634,
		SurgeofPower = 285514,
	}
	ids.Ele_Debuff = {
		FlameShock = 188389,
	}
	ids.Ele_PetAbility = {

	}
		
--Enhancement
	ids.Enh_Ability = {
		AncestralSpirit = 2008,
		AstralRecall = 556,
		AstralShift = 108271,
		CapacitorTotem = 192058,
		CleanseSpirit = 51886,
		CrashLightning = 187874,
		EarthElemental = 198103,
		EarthbindTotem = 2484,
		FarSight = 6196,
		FeralSpirit = 51533,
		Flametongue = 193796,
		Frostbrand = 196834,
		GhostWolf = 2645,
		HealingSurge = 188070,
		Heroism = 32182,
		Hex = 51514,
		HaxRaptor = 210873,
		LavaLash = 60103,
		LightningBolt = 187837,
		Purge = 370,
		Rockbiter = 193786,
		SpiritWalk = 58875,
		Stormstrike = 17364,
		TremorTotem = 8143,
		WaterWalking = 546,
		WindShear = 57994,
	}
	ids.Enh_Passive = {
		MaelstromWeapon = 187880,
		MasteryEnhancedElements = 77223,
		Reincarnation = 20608,
		Stormbringer = 201845,
		Windfury = 33757,
	}
	ids.Enh_Talent = {
		--15
		Boulderfist = 246035,
		HotHand = 201900,
		LightningShield = 192106,
		--30
		Landslide = 197992,
		ForcefulWinds = 262647,
		TotemMastery = 262395,
		--45
		SpiritWolf = 260878,
		EarthShield = 974,
		StaticCharge = 265046,
		--60
		SearingAssault = 192087,
		Hailstorm = 210853,
		Overcharge = 210727,
		--75
		NaturesGuardian = 30884,
		FeralLunge = 196884,
		WindRushTotem = 192077,
		--90
		CrashingStorm = 192246,
		FuryofAir = 197211,
		Sundering = 197214,
		--100
		ElementalSpirits = 262624,
		EarthenSpike = 188089,
		Ascendance = 114051,
			Windstrike = 115356,
	}
	ids.Enh_Form = {
		FuryofAir = 197211,
		TailwindTotem = 262400,
	}
	ids.Enh_Buff = {
		Ascendance = 114051,
		CrashLightning = 187878,
		EarthShield = 974,
		Flametongue = 194084,
		Frostbrand = 196834,
		ForcefulWinds = 262652,
		GatheringStorms = 198300,
		Landslide = 202004,
		LightningShield = 192106,
		HotHand = 215785,
		Stormbringer = 201846,
	}
	ids.Enh_Debuff = {
		EarthenSpike = 188089,
		SearingAssault = 268429,
	}
	ids.Enh_PetAbility = {

	}

--Restoration
	ids.Resto_Ability = {
		AncestralSpirit = 2008,
		AncestralVision = 212048,
		AstralRecall = 556,
		AstralShift = 108271,
		CapacitorTotem = 192058,
		ChainHeal = 1064,
		ChainLightning = 421,
		EarthElemental = 198103,
		EarthbindTotem = 2484,
		FarSight = 6196,
		FlameShock = 188838,
		GhostWolf = 2645,
		HealingRain = 73920,
		HealingStreamTotem = 5394,
		HealingSurge = 8004,
		HealingTideTotem = 108280,
		HealingWave = 77472,
		Heroism = 32182,
		Hex = 51514,
		HaxRaptor = 210873,
		LavaBurst = 51505,
		LightningBolt = 403,
		Purge = 370,
		PurifySpirit = 77130,
		Riptide = 61295,
		SpiritLinkTotem = 98008,
		SpiritwalkersGrace = 79206,
		TremorTotem = 8143,
		WaterWalking = 546,
		WindShear = 57994,
	}
	ids.Resto_Passive = {
		LavaSurge = 77756,
		MasteryDeepHealing = 77226,
		Reincarnation = 20608,
		Resurgence = 16196,
		TidalWaves = 51564,
	}
	ids.Resto_Talent = {
		--15
		Torrent = 200072,
		Undulation = 200071,
		UnleashLife = 73685,
		--30
		EchooftheElements = 108283,
		Deluge = 200076,
		EarthShield = 974,
		--45
		SpiritWolf = 260878,
		EarthgrabTotem = 51485,
		StaticCharge = 265046,
		--60
		AncestralVigor = 207401,
		EarthenWallTotem = 198838,
		AncestralProtectionTotem = 207399,
		--75
		NaturesGuardian = 30884,
		GracefulSpirit = 192088,
		WindRushTotem = 192077,
		--90
		FlashFlood = 280614,
		Downpour = 207778,
		CloudburstTotem = 157153,
		--100
		HighTIde = 157154,
		Wellspring = 197995,
		Ascendance = 114052,
	}
	ids.Resto_Form = {
	
	}
	ids.Resto_Buff = {
		EarthShield = 974,
		LavaSurge = 77762,
 	}
	ids.Resto_Debuff = {
		FlameShock = 188838,
	}
	ids.Resto_PetAbility = {

	}