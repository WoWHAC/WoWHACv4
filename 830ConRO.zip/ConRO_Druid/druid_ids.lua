local ConRO_Druid, ids = ...;

--Generic
	ids.Racial = {
		Berserking = 26297,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.Druid_AzTrait = {
		ArcanicPulsar = 287773,
		IronJaws = 276021,
		GuardiansWrath = 278511,
		StreakingStars = 272871,
		WildFleshrending = 279527,
	}
	ids.Druid_AzTraitBuff = {
		IronJaws = 276026,
		GuardiansWrath = 279541,
	}
	ids.Druid_AzTraitDebuff = {
		ConcentratedFlame = 295368,
	}	
	ids.AzEssence = {
		BloodoftheEnemy = 298273,
		ConcentratedFlame = 295373,
		GuardianofAzeroth = 299358,
		MemoryofLucidDream = 298357,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}
	ids.AzEssenceBuff = {
		MemoryofLucidDream = 298357,	
	}
	
--Balance
	ids.Bal_Ability = {
		Barkskin = 22812,
		BearForm = 5487,
		CatForm = 768,
		CelestialAlignment = 194223,
		Dash = 1850,
		Dreamwalk = 193753,
		EntanglingRoots = 339,
		Growl = 6795,
		Hibernate = 2637,
		Innervate = 29166,
		LunarStrike = 194153,
		Mangle = 33917,
		Moonfire = 8921,
		MoonkinForm = 24858,
		Prowl = 5215,
		Rebirth = 20484,
		Regrowth = 8936,
		RemoveCorruption = 2782,
		Revive = 50769,
		Shred = 5221,
		SolarBeam = 78675,
		SolarWrath = 190984,
		Soothe = 2908,
		Starfall = 191034,
		Starsurge = 78674,
		Sunfire = 93402,
		TravelForm = 783,
	}
	ids.Bal_Passive = {
		AquaticForm = 276012,
		AstralInfluence = 197524,
		Eclipse = 279619,
		Empowerments = 279708,
		FlightForm = 276029,
		MasteryStarlight = 77492,		
	}
	ids.Bal_Talent = {
		--15
		NaturesBalance = 202430,
		WarriorofElune = 202425,
		ForceofNature = 205636,
		--30
		TigerDash = 252216,
		Renewal = 108238,
		WildCharge = 102401,
			WildCharge_Bear = 16979,
			WildCharge_Cat = 49376,
			WildCharge_Moonkin = 102383,
		--45
		FeralAffinity = 202157,
			FerociousBite = 22568,
			Rake = 1822,
			Rip = 1079,
			Swipe = 213764,
		GuardianAffinity = 197491,
			FrenziedRegeneration = 22842,
			Ironfur = 192081,
			ThickHide = 16931,	
		RestorationAffinity = 197492,
			Rejuenation = 774,
			Swiftmend = 18562,
			WildGrowth = 48438,
			YserasGift = 145108,
		--60
		MightyBash = 5211,
		MassEntanglement = 102359,
		Typhoon = 132469,
		--75
		SouloftheForest = 114107,
		Starlord = 202345,
		IncarnationChosenofElune = 102560,
		--90
		StellarDrift = 202354,
		TwinMoons = 279620,
		StellarFlare = 202347,
		--100
		ShootingStars = 202342,
		FuryofElune = 202770,
		NewMoon = 274281,
			HalfMoon = 274282,
			FullMoon = 274283,
	}
	ids.Bal_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		CelestialGuardian = 233754,
		CrescentBurn = 200567,
		CelestialDownpour = 200726,
		MoonandStars = 233750,
		MoonkinAura = 209740,
		DyingStars = 232546,
		DeepRoots = 233755,
		FaerieSwarm = 209749,
		Cyclone = 209753,
		PricklingThorns = 200549,
		Thorns = 236696,
		IronfeatherArmor = 233752,
		ProtectoroftheGrove = 209730,
	}
	ids.Bal_Form = {
		MoonkinForm = 24858,
		WarriorofElune = 202425,
	}
	ids.Bal_Buff = {
		CelestialAlignment = 194223,
		IncarnationChosenofElune = 102560,
		LunarEmpowerment = 164547,
		OwlkinFrenzy = 157228,
		SolarEmpowerment = 164545,
		Starfall = 191034,
		Starlord = 279709,
		StellarDrift = 202461,
	}
	ids.Bal_Debuff = {
		Moonfire = 164812,
		Sunfire = 164815,
		StellarFlare = 202347,
	}
	ids.Bal_PetAbility = {

	}
		
--Feral
	ids.Feral_Ability = {
		BearForm = 5487,
		Berserk = 106951,
		CatForm = 768,
		Dash = 1850,
		Dreamwalk = 193753,
		EntanglingRoots = 339,
		FerociousBite = 22568,
		Growl = 6795,
		Hibernate = 2637,
		Maim = 22570,
		Mangle = 33917,
		Moonfire = 8921,
		Prowl = 5215,
		Rake = 1822,
		Rebirth = 20484,
		Regrowth = 8936,
		RemoveCorruption = 2782,
		Revive = 50769,
		Rip = 1079,
		Shred = 5221,
		SkullBash = 106839,
		Soothe = 2908,
		StampedingRoar = 77764,
		SurvivalInstincts = 61336,
		Swipe = 213764,		
		Swipe_Cat = 106785,
		Swipe_Bear = 213771,
		Thrash = 106832,
		Thrash_Cat = 106830,
		Thrash_Bear = 77758,
		TigersFury = 5217,
		TravelForm = 783,
	}
	ids.Feral_Passive = {
		AquaticForm = 276012,
		FelineSwiftness = 131768,
		FeralInstinct = 16949,
		FlightForm = 276029,
		InfectedWounds = 48484,
		MasteryRazorClaws = 77493,
		OmenofClarity = 16864,
		PredatorySwiftness = 16974,
		PrimalFury = 159286,
	}
	ids.Feral_Talent = {
		--15
		Predator = 202021,
		Sabertooth = 202031,
		LunarInspiration = 155580,
			Moonfire_Cat = 155625,
		--30
		TigerDash = 252216,
		Renewal = 108238,
		WildCharge = 102401,
			WildCharge_Bear = 16979,
			WildCharge_Cat = 49376,
			WildCharge_Moonkin = 102383,
		--45
		BalanceAffinity = 197488,
			AstralInfluence = 197524,
			LunarStrike = 197628,
			Starsurge = 197626,
			SolarWrath = 197629,
			Sunfire = 197630,
		GuardianAffinity = 217615,
			FrenziedRegeneration = 22842,
			Ironfur = 192081,
			ThickHide = 16931,	
		RestorationAffinity = 197492,
			Rejuenation = 774,
			Swiftmend = 18562,
			WildGrowth = 48438,
			YserasGift = 145108,		
		--60
		MightyBash = 5211,
		MassEntanglement = 102359,
		Typhoon = 132469,
		--75
		SouloftheForest = 158476,
		SavageRoar = 52610,
		IncarnationKingoftheJungle = 102543,
		--90
		ScentofBlood = 285564,
		BrutalSlash = 202028,
		PrimalWrath = 285381,
		--100
		MomentofClarity = 236068,
		Bloodtalons = 155672,
		FeralFrenzy = 274837,
	}
	ids.Feral_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		Thorns = 236696,
		EarthenGrasp = 236023,
		FreedomoftheHerd = 213200,
		MalornesSwiftness = 236012,
		KingoftheJungle = 203052,
		EnragedMaim = 236026,
		FerociousWound = 236020,
		FreshWound = 203224,
		RipandTear = 203242,
		SavageMomentum = 205673,
		ProtectoroftheGrove = 209730,
		ToothandClaw = 236019,
			EnragedMaul = 236716,		
	}
	ids.Feral_Form = {
		BearForm = 5487,
		CatForm = 768,
		Prowl = 5215,
	}
	ids.Feral_Buff = {
		ApexPredator = 252752,
		Berserk = 106951,
		Bloodtalons = 145152,
		Clearcasting = 135700,
		IncarnationKingoftheJungle = 102543,
		TigersFury = 5217,
		PredatorySwiftness = 69369,
		Regrowth = 8936,
		SavageRoar = 52610,
		ToothandClaw = 236440,
	}
	ids.Feral_Debuff = {
		Moonfire = 155625,
		Rake = 155722,
			RakeStun = 163505,
		Rip = 1079,
		Thrash_Cat = 106830,
		Thrash_Bear = 192090,
	}
	ids.Feral_PetAbility = {

	}

--Guardian
	ids.Guard_Ability = {
		Barkskin = 22812,
		BearForm = 5487,
		CatForm = 768,
		Dash = 1850,
		Dreamwalk = 193753,
		EntanglingRoots = 339,
		FrenziedRegeneration = 22842,
		Growl = 6795,
		IncapacitatingRoar = 99,
		Ironfur = 192081,
		Mangle = 33917,
		Maul = 6807,
		Moonfire = 8921,
		Prowl = 5215,
		Rebirth = 20484,
		Regrowth = 8936,
		RemoveCorruption = 2782,
		Revive = 50769,
		Shred = 5221,
		SkullBash = 106839,
		Soothe = 2908,
		StampedingRoar = 77761,
		SurvivalInstincts = 61336,
		Swipe = 213764,
		Swipe_Bear = 213771,
		Thrash = 106832,
		Thrash_Bear = 77758,
		TravelForm = 783,
	}
	ids.Guard_Passive = {
		AquaticForm = 276012,
		FlightForm = 276029,
		Gore = 210706,
		LightningReflexes = 231065,
		MasteryNaturesGuardian = 155783,
		ThickHide = 16931,
	}
	ids.Guard_Talent = {
		--15
		Brambles = 203953,
		BloodFrenzy = 203962,
		BristlingFur = 155835,
		--30
		TigerDash = 252216,
		UrsolsVortex = 102793,
		WildCharge = 102401,
			WildCharge_Bear = 16979,
			WildCharge_Cat = 49376,
			WildCharge_Moonkin = 102383,
		--45
		BalanceAffinity = 197488,
			AstralInfluence = 197524,
			LunarStrike = 197628,
			Starsurge = 197626,
			SolarWrath = 197629,
			Sunfire = 197630,
		FeralAffinity = 197490,
			FerociousBite = 22568,
			Rake = 1822,
			Rip = 1079,
			Swipe = 213764,
		RestorationAffinity = 197492,
			Rejuenation = 774,
			Swiftmend = 18562,
			WildGrowth = 48438,
			YserasGift = 145108,
		--60
		MightyBash = 5211,
		MassEntanglement = 102359,
		Typhoon = 132469,
		--75
		SouloftheForest = 158477,
		GalacticGuardian = 203964,
		IncarnationGuardianofUrsoc = 102558,
		--90
		Earthwarden = 203974,
		SurvivaloftheFittest = 203965,
		GuardianofElune = 155578,
		--100
		RendandTear = 204053,
		LunarBeam = 204066,
		Pulverize = 80313,
	}
	ids.Guard_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		MasterShapeshifter = 236144,
		Toughness = 201259,
		DenMother = 236180,
		DemoralizingRoar = 201664,
		ClanDefender = 213951,
		RagingFrenzy = 236153,
		SharpenedClaws = 202110,
		ChargingBash = 228431,
		EntanglingClaws = 202226,
		Overrun = 202246,
		ProtectorofthePack = 202043,
		AlphaChallenge = 207017,
		MalornesSwiftness = 236147,
		RoaringSpeed = 236148,
	}
	ids.Guard_Form = {
		BearForm = 5487,
	}
	ids.Guard_Buff = {
		Ironfur = 192081,
		IncarnationGuardianofUrsoc = 102558,
		Pulverize = 158792,
		GalacticGuardian = 213708,
	}
	ids.Guard_Debuff = {
		Thrash = 192090,
		Moonfire = 164812,
	}
	ids.Guard_PetAbility = {
	
	}
	
--Restoration
	ids.Resto_Ability = {
		Barkskin = 22812,
		BearForm = 5487,
		CatForm = 768,
		Dash = 1850,
		Dreamwalk = 193753,
		Efflorescence = 145205,
		EntanglingRoots = 339,
		Growl = 6795,
		Hibernate = 2637,
		Innervate = 29166,
		Ironbark = 102342,
		Lifebloom = 33763,
		Mangle = 33917,
		Moonfire = 8921,
		NaturesCure = 88423,
		Prowl = 5215,
		Rebirth = 20484,
		Regrowth = 8936,
		Rejuvenation = 774,
		Revitalize = 212040,
		Revive = 50769,
		Shred = 5221,
		SolarWrath = 5176,
		Soothe = 2908,
		Sunfire = 93402,
		Swiftmend = 18562,
		Tranquility = 740,
		TravelForm = 783,
		UrsolsVortex = 102793,
		WildGrowth = 48438,
	}
	ids.Resto_Passive = {
		AquaticForm = 276012,
		FlightForm = 276029,
		MasteryHarmony = 77495,
		OmenofClarity = 113043,
		YserasGift = 145108,
	}
	ids.Resto_Talent = {
		--15
		Abundance = 207383,
		Prosperity = 200383,
		CenarionWard = 102351,
		--30
		TigerDash = 252216,
		Renewal = 108238,
		WildCharge = 102401,
			WildChargeBear = 16979,
			WildChargeCat = 49376,
			WildChargeMoonkin = 102383,
		--45
		BalanceAffinity = 197488,
			AstralInfluence = 197524,
			LunarStrike = 197628,
			Starsurge = 197626,
			SolarWrath = 197629,
			Sunfire = 197630,
		FeralAffinity = 197490,
			FerociousBite = 22568,
			Rake = 1822,
			Rip = 1079,
			Swipe = 213764,
		GuardianAffinity = 217615,
			FrenziedRegeneration = 22842,
			Ironfur = 192081,
			ThickHide = 16931,	
		--60
		MightyBash = 5211,
		MassEntanglement = 102359,
		Typhoon = 132469,
		--75
		SouloftheForest = 158478,
		Cultivation = 200390,
		IncarnationTreeofLife = 33891,
		--90
		InnerPeace = 197073,
		Stonebark = 197061,
		SpringBlossoms = 207385,
		--100
		Photosynthesis = 274902,
		Germination = 155675,
		Flourish = 197721,
	}
	ids.Resto_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		
	}
	ids.Resto_Form = {

	}
	ids.Resto_Buff = {
		Lifebloom =	33763,
		Regrowth = 8936,
	}
	ids.Resto_Debuff = {

	}
	ids.Resto_PetAbility = {
	
	}