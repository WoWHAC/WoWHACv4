local ConRO_Warlock, ids = ...;

--Generic
	ids.Racial = {
		ArcaneTorrent = 28730,
		Berserking = 26297,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.Warlock_AzTrait = {
		BalefulInvocation = 287059,
		ExplosivePotential = 275395,
		InevitableDemise = 273521,
	}
	ids.Warlock_AzTraitBuff = {
		ExplosivePotential = 275398,
		ForbiddenKnowledge = 278738,
		InevitableDemise = 273525,
		ShadowsBite = 272944,
	}
	ids.AzEssence = {
		BloodoftheEnemy = 298273,
		ConcentratedFlame = 295373,
		FocusedAzeriteBeam =295258,		
		GuardianofAzeroth = 299358,
		MemoryofLucidDream = 298357,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}	
	
--Affliction
	ids.Aff_Ability = {
		Agony = 980,
		Banish = 710,
		CommandDemon = 119898,
			CauterizeMaster = 119905, --Imp
			Suffering = 119907, --Voidwalker
			Whiplash = 119909, --Succubus
			SpellLock = 119910, --Felhunter
			ShadowLock = 171140, --Doomguard
			MeteorStrike = 171152, --Infernal
		Corruption = 172,
		CreateHealthstone = 6201,
		CreateSoulwell = 29893,
		DemonicGateway = 111771,
		DrainLife = 234153,
		EnslaveDemon = 1098,
		EyeofKilrogg = 126,
		Fear = 5782,
		HealthFunnel = 755,
		RitualofSummoning = 698,
		SeedofCorruption = 27243,
		Shadowbolt = 232670,
		Shadowfury = 30283,
		Soulstone = 20707,
		SummonDarkglare = 205180,
		SummonDemon = 10,
			SummonImp = 688,
			SummonVoidwalker = 697,
			SummonFelhunter = 691,
			SummonSuccubus = 712,
		UnendingBreath = 5697,
		UnendingResolve = 104773,
		UnstableAffliction = 30108,
	}
	ids.Aff_Passive = {
		MasteryPotentAfflictions = 77215,
		SoulLeech = 108370,
		SoulShards = 246985,
	}
	ids.Aff_Talent = {
		--15
		Nightfall = 108558,
		DrainSoul = 198590,
		Deathbolt = 264106,
		--30
		WritheinAgony = 196102,
		AbsoluteCorruption = 196103,
		SiphonLife = 63106,
		--45
		DemonSkin = 219272,
		BurningRush = 111400,
		DarkPact = 108416,
		--60
		SowtheSeeds = 196226,
		PhantomSingularity = 205179,
		VileTaint = 278350,
		--75
		Darkfury = 264874,
		MortalCoil = 6789,
		DemonicCircle = 268358,
			DemonicCircleSummon = 48018,
			DemonicCircleTeleport = 48020,
		--90
		ShadowEmbrace = 32388,
		Haunt = 48181,
		GrimoireofSacrifice = 108503,
		--100
		SoulConduit = 215941,
		CreepingDeath = 264000,
		DarkSoulMisery = 113860,
	}
	ids.Aff_Form = {
	
	}
	ids.Aff_Buff = {
		BurningRush = 111400,
		DarkPact = 108416,
		GrimoireofSacrifice = 196099,
	}
	ids.Aff_Debuff = {
		Agony = 980,
		Corruption = 146739,
		DrainSoul = 198590,
		Haunt = 48181,
		PhantomSingularity = 205179,
		SeedofCorruption = 27243,		
		SiphonLife = 63106,
		ShadowEmbrace = 32390,
		UnstableAffliction1 = 233490,
		UnstableAffliction2 = 233496,
		UnstableAffliction3 = 233497,
		UnstableAffliction4 = 233498,
		UnstableAffliction5 = 233499,
	}
	ids.Aff_PetAbility = {
		CauterizeMaster = 119899, --Imp
		Suffering = 17735, --Voidwalker
		Whiplash = 6360, --Succubus
		SpellLock = 19647, --Felhunter
		DevourMagic = 19505, --Felhunter
		OpticalBlast = 115781, --Observer
		MeteorStrike = 171017, --Infernal	
		ThreateningPresence = 112042, -- Voidwalker
	}
		
--Demonology
	ids.Demo_Ability = {
		Banish = 710,
		CallDreadstalkers = 104316,
		CommandDemon = 119898,
			CauterizeMaster = 119905, --Imp
			Suffering = 119907, --Voidwalker
			Whiplash = 119909, --Succubus
			SpellLock = 119910, --Felhunter
			AxeToss = 119914, -- Felguard
			ShadowLock = 171140, --Doomguard
			MeteorStrike = 171152, --Infernal
		CreateHealthstone = 6201,
		CreateSoulwell = 29893,
		Demonbolt = 264178,
		DemonicGateway = 111771,
		DrainLife = 234153,
		EnslaveDemon = 1098,
		EyeofKilrogg = 126,
		Fear = 5782,
		HandofGuldan = 105174,
		HealthFunnel = 755,
		Implosion = 196277,
		RitualofSummoning = 698,
		ShadowBolt = 686,
		Shadowfury = 30283,
		Soulstone = 20707,
		SummonDemon = nil,
			SummonImp = 688,
			SummonVoidwalker = 697,
			SummonFelhunter = 691,
			SummonSuccubus = 712,
			SummonFelguard = 30146,
		SummonDemonicTyrant = 265187,
		UnendingBreath = 5697,
		UnendingResolve = 104773,
	}
	ids.Demo_Passive = {
		DemonicCore = 267102,
		MasteryMasterDemonologist = 77219,
		SoulLeech = 108370,
		SoulLink = 108415,
		SoulShards = 246985,
	}
	ids.Demo_Talent = {
		--15
		Dreadlash = 264078,
		DemonicStrength = 267171,
		BilescourgeBombers = 267211,
		--30
		DemonicCalling = 205145,
		PowerSiphon = 264130,
		Doom = 265412,
		--45
		DemonSkin = 219272,
		BurningRush = 111400,
		DarkPact = 108416,
		--60
		FromtheShadows = 267170,
		SoulStrike = 264057,
		SummonVilefiend = 264119,
		--75
		Darkfury = 264874,		
		MortalCoil = 6789,		
		DemonicCircle = 48018,
			DemonicCircleSummon = 48018,
			DemonicCircleTeleport = 48020,
		--90
		SoulConduit = 215941,
		InnerDemons = 267216,
		GrimoireFelguard = 111898,
		--100
		SacrificedSouls = 267214,
		DemonicConsumption = 267215,
		NetherPortal = 267217,
	}
	ids.Demo_Form = {
	
	}
	ids.Demo_Buff = {
		BurningRush = 111400,
		DarkPact = 108416,
		DemonicCalling = 205146,
		DemonicCore = 264173,
		NetherPortal = 267218,
	}
	ids.Demo_Debuff = {
		Doom = 265412,
	}
	ids.Demo_PetAbility = {
		CauterizeMaster = 119899, --Imp
		Suffering = 17735, --Voidwalker
		Whiplash = 6360, --Succubus
		SpellLock = 19647, --Felhunter
		DevourMagic = 19505, --Felhunter
		OpticalBlast = 115781, --Observer
		MeteorStrike = 171017, --Infernal	
		Felstorm = 89751, -- Felguard
		AxeToss = 89766,
	}
	
--Destruction
	ids.Dest_Ability = {
		Banish = 710,
		ChaosBolt = 116858,
		CommandDemon = 119898,
			CauterizeMaster = 119905, --Imp
			Suffering = 119907, --Voidwalker
			Whiplash = 119909, --Succubus
			SpellLock = 119910, --Felhunter
			ShadowLock = 171140, --Doomguard
			MeteorStrike = 171152, --Infernal
		Conflagrate = 17962,
		CreateHealthstone = 6201,
		CreateSoulwell = 29893,
		DemonicGateway = 111771,
		DrainLife = 234153,
		EnslaveDemon = 1098,
		EyeofKilrogg = 126,
		Fear = 5782,
		Havoc = 80240,
		HealthFunnel = 755,
		Immolate = 348,
		Incinerate = 29722,
		RainofFire = 5740,
		RitualofSummoning = 698,
		Shadowfury = 30283,
		Soulstone = 20707,
		SummonDemon = nil,
			SummonImp = 688,
			SummonVoidwalker = 697,
			SummonFelhunter = 691,
			SummonSuccubus = 712,
		SummonInfernal = 1122,
		UnendingBreath = 5697,
		UnendingResolve = 104773,
	}
	ids.Dest_Passive = {
		Backdraft = 196406,
		MasteryChaoticEnergies = 77220,
		SoulLeech = 108370,
		SoulShards = 246985,
	}
	ids.Dest_Talent = {
		--15
		Flashover = 267115,
		Eradication = 196412,
		SoulFire = 6353,
		--30
		ReverseEntropy = 205148,
		InternalCombustion = 266134,
		Shadowburn = 17877,
		--45
		DemonSkin = 219272,
		BurningRush = 111400,
		DarkPact = 108416,
		--60
		Inferno = 270545,
		FireandBrimstone = 196408,		
		Cataclysm = 152108,
		--75
		Darkfury = 264874,
		MortalCoil = 6789,
		DemonicCircle = 268358,
			DemonicCircleSummon = 48018,
			DemonicCircleTeleport = 48020,
		--90
		RoaringBlaze = 205184,
		GrimoireofSupremacy = 266086,
		GrimoireofSacrifice = 108503,
		--100
		SoulConduit = 215941,
		ChannelDemonfire = 196447,
		DarkSoulInstability = 113858,
	}
	ids.Dest_Form = {
	
	}
	ids.Dest_Buff = {
		BackDraft = 117828,
		BurningRush = 111400,
		DarkPact = 108416,
		GrimoireofSacrifice = 196099,
		DarkSoulInstability = 113858,
 	}
	ids.Dest_Debuff = {
		Immolate = 157736,
		Eradication = 196414,
		Havoc = 80240,
	}
	ids.Dest_PetAbility = {
		CauterizeMaster = 119899, --Imp
		Suffering = 17735, --Voidwalker
		Whiplash = 6360, --Succubus
		SpellLock = 19647, --Felhunter
		DevourMagic = 19505, --Felhunter
		OpticalBlast = 115781, --Observer
		MeteorStrike = 171017, --Infernal	
		ThreateningPresence = 112042, -- Voidwalker
	}