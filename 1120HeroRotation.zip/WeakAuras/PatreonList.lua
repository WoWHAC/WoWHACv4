if not WeakAuras.IsLibsOK() then return end
---@type string
local AddonName = ...
---@class Private
local Private = select(2, ...)
Private.DiscordList = {

}
Private.DiscordListCJ = {

}
Private.DiscordListK = {

}
