local _, addonTable = ...;

--- @type MaxDps
if not MaxDps then return end

local Druid = addonTable.Druid;

function Druid:Restoration()
	return nil;
end