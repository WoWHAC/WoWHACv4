# MaxDps

## [v8.3.1](https://github.com/kaminaris/MaxDps/tree/v8.3.1) (2020-09-06)
[Full Changelog](https://github.com/kaminaris/MaxDps/compare/v8.3.0...v8.3.1) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- v8.3.1 - StdUi version up, Version bump, Fixes for modules, Neuron support  
