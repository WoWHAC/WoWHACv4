local _, addonTable = ...;

--- @type MaxDps
if not MaxDps then return end

local Paladin = addonTable.Paladin;
local MaxDps = MaxDps;

function Paladin:Holy()

end