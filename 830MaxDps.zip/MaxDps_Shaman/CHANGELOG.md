# MaxDps_Shaman

## [v8.3.0](https://github.com/kaminaris/MaxDps-Shaman/tree/v8.3.0) (2020-05-11)
[Full Changelog](https://github.com/kaminaris/MaxDps-Shaman/compare/v8.2.5...v8.3.0)

- v8.3.0 - Version bump  
- Merge pull request #2 from Delsorou/patch-1  
    Check sundering talent for priority rotation  
- Check sundering talent for priority rotation  
    Added check for Sundering talent to "priority" rotation due to chat spam from levels 1-90.  