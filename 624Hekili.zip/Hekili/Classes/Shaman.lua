-- Shaman.lua
-- August 2014

local addon, ns = ...
local Hekili = _G[ addon ]

local class = ns.class
local state = ns.state

local addExclusion = ns.addExclusion

local addHook = ns.addHook
local callHook = ns.callHook

local addAbility = ns.addAbility
local modifyAbility = ns.modifyAbility
local addHandler = ns.addHandler

local addAura = ns.addAura
local modifyAura = ns.modifyAura

local addGearSet = ns.addGearSet
local addGlyph = ns.addGlyph
local addTalent = ns.addTalent
local addPerk = ns.addPerk
local addResource = ns.addResource
local addStance = ns.addStance

local removeResource = ns.removeResource

local setClass = ns.setClass
local setPotion = ns.setPotion
local setRole = ns.setRole

local storeDefault = ns.storeDefault

-- This table gets loaded only if there's a pported class/specialization.
if (select(2, UnitClass('player')) == 'SHAMAN') then

  ns.initializeClassModule = function ()

    setClass( 'SHAMAN' )
    setRole( 'attack' )

    addResource( 'mana', true )

    addTalent( 'natures_guardian', 30884 )
    addTalent( 'stone_bulwark_totem', 108270 )
    addTalent( 'astral_shift', 108271 )
    addTalent( 'frozen_power', 63374 )
    addTalent( 'earthgrab_totem', 51485 )
    addTalent( 'windwalk_totem', 108273 )
    addTalent( 'call_of_the_elements', 108285 )
    addTalent( 'totemic_persistence', 108284 )
    addTalent( 'totemic_projection', 108287 )
    addTalent( 'elemental_mastery', 16166 )
    addTalent( 'ancestral_swiftness', 16188 )
    addTalent( 'echo_of_the_elements', 108283 )
    addTalent( 'rushing_streams', 147074 )
    addTalent( 'ancestral_guidance', 108281 )
    addTalent( 'conductivity', 108282 )
    addTalent( 'unleashed_fury', 117012 )
    addTalent( 'primal_elementalist', 117013 )
    addTalent( 'elemental_blast', 117014 )
    addTalent( 'elemental_fusion', 152257 )
    addTalent( 'storm_elemental_totem', 152256 )
    addTalent( 'liquid_magma', 152255 )

    -- Major Glyphs.
    addGlyph( 'capacitor_totem', 55442 )
    addGlyph( 'chain_lightning', 55449 )
    addGlyph( 'chaining', 55452 )
    addGlyph( 'cleansing_waters', 55445 )
    addGlyph( 'ephemeral_spirits', 159640 )
    addGlyph( 'eternal_earth', 147781 )
    addGlyph( 'feral_spirit', 63271 )
    addGlyph( 'fire_elemental_totem', 55455 )
    addGlyph( 'fire_nova', 55450 )
    addGlyph( 'flame_shock', 55447 )
    addGlyph( 'frost_shock', 55443 )
    addGlyph( 'frostflame_weapon', 161654 )
    addGlyph( 'ghost_wolf', 59289 )
    addGlyph( 'grounding', 159643 )
    addGlyph( 'grounding_totem', 55441 )
    addGlyph( 'healing_stream_totem', 55456 )
    addGlyph( 'healing_wave', 55440 )
    addGlyph( 'hex', 63291 )
    addGlyph( 'lava_spread', 159644 )
    addGlyph( 'lightning_shield', 101052 )
    addGlyph( 'purge', 55439 )
    addGlyph( 'purging', 147762 )
    addGlyph( 'reactive_shielding', 159647 )
    addGlyph( 'riptide', 63273 )
    addGlyph( 'shamanistic_rage', 63280 )
    addGlyph( 'shamanistic_resolve', 159648 )
    addGlyph( 'shocks', 159649 )
    addGlyph( 'spirit_walk', 55454 )
    addGlyph( 'spiritwalkers_aegis', 159651 )
    addGlyph( 'spiritwalkers_focus', 159650 )
    addGlyph( 'spiritwalkers_grace', 55446 )
    addGlyph( 'telluric_currents', 55453 )
    addGlyph( 'thunder', 63270 )
    addGlyph( 'totemic_recall', 55438 )
    addGlyph( 'totemic_vigor', 63298 )
    addGlyph( 'unstable_earth', 55437 )
    addGlyph( 'water_shield', 55436 )
    addGlyph( 'wind_shear', 55451 )

    -- Minor Glyphs.
    addGlyph( 'astral_fixation', 147787 )
    addGlyph( 'astral_recall', 58058 )
    addGlyph( 'deluge', 63279 )
    addGlyph( 'elemental_familiars', 147788 )
    addGlyph( 'far_sight', 58059 )
    addGlyph( 'flaming_serpents', 147772 )
    addGlyph( 'ghostly_speed', 159642 )
    addGlyph( 'lava_lash', 55444 )
    addGlyph( 'lingering_ancestors', 147784 )
    addGlyph( 'rain_of_frogs', 147707 )
    addGlyph( 'spirit_raptors', 147783 )
    addGlyph( 'spirit_wolf', 147770 )
    addGlyph( 'compy', 147785 )
    addGlyph( 'lakestrider', 55448 )
    addGlyph( 'spectral_wolf', 58135 )
    addGlyph( 'thunderstorm', 62132 )
    addGlyph( 'totemic_encirclement', 58057 )

    -- Player Buffs / Debuffs
    addAura( 'ancestral_swiftness', 16188, 'duration', 3600 )
    addAura( 'ascendance', 114051, 'duration', 15 )
    addAura( 'earthquake', 182387, 'duration', 10 )
    -- addAura( 'echo_of_the_elements', 159103, 'duration', 20 )
    addAura( 'elemental_blast', 117014, 'duration', 8 )
    addAura( 'elemental_fusion', 157174, 'duration', 15, 'max_stack', 2 )
    addAura( 'elemental_mastery', 16166, 'duration', 20 )
    addAura( 'exhaustion', 57723, 'unit', 'player', 'duration', 600 )
    addAura( 'improved_chain_lightning', 157766, 'duration', 10 )
    class.auras[ 'enhanced_chain_lightning' ] = class.auras[ 'improved_chain_lightning' ] -- alias bc SimC uses both.
    addAura( 'flame_shock', 8050, 'duration', 30 )
    addAura( 'focus_of_the_elements', 167205, 'duration', 10 )
    addAura( 'frost_shock', 8056, 'duration', 8 )
    addAura( 'healing_rain', 73920, 'duration', 10 )
    addAura( 'lava_surge', 77762 , 'duration', 6 )
    addAura( 'lightning_shield', 324, 'duration', 3600 )
    addAura( 'liquid_magma', 152255, 'duration', 10, 'affects', 'pet',
      'feign', function()
        if talent.liquid_magma.enabled then
          buff.liquid_magma.count = talent.liquid_magma.enabled and cooldown.liquid_magma.remains > 34 and 1 or 0
          buff.liquid_magma.expires = min( cooldown.liquid_magma.expires - 34, totem.fire.expires )
          buff.liquid_magma.applied = cooldown.liquid_magma.expires - 44
          buff.liquid_magma.caster = 'player'
          setCooldown( 'fire_elemental_totem', max( cooldown.fire_elemental_totem.remains, buff.liquid_magma.remains ) )
          setCooldown( 'searing_totem', buff.liquid_magma.remains )
          setCooldown( 'magma_totem', buff.liquid_magma.remains )
        else
          removeBuff( 'liquid_magma' )
        end
      end )
    addAura( 'maelstrom_weapon', 51530 , 'duration', 30, 'max_stack', 5 )
    addAura( 'sated', 57724, 'unit', 'player', 'duration', 600 )
    addAura( 'spiritwalkers_grace', 79206, 'duration', 15 )
    addAura( 'stormstrike', 17364 , 'duration', 15 )
    addAura( 'thunderstorm', 51490, 'duration', 5 )
    addAura( 'unleash_flame', 73683 , 'duration', 20 )
    addAura( 'unleash_wind', 73681 , 'duration', 30, 'max_stack', 6 )
    addAura( 'unleashed_fury', 118472, 'duration', 10 )
    addAura( 'windstrike', 115356, 'duration', 15 )

    addPerk( 'enhanced_chain_lightning', 157765 )
    class.perks[ 'improved_chain_lightning' ] = class.perks[ 'enhanced_chain_lightning' ] -- alias bc SimC uses both.
    addPerk( 'enhanced_unleash', 157784 )
    addPerk( 'improved_flame_shock', 157804 )
    addPerk( 'improved_lightning_shield', 157774 )
    addPerk( 'improved_maelstrom_weapon', 157807 )
    addPerk( 'improved_reincarnation', 157764 )

    addExclusion( 324 ) -- exclude LS from target detection; enemy could be inaccessible
    addExclusion( 26364 ) -- LS damage spellID

    -- Gear Sets
    addGearSet( 't18_class_trinket', 124521 )
    addGearSet( 'tier18', 124293, 124297, 124302, 124303, 124308 )
    addGearSet( 'tier17', 115579, 115576, 115577, 115578, 115575 )
    addGearSet( 'tier16_caster', 99341, 99347, 99340, 99342, 99095 )
    addGearSet( 'tier16_melee', 99347, 99340, 99341, 99342, 99343 )
    addGearSet( 'tier15_melee', 96689, 96690, 96691, 96692, 96693 )
    addGearSet( 'tier14_melee', 87138, 87137, 87136, 87135, 87134 )

    ns.addToggle( 'magma', true, "Liquid Magma", "Toggling this keybinding will enable or disable Liquid Magma (|cFFFFD100toggle.magma|r) in the default action lists." )
    
    ns.addToggle( 'nova_st', false, "Single-Target Fire Nova", "Toggling this keybinding will enable or disable Fire Nova (|cFFFFD100toggle.nova_st|r) entries within the default Single Target priority list.  This feature is built around spending Fire Nova when it would provide the highest damage against your primary target." )


    ns.RegisterEvent( "UNIT_SPELLCAST_SUCCEEDED", function( _, unit, spell, _, spellID )

        if unit == 'player' and class.abilities[ spellID ] and class.abilities[ spellID ].key == 'ascendance' then
          class.abilities[ spellID ].last = GetTime()
        end

    end )


    addHook( "timeToReady", function( delay, ability )
      if ability == 'ascendance' and class.abilities[ ability ].last and state.now + state.offset + state.delay - class.abilities[ ability ].last < 180 then
        return class.abilities[ ability ].last + 180
      end
      return delay
    end )


    -- Set racial to the right spellID.
    class.abilities[ 'blood_fury' ].elem.id = 33697


    addAbility(	'ancestral_swiftness',
      {
        id = 16188,
        spend = 0,
        cast = 0,
        gcdType	= 'off',
        cooldown = 90
      } )

    addAbility(	'ascendance',
      {
        id = 114051,
        known = 114049,
        spend = 0.052,
        cast = 0,
        gcdType = 'off',
        cooldown = 120,
        toggle = 'cooldowns'
      }, 114050 )

    addAbility( 'bloodlust',
      {
        id = 2825,
        spend = 0.215,
        cast = 0,
        gcdType = 'off',
        cooldown = 300,
        toggle = 'cooldowns'
      } )

    addAbility( 'chain_lightning',
      {
        id = 421,
        spend = 0.01,
        cast = 2.0,
        gcdType = 'spell',
        cooldown = 0,
        hostile = true
      } )

    addAbility( 'earth_elemental_totem',
      {
        id = 2062,
        spend = 0.281,
        cast = 0,
        gcdType = 'totem',
        cooldown = 300
      } )

    addAbility( 'earth_shock',
      {
        id = 8042,
        spend = 0.012,
        cast = 0,
        gcdType = 'spell',
        cooldown = 6,
        hostile = true
      } )

    addAbility( 'earthquake',
      {
        id = 61882,
        spend = 0.008,
        cast = 2.5,
        gcdType = 'spell',
        cooldown = 10,
        charges = 1,
        recharge = 10,
        hostile = true
      } )

    addAbility( 'elemental_blast',
      {
        id = 117014,
        spend = 0,
        cast = 2.0,
        gcdType = 'spell',
        cooldown = 12,
        hostile = true
      } )

    addAbility( 'elemental_mastery',
      {
        id = 16166,
        spend = 0,
        cast = 0,
        gcdType = 'off',
        cooldown = 120,
        toggle = 'cooldowns'
      } )

    addAbility( 'feral_spirit',
      {
        id = 51533,
        spend = 0.12,
        cast = 0,
        gcdType = 'spell',
        cooldown = 120,
        toggle = 'cooldowns'
      } )

    addAbility( 'fire_elemental_totem',
      {
        id = 2894,
        spend = 0.269,
        cast = 0,
        gcdType = 'totem',
        cooldown = 300,
        toggle = 'cooldowns',
        usable = function ( ) return buff.liquid_magma.down end,
      } )

    addAbility( 'fire_nova',
      {
        id = 1535,
        spend = 0.137,
        cast = 0,
        gcdType = 'spell',
        cooldown = 4.5,
        charges = 1,
        recharge = 4.5,
        hostile = true
      } )

    addAbility( 'flame_shock',
      {
        id = 8050,
        spend = 0.012,
        cast = 0,
        gcdType = 'spell',
        cooldown = 6,
        hostile = true
      } )

    addAbility( 'frost_shock',
      {
        id = 8056,
        spend = 0.012,
        cast = 0,
        gcdType = 'spell',
        cooldown = 6,
        hostile = true
      } )

    class.abilities[ 'shock' ] = class.abilities[ 'frost_shock' ]
    ns.keys[ 'shock' ] = true

    addAbility( 'healing_rain',
      {
        id = 73920,
        spend = 0.216,
        cast = 2,
        gcdType = 'spell',
        cooldown = 10
      } )
      
    addAbility( 'healing_stream_totem',
      {
        id = 5394,
        spend = 0.086,
        cast = 0,
        gcdType = 'totem',
        cooldown = 30,
        hostile = false,
      } )

    addAbility( 'healing_surge',
      {
        id = 8004,
        spend = 0.207,
        cast = 1.5,
        gcdType = 'spell',
        cooldown = 0
      } )

    addAbility( 'heroism',
      {
        id = 32182,
        spend = 0.215,
        cast = 0,
        gcdType = 'off',
        cooldown = 300,
        toggle = 'cooldowns'
      } )
     
    if state.faction == 'Alliance' then
      class.abilities.bloodlust = class.abilities.heroism
    else
      class.abilities.heroism = class.abilities.bloodlust
    end

    addAbility( 'lava_beam',
      {
        id = 114074,
        known = function() return spec.elemental and buff.ascendance.up end,
        spend = 0.01,
        cast = 2,
        gcdType = 'spell',
        cooldown = 0,
        hostile = true
      } )

    addAbility( 'lava_burst',
      {
        id = 51505,
        known = function() return spec.elemental and level >= 34 end,
        spend = 0.005,
        cast = 2,
        gcdType = 'spell',
        charges = 1,
        recharge = 8,
        cooldown = 8,
        hostile = true
      } )


    addAbility( 'lava_lash',
      {
        id = 60103,
        spend = 0.01,
        cast = 0,
        gcdType = 'melee',
        cooldown = 10.5,
        charges = 1,
        recharge = 10.5,
        hostile = true
      } )

    addAbility( 'lightning_bolt',
      {
        id = 403,
        spend = 0.018,
        cast = 2.5,
        gcdType = 'spell',
        cooldown = 0,
        hostile = true
      } )

    addAbility( 'lightning_shield',
      {
        id = 324,
        spend = 0,
        cast = 0,
        gcdType = 'spell',
        cooldown = 0
      } )

    addAbility( 'liquid_magma',
      {
        id = 152255,
        spend = 0,
        cast = 0,
        gcdType = 'spell',
        cooldown = 45,
        hostile = true,
        toggle = 'magma'
      } )

    addAbility( 'magma_totem',
      {
        id = 8190,
        spend = 0.211,
        cast = 0,
        gcdType = 'totem',
        cooldown = 0,
        hostile = true,
        usable = function ( ) return buff.liquid_magma.down end,
      } )

    addAbility( 'searing_totem',
      {
        id = 3599,
        spend = 0.03,
        cast = 0,
        gcdType = 'totem',
        cooldown = 0,
        hostile = true,
        usable = function ( ) return buff.liquid_magma.down end,
      } )

    addAbility( 'spiritwalkers_grace',
      {
        id = 79206,
        spend = 0.141,
        cast = 0,
        gcdType = 'off',
        cooldown = 120
      } )

    addAbility( 'storm_elemental_totem',
      {
        id = 152256,
        spend = 0.269,
        cast = 0,
        gcdType = 'totem',
        cooldown = 300,
        toggle = 'cooldowns'
      } )

    addAbility( 'stormstrike',
      {
        id = 17364,
        known = function() return spec.enhancement and not buff.ascendance.up end,
        spend = 0.01,
        cast = 0,
        gcdType = 'melee',
        charges = 1,
        recharge = 7.5,
        cooldown = 7.5,
        hostile = true
      } )

    addAbility( 'strike',
      {
        id = 73899,
        spend = 0.094,
        cast = 0,
        gcdType = 'melee',
        cooldown = 7.5,
        charges = 1,
        recharge = 7.5,
        hostile = true
      } )

    addAbility( 'thunderstorm',
      {
        id = 51490,
        spend = 0,
        cast = 0,
        gcdType = 'spell',
        cooldown = 45,
        hostile = true
      } )

    addAbility( 'unleash_elements',
      {
        id = 73680,
        spend = 0.075,
        cast = 0,
        gcdType = 'spell',
        cooldown = 15
      } )

    addAbility( 'unleash_flame',
      {
        id = 165462,
        spend = 0.075,
        cast = 0,
        gcdType = 'spell',
        cooldown = 15
      } )

    addAbility( 'wind_shear',
      {
        id = 57994,
        spend = 0.094,
        cast = 0,
        gcdType = 'off',
        cooldown = 12,
        toggle = 'interrupts',
        usable = function() return target.casting end
      } )

    addAbility( 'windstrike',
      {
        id = 115356,
        known = function() return spec.enhancement and buff.ascendance.up end,
        spend = 0.01,
        cast = 0,
        gcdType = 'melee',
        cooldown = 7.5,
        charges = 1,
        recharge = 7.5,
        hostile = true
      } )


    ns.addHook( "specializationChanged", function ()

        for k,v in pairs( class.abilities ) do
          for key,mod in pairs( v.mods ) do
            class.abilities[ k ].mods[ key ] = nil
          end
        end

        -- Enhancement
        if state.spec.id == 263 then
          Hekili.minGCD = 1.0
          setPotion( 'draenic_agility' )

          modifyAbility( 'ascendance', 'id', 114051 )

          modifyAbility( 'ascendance', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'bloodlust', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'chain_lightning', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return max(0, x * haste)
          end )

          modifyAbility( 'chain_lightning', 'spend', function( x )
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return max(0, x * haste)
          end )

          modifyAbility( 'earth_elemental_totem', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'elemental_blast', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return x * haste
          end )

          modifyAbility( 'feral_spirit', 'cooldown', function( x )
            if glyph.ephemeral_spirits.enabled then x = x / 2 end
            return x
          end )

          modifyAbility( 'feral_spirit', 'spend', function( x )
            return x * 0.25
          end )
          
          modifyAbility( 'fire_nova', 'cooldown', function( x )
            -- if cooldown.fire_nova.charges > 1 then return 0 end
            return x * haste
          end )

          modifyAbility( 'fire_nova', 'recharge', function( x )
            return x * haste
          end )

          modifyAbility( 'fire_nova', 'spend', function( x )
            if spec.enhancement then return x * 0.25 end
            return x
          end )

          modifyAbility( 'fire_nova', 'charges', function( x )
            if talent.echo_of_the_elements.enabled then return 2 end
            return x
          end )

          modifyAbility( 'flame_shock', 'cooldown', function( x )
            return x * haste
          end )

          modifyAbility( 'flame_shock', 'spend', function( x )
            return x * 0.10
          end )

          modifyAbility( 'frost_shock', 'cooldown', function( x )
            if glyph.frost_shock.enabled then x = 4 end
            return x * haste
          end )

          modifyAbility( 'frost_shock', 'spend', function( x )
            return x * 0.10
          end )

          modifyAbility( 'healing_rain', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return max(0, x * haste)
          end )

          modifyAbility( 'healing_rain', 'spend', function( x )
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return max(0, x * haste)
          end )

          modifyAbility( 'healing_surge', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return max(0, x * haste)
          end )

          modifyAbility( 'healing_surge', 'spend', function( x )
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return x
          end )

          modifyAbility( 'heroism', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'lava_lash', 'cooldown', function( x )
            -- if cooldown.lava_lash.charges > 1 then return 0 end
            return x * haste
          end )

          modifyAbility( 'lava_lash', 'recharge', function( x )
            return x * haste
          end )

          modifyAbility( 'lava_lash', 'charges', function( x )
            if talent.echo_of_the_elements.enabled then return 2 end
            return x
          end )

          modifyAbility( 'lightning_bolt', 'cast', 2.5 )

          modifyAbility( 'lightning_bolt', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return max(0, x * haste)
          end )

          modifyAbility( 'lightning_bolt', 'spend', function( x )
            if buff.maelstrom_weapon.up then x = ( x - ( x * ( 0.2 * buff.maelstrom_weapon.stack ) ) ) end
            return max(0, x * haste)
          end )

          modifyAbility( 'magma_totem', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'searing_totem', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'stormstrike', 'charges', function( x )
            if talent.echo_of_the_elements.enabled then return 2 end
            return x
          end )

          modifyAbility( 'stormstrike', 'cooldown', function( x )
            -- if cooldown.stormstrike.charges > 1 then return 0 end
            return x * haste
          end )

          modifyAbility( 'stormstrike', 'recharge', function( x )
            return x * haste
          end )

          modifyAbility( 'strike', 'charges', function( x )
            if talent.echo_of_the_elements.enabled then return 2 end
            return x
          end )

          modifyAbility( 'strike', 'cooldown', function( x )
            -- if cooldown.stormstrike.charges > 1 then return 0 end
            return x * haste
          end )

          modifyAbility( 'strike', 'recharge', function( x )
            return x * haste
          end )

          modifyAbility( 'unleash_elements', 'cooldown', function( x )
            return x * haste
          end )

          modifyAbility( 'unleash_elements', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'wind_shear', 'spend', function( x )
            return x * 0.25
          end )

          modifyAbility( 'windstrike', 'charges', function( x )
            if talent.echo_of_the_elements.enabled then return 2 end
            return x
          end )

          modifyAbility( 'windstrike', 'cooldown', function( x )
            -- if cooldown.windstrike.charges > 1 then return 0 end
            return x * haste
          end )

          modifyAbility( 'windstrike', 'recharge', function( x )
            return x * haste
          end )

          modifyAura( 'ascendance', 'id', 114051 )

          modifyAura( 'lightning_shield', 'max_stack', 1 )
          
          modifyAura( 'maelstrom_weapon', 'max_stack', function( x )
            if set_bonus.tier18_4pc > 0 then return 10 end
            return x
          end )
          
          modifyAura( 'flame_shock', 'duration', 30 )

          -- Elemental
        elseif state.spec.id == 262 then
          Hekili.minGCD = 1.5
          setPotion( 'draenic_intellect' )

          modifyAbility( 'ascendance', 'id', function( x )
            return 114050
          end )

          modifyAbility( 'chain_lightning', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            return x * haste
          end )

          modifyAbility( 'earthquake', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            if buff.enhanced_chain_lightning.up then return 0 end
            return x * haste
          end )

          modifyAbility( 'earthquake', 'charges', function( x )
            if talent.echo_of_the_elements.enabled then return 2 end
            return x
          end )

          modifyAbility( 'earthquake', 'cooldown',  function( x )
            -- if cooldown.earthquake.charges > 1 then return 0 end
            return x
          end )

          modifyAbility( 'elemental_blast', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            return x * haste
          end )

          modifyAbility( 'frost_shock', 'cooldown',  function( x )
            if glyph.frost_shock.enabled then x = x - 2 end
            return x
          end )

          modifyAbility( 'healing_rain', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            return x * haste
          end )

          modifyAbility( 'healing_surge', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            return x * haste
          end )

          modifyAbility( 'lava_burst', 'cast', function( x )
            if buff.lava_surge.up then return 0
            elseif buff.ancestral_swiftness.up then return 0 end
            return x * haste
          end )

          modifyAbility( 'lava_burst', 'charges', function( x )
            if talent.echo_of_the_elements.enabled then return 2 end
            return x
          end )

          modifyAbility( 'lava_burst', 'cooldown', function( x )
            if buff.lava_surge.up and cast_start > 0 and buff.lava_surge.applied > cast_start then return 0 end
            if buff.ascendance.up then return 0 end
            -- if cooldown.lava_burst.charges > 1 then return 0 end
            return x
          end )

          modifyAbility( 'lava_burst', 'recharge', function( x )
            if buff.ascendance.up then return 0 end
            return x
          end )

          modifyAbility( 'lightning_bolt', 'cast', 2.0 )

          modifyAbility( 'lightning_bolt', 'cast', function( x )
            if buff.ancestral_swiftness.up then return 0 end
            return x * haste
          end )

          modifyAbility( 'spiritwalkers_grace', 'cooldown', function( x )
            if glyph.spiritwalkers_focus.enabled then x = x - 60 end
            return x
          end )

          modifyAbility( 'thunderstorm', 'cooldown', function( x )
            if glyph.thunder.enabled then x = x - 10 end
            return x
          end )

          modifyAura( 'ascendance', 'id', 114050 )
          
          modifyAura( 'flame_shock', 'duration', function( x )
            if t18_class_trinket == 1 then return x + 1.5 * x end
            return x
          end ) 

          modifyAura( 'lightning_shield', 'max_stack', 15 )          

          modifyAura( 'lightning_shield', 'max_stack', function( x )
            if perk.improved_lightning_shield.enabled then x = 20 end
            return x
          end )

        end

        -- Shared
        modifyAbility( 'fire_elemental_totem', 'cooldown', function( x )
          if glyph.fire_elemental_totem.enabled then x = x / 2 end
          return x
        end )

        modifyAbility( 'fire_elemental_totem', 'spend', function( x )
          if spec.enhancement then return x * 0.25 end
          return x
        end )

    end )


    -- All actions that modify the game state are included here.
    addHandler( 'ancestral_swiftness', function ()
      applyBuff( 'ancestral_swiftness', 60 )
    end )


    addHandler( 'ascendance', function ()
      applyBuff( 'ascendance', 15 )
      gainCharges( 'lava_burst', 1 )
      gainCharges( 'stormstrike', 1 )
      gainCharges( 'windstrike', 1 )
      gainCharges( 'strike', 1 )
    end )


    addHandler( 'berserking', function ()
      applyBuff( 'berserking', 10 )
    end )

    addHandler( 'blood_fury', function ()
      applyBuff( 'blood_fury', 15 )
    end )

    addHandler( 'bloodlust', function ()
      applyBuff( 'bloodlust', 40 )
      applyDebuff( 'player', 'sated', 600 )
    end )

    addHandler( 'chain_lightning', function ()
      if buff.maelstrom_weapon.stack >= 5 then removeStack( 'maelstrom_weapon', 5 )
      elseif buff.ancestral_swiftness.up then removeBuff( 'ancestral_swiftness' )
      elseif buff.maelstrom_weapon.up then removeBuff( 'maelstrom_weapon' ) end

      if perk.enhanced_chain_lightning.enabled and active_enemies >= 3 then
        applyBuff( 'improved_chain_lightning', 15 )
        applyBuff( 'enhanced_chain_lightning', 15 )
      end

      if buff.lightning_shield.up and buff.lightning_shield.stack < buff.lightning_shield.max_stack then
        addStack( 'lightning_shield', 3600, min( glyph.chain_lightning.enabled and 5 or 3, active_enemies) )
      end
    end )

    addHandler( 'earth_elemental_totem', function ()
      summonTotem( 'earth_elemental_totem', 'earth', 60 )

      if talent.storm_elemental_totem.enabled then setCooldown( 'storm_elemental_totem', max( cooldown.storm_elemental_totem.remains, 61 ) ) end
      setCooldown( 'fire_elemental_totem', max( cooldown.fire_elemental_totem.remains, 61 ) )
      -- Remove Fire Elemental Pet?  Reset Fire Elemental Totem?
    end )

    addHandler( 'earth_shock', function ()
      local cooldown = spec.elemental == 1 and 5 or 6 * haste
      setCooldown( 'flame_shock', cooldown )
      setCooldown( 'frost_shock', cooldown )
      if buff.lightning_shield.stack > 1 then
        if set_bonus.tier17_2pc then applyBuff( 'focus_of_the_elements', 10 ) end
        if set_bonus.tier17_4pc and buff.lightning_shield.stack > 12 then
          applyBuff( 'lava_surge', 6 )
          if talent.echo_of_the_elements.enabled then gainCharges( 'lava_burst', 1 )
          else setCooldown( 'lava_burst', 0 ) end
        end
        buff.lightning_shield.count = 1
      end
    end )

    addHandler( 'earthquake', function ()
      removeBuff( 'improved_chain_lightning' )
      removeBuff( 'enhanced_chain_lightning' )
      applyDebuff( 'target', 'earthquake', 10 )
    end )

    addHandler( 'elemental_blast', function ()
      applyBuff( 'elemental_blast', 8 )
    end )

    addHandler( 'elemental_mastery', function ()
      applyBuff( 'elemental_mastery', 20 )
    end )


    addHandler( 'fire_elemental_totem', function ()
      if glyph.fire_elemental_totem.enabled then
        summonTotem( 'fire_elemental_totem', 'fire', 30 )
      else
        summonTotem( 'fire_elemental_totem', 'fire', 60 )
      end

      if talent.storm_elemental_totem.enabled then setCooldown( 'storm_elemental_totem', max( cooldown.storm_elemental_totem.remains, 61 ) ) end
      setCooldown( 'earth_elemental_totem', max( cooldown.storm_elemental_totem.remains, 61 ) )
      -- Remove Earth Elemental Pet?  Reset Earth Elemental Totem?
    end )

    addHandler( 'fire_nova', function ()
      removeBuff( 'unleash_flame' )
    end )

    addHandler( 'flame_shock', function ()
      local cooldown = spec.elemental == 1 and 5 or 6 * haste
      applyDebuff( 'target', 'flame_shock', 30 )
      removeBuff( 'unleash_flame' )
      removeBuff( 'elemental_fusion' )
      setCooldown( 'earth_shock', cooldown )
      setCooldown( 'frost_shock', cooldown )
    end )

    addHandler( 'frost_shock', function()
      local cooldown = 6

      if glyph.frost_shock.enabled then cooldown = cooldown - 2 end
      if spec.enhancement then cooldown = cooldown * haste end

      removeBuff( 'elemental_fusion' )
      applyDebuff( 'target', 'frost_shock', 8 )
      setCooldown( 'earth_shock', cooldown )
      setCooldown( 'flame_shock', cooldown )
    end )

    addHandler( 'healing_rain', function ()
      if buff.maelstrom_weapon.stack >= 5 then removeStack( 'maelstrom_weapon', 5 )
      elseif buff.ancestral_swiftness.up then removeBuff( 'ancestral_swiftness' )
      elseif buff.maelstrom_weapon.up then removeBuff( 'maelstrom_weapon' ) end
      applyBuff( 'healing_rain', 10 )
    end )

    addHandler( 'healing_stream_totem', function ()
      summonTotem( 'healing_stream_totem', 'water', 15 )
    end )

    addHandler( 'healing_surge', function ()
      if buff.maelstrom_weapon.stack >= 5 then removeStack( 'maelstrom_weapon', 5 )
      elseif buff.ancestral_swiftness.up then removeBuff( 'ancestral_swiftness' )
      elseif buff.maelstrom_weapon.up then removeBuff( 'maelstrom_weapon' ) end
    end )

    addHandler( 'heroism', class.abilities[ 'bloodlust' ].handler )

    addHandler( 'lava_beam', class.abilities[ 'chain_lightning' ].handler )

    addHandler( 'lava_burst', function ()
      if buff.lava_surge.up and ( cast_start == 0 or buff.lava_surge.applied < cast_start ) then removeBuff( 'lava_surge' ) end
      if buff.lightning_shield.up then addStack( 'lightning_shield', 3600, 1 ) end
    end )

    addHandler( 'lava_lash', function ()
      if talent.elemental_fusion.enabled then
        applyBuff( 'elemental_fusion', 20, max(2, buff.elemental_fusion.stack + 1) )
      end
    end )

    addHandler( 'lightning_bolt', function ()
      if buff.maelstrom_weapon.stack >= 5 then removeStack( 'maelstrom_weapon', 5 )
      elseif buff.ancestral_swiftness.up then removeBuff( 'ancestral_swiftness' )
      elseif buff.maelstrom_weapon.up then removeBuff( 'maelstrom_weapon' ) end

      if buff.lightning_shield.up and buff.lightning_shield.stack < buff.lightning_shield.max_stack then
        addStack( 'lightning_shield', 3600, 1 )
      end
    end )

    addHandler( 'lightning_shield', function ()
      applyBuff( 'lightning_shield', 3600 )
    end )

    addHandler( 'liquid_magma', function ()
      applyBuff( 'liquid_magma', min( totem.fire.remains, 10 ) )
      setCooldown( 'fire_elemental_totem', max( cooldown.fire_elemental_totem.remains, buff.liquid_magma.remains ) )
      setCooldown( 'searing_totem', buff.liquid_magma.remains )
      setCooldown( 'magma_totem', buff.liquid_magma.remains )
    end )

    addHandler( 'magma_totem', function ()
      summonTotem( 'magma_totem', 'fire', 60 )
    end )

    addHandler( 'searing_totem', function ()
      summonTotem( 'searing_totem', 'fire', 60 )
    end )

    addHandler( 'spiritwalkers_grace', function ()
      if glyph.spiritwalkers_focus.enabled then applyBuff( 'spiritwalkers_grace', 1, 8 )
      elseif glyph.spiritwalkers_focus.enabled then applyBuff( 'spiritwalkers_grace', 1, 20 )
      else applyBuff( 'spiritwalkers_grace', 1, 15 ) end
    end )

    addHandler( 'storm_elemental_totem', function ()
      summonTotem( 'storm_elemental_totem', 'air', 60 )
      setCooldown( 'fire_elemental_totem', max( cooldown.fire_elemental_totem.remains, 61 ) )
      setCooldown( 'earth_elemental_totem', max( cooldown.earth_elemental_totem.remains, 61 ) )
    end )

    addHandler( 'stormstrike', function ()
      spendCharges( 'strike', 1 )
      spendCharges( 'windstrike', 1 )
      if set_bonus.tier17_2pc and cooldown.feral_spirit.remains > 0 then
        setCooldown( 'feral_spirit', max(0, cooldown.feral_spirit.remains - 5) )
      end
      applyDebuff( 'target', 'stormstrike', 15 )
      if set_bonus.tier15_2pc_melee then addStack( 'maelstrom_weapon', 30, 2 ) end
    end )

    addHandler( 'thunderstorm', function ()
      applyDebuff( 'target', 'thunderstorm', 5 )
    end )

    addHandler( 'unleash_elements', function ()
      if talent.unleashed_fury.enabled then applyBuff( 'unleashed_fury', 10 ) end
      applyBuff( 'unleash_wind', 12, 6 )
      applyBuff( 'unleash_flame', 8 )
    end )

    addHandler( 'unleash_flame', function ()
      applyBuff( 'unleash_flame', 20 )
    end )

    addHandler( 'wind_shear', function ()
      interrupt()
    end )

    addHandler( 'windstrike', function ()
      spendCharges( 'strike', 1 )
      spendCharges( 'stormstrike', 1 )
      applyDebuff( 'target', 'windstrike', 15 )
      if set_bonus.tier15_2pc_melee then addStack( 'maelstrom_weapon', 30, 2 ) end
    end )

    -- Pick an instant cast ability for checking the GCD.
    -- setGCD( 'lightning_shield' )

    -- Import strings
    storeDefault( 'Enh: Precombat', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N263^SDefault^B^SRelease^N20150916.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^S!buff.lightning_shield.up^SAbility^Slightning_shield^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Shield^t^N2^T^SEnabled^B^SScript^Stoggle.cooldowns^SArgs^Sname=draenic_agility^SAbility^Spotion^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SPotion^t^t^SName^SEnh:~`Precombat^t^^]] )

    storeDefault( 'Enh: Default', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SScript^S^SDefault^B^SRelease^N20150916.1^SSpecialization^N263^SActions^T^N1^T^SEnabled^B^SScript^Stoggle.interrupts^SAbility^Swind_shear^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SWind~`Shear^t^N2^T^SEnabled^b^SScript^Stoggle.cooldowns&(target.health.pct<25|time>0.500)^SAbility^Sbloodlust^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SHeroism^t^N3^T^SEnabled^B^SScript^Stoggle.cooldowns&((talent.storm_elemental_totem.enabled&(pet.storm_elemental_totem.remains>=25|(cooldown.storm_elemental_totem.remains>target.time_to_die&pet.fire_elemental_totem.remains>=25)))|(!talent.storm_elemental_totem.enabled&pet.fire_elemental_totem.remains>=25)|target.time_to_die<=30)^SArgs^Sname=draenic_agility^SAbility^Spotion^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SPotion^t^N4^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sblood_fury^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SBlood~`Fury^t^N5^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sarcane_torrent^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SArcane~`Torrent^t^N6^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sberserking^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SBerserking^t^N7^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Selemental_mastery^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Mastery^t^N8^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sstorm_elemental_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SStorm~`Elemental~`Totem^t^N9^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sfire_elemental_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFire~`Elemental~`Totem^t^N10^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sferal_spirit^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFeral~`Spirit^t^N11^T^SEnabled^B^SScript^Stoggle.magma&(pet.searing_totem.remains>10|pet.magma_totem.remains>10|pet.fire_elemental_totem.remains>10)^SAbility^Sliquid_magma^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLiquid~`Magma^t^N12^T^SEnabled^B^SName^SAncestral~`Swiftness^SAbility^Sancestral_swiftness^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N13^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sascendance^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SAscendance^t^N14^T^SEnabled^B^SScript^Sactive_enemies>1^SArgs^Sname="Enh:~`AOE"^SAbility^Scall_action_list^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SCall~`Action~`List^t^N15^T^SEnabled^B^SName^SCall~`Action~`List~`(1)^SArgs^Sname="Enh:~`Single"^SAbility^Scall_action_list^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^t^SName^SEnh:~`Default^t^^]] )

    storeDefault( 'Enh: Single', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SScript^S^SDefault^B^SRelease^N20150916.1^SSpecialization^N263^SActions^T^N1^T^SEnabled^B^SScript^S!totem.fire.active^SAbility^Ssearing_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SSearing~`Totem^t^N2^T^SEnabled^B^SScript^Stalent.unleashed_fury.enabled^SAbility^Sunleash_elements^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SUnleash~`Elements^t^N3^T^SEnabled^B^SScript^Sbuff.maelstrom_weapon.react>=5+3*set_bonus.tier18_4pc^SAbility^Selemental_blast^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Blast^t^N4^T^SEnabled^B^SScript^S!talent.echo_of_the_elements.enabled|(talent.echo_of_the_elements.enabled&(charges=2|(action.windstrike.charges_fractional>1.75)|(charges=1&buff.ascendance.remains<1.5)))^SAbility^Swindstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SWindstrike^t^N5^T^SEnabled^B^SScript^Sbuff.maelstrom_weapon.react>=5+3*set_bonus.tier18_4pc^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Bolt^t^N6^T^SEnabled^B^SScript^S!talent.echo_of_the_elements.enabled|(talent.echo_of_the_elements.enabled&(charges=2|(action.stormstrike.charges_fractional>1.75)|target.time_to_die<6))^SAbility^Sstormstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SStormstrike^t^N7^T^SEnabled^B^SScript^S!talent.echo_of_the_elements.enabled|(talent.echo_of_the_elements.enabled&(charges=2|(action.lava_lash.charges_fractional>1.8)|target.time_to_die<8))^SAbility^Slava_lash^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLava~`Lash^t^N8^T^SEnabled^B^SScript^S(talent.elemental_fusion.enabled&buff.elemental_fusion.stack=2&buff.unleash_flame.up&dot.flame_shock.remains<16)|(!talent.elemental_fusion.enabled&buff.unleash_flame.up&dot.flame_shock.remains<=9)|!ticking^SAbility^Sflame_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFlame~`Shock^t^N9^T^SEnabled^B^SName^SUnleash~`Elements~`(1)^SAbility^Sunleash_elements^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N10^T^SEnabled^B^SScript^Stalent.echo_of_the_elements.enabled^SAbility^Swindstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SWindstrike~`(1)^t^N11^T^SEnabled^B^SScript^S(!set_bonus.tier18_4pc>0&buff.maelstrom_weapon.react>=3)|buff.ancestral_swiftness.up^SAbility^Selemental_blast^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Blast~`(1)^t^N12^T^SEnabled^B^SScript^S(!set_bonus.tier18_4pc>0&(buff.maelstrom_weapon.react>=3&!buff.ascendance.up))|buff.ancestral_swiftness.up^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Bolt~`(1)^t^N13^T^SEnabled^B^SScript^Stalent.echo_of_the_elements.enabled^SAbility^Slava_lash^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLava~`Lash~`(1)^t^N14^T^SEnabled^B^SScript^S(talent.elemental_fusion.enabled&dot.flame_shock.remains>=16)|!talent.elemental_fusion.enabled^SAbility^Sfrost_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFrost~`Shock^t^N15^T^SEnabled^B^SScript^Sbuff.maelstrom_weapon.react>=1+2*set_bonus.tier18_4pc^SAbility^Selemental_blast^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Blast~`(2)^t^N16^T^SEnabled^B^SScript^Stalent.echo_of_the_elements.enabled&((!set_bonus.tier18_4pc>0&(buff.maelstrom_weapon.react>=2&!buff.ascendance.up))|buff.ancestral_swiftness.up)^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Bolt~`(2)^t^N17^T^SEnabled^B^SScript^Stalent.echo_of_the_elements.enabled^SAbility^Sstormstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SStormstrike~`(1)^t^N18^T^SEnabled^B^SScript^S(!set_bonus.tier18_4pc>0&(buff.maelstrom_weapon.react>=1&!buff.ascendance.up))|(set_bonus.tier18_4pc>0&((talent.unleashed_fury.enabled&buff.unleashed_fury.up)|!talent.unleashed_fury.enabled)&(buff.maelstrom_weapon.react>=5|(buff.maelstrom_weapon.react>=3&!buff.ascendance.up)))|buff.ancestral_swiftness.up^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Bolt~`(3)^t^N19^T^SEnabled^B^SScript^Spet.searing_totem.remains<=20&!pet.fire_elemental_totem.active&!buff.liquid_magma.up^SAbility^Ssearing_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SSearing~`Totem~`(1)^t^t^SName^SEnh:~`Single^t^^]] )

    storeDefault( 'Enh: AOE', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N263^SDefault^B^SRelease^N20150916.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Sactive_enemies>=4&dot.flame_shock.ticking&(cooldown.shock.remains>cooldown.fire_nova.remains|cooldown.fire_nova.remains=0)^SAbility^Sunleash_elements^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SUnleash~`Elements^t^N2^T^SEnabled^B^SScript^Sactive_dot.flame_shock>=3&active_enemies>=3^SAbility^Sfire_nova^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFire~`Nova^t^N3^T^SEnabled^B^SScript^S!talent.echo_of_the_elements.enabled&active_dot.flame_shock>=4&cooldown.fire_nova.remains<=action.fire_nova.gcd%2^SArgs^Ssec=cooldown.fire_nova.remains^SAbility^Swait^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SWait^t^N4^T^SEnabled^B^SScript^S!totem.fire.active^SAbility^Smagma_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SMagma~`Totem^t^N5^T^SEnabled^B^SScript^Sdot.flame_shock.ticking&active_dot.flame_shock<active_enemies^SAbility^Slava_lash^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLava~`Lash^t^N6^T^SEnabled^B^SScript^S!buff.unleash_flame.up&(buff.maelstrom_weapon.react>=4|buff.ancestral_swiftness.up)^SAbility^Selemental_blast^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Blast^t^N7^T^SEnabled^B^SScript^Sbuff.maelstrom_weapon.react=5&((glyph.chain_lightning.enabled&active_enemies>=3)|(!glyph.chain_lightning.enabled&active_enemies>=2))^SAbility^Schain_lightning^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SChain~`Lightning^t^N8^T^SEnabled^B^SScript^Sactive_enemies<4^SAbility^Sunleash_elements^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SUnleash~`Elements~`(1)^t^N9^T^SEnabled^B^SScript^Sdot.flame_shock.remains<=9|!ticking^SAbility^Sflame_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFlame~`Shock^t^N10^T^SEnabled^B^SScript^S!debuff.stormstrike.up^SArgs^Starget=1^SAbility^Swindstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SWindstrike^t^N11^T^SEnabled^B^SScript^S!active_dot.stormstrike>=2^SArgs^Starget=2^SAbility^Swindstrike^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SWindstrike~`(1)^t^N12^T^SEnabled^B^SScript^S!active_dot.stormstrike>=3^SArgs^Starget=3^SAbility^Swindstrike^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SWindstrike~`(2)^t^N13^T^SEnabled^B^SName^SWindstrike~`(3)^SAbility^Swindstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N14^T^SEnabled^B^SScript^S!buff.unleash_flame.up&buff.maelstrom_weapon.react>=3^SAbility^Selemental_blast^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Blast~`(1)^t^N15^T^SEnabled^B^SScript^S(buff.maelstrom_weapon.react>=3|buff.ancestral_swiftness.up)&((glyph.chain_lightning.enabled&active_enemies>=4)|(!glyph.chain_lightning.enabled&active_enemies>=3))^SAbility^Schain_lightning^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SChain~`Lightning~`(1)^t^N16^T^SEnabled^B^SScript^Spet.magma_totem.remains<=20&!pet.fire_elemental_totem.active&!buff.liquid_magma.up^SAbility^Smagma_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SMagma~`Totem~`(1)^t^N17^T^SEnabled^B^SScript^Sbuff.maelstrom_weapon.react=5&glyph.chain_lightning.enabled&active_enemies<3^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Bolt^t^N18^T^SEnabled^B^SScript^S!debuff.stormstrike.up^SArgs^Starget=1^SAbility^Sstormstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SStormstrike^t^N19^T^SEnabled^B^SScript^S!active_dot.stormstrike>=2^SArgs^Starget=2^SAbility^Sstormstrike^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SStormstrike~`(1)^t^N20^T^SEnabled^B^SScript^S!active_dot.stormstrike>=3^SArgs^Starget=3^SAbility^Sstormstrike^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SStormstrike~`(2)^t^N21^T^SEnabled^B^SName^SStormstrike~`(3)^SAbility^Sstormstrike^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N22^T^SEnabled^B^SName^SLava~`Lash~`(1)^SAbility^Slava_lash^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N23^T^SEnabled^B^SScript^Sactive_dot.flame_shock>=2&active_enemies>=2^SAbility^Sfire_nova^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFire~`Nova~`(1)^t^N24^T^SEnabled^B^SScript^S!buff.unleash_flame.up&buff.maelstrom_weapon.react>=1^SAbility^Selemental_blast^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Blast~`(2)^t^N25^T^SEnabled^B^SScript^S(buff.maelstrom_weapon.react>=1|buff.ancestral_swiftness.up)&((glyph.chain_lightning.enabled&active_enemies>=3)|(!glyph.chain_lightning.enabled&active_enemies>=2))^SAbility^Schain_lightning^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SChain~`Lightning~`(2)^t^N26^T^SEnabled^B^SScript^S(buff.maelstrom_weapon.react>=1|buff.ancestral_swiftness.up)&glyph.chain_lightning.enabled&active_enemies<3^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Bolt~`(1)^t^N27^T^SEnabled^B^SScript^Sactive_dot.flame_shock>=1&active_enemies>=1^SAbility^Sfire_nova^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFire~`Nova~`(2)^t^t^SName^SEnh:~`AOE^t^^]] )

    storeDefault( 'Ele: Precombat', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SScript^S^SDefault^B^SRelease^N20150916.1^SSpecialization^N262^SActions^T^N1^T^SEnabled^B^SScript^S!buff.lightning_shield.up^SAbility^Slightning_shield^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLightning~`Shield^t^N2^T^SEnabled^B^SScript^Stoggle.cooldowns^SArgs^Sname=draenic_intellect^SAbility^Spotion^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SPotion^t^t^SName^SEle:~`Precombat^t^^]] )

    storeDefault( 'Ele: Default', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SDefault^B^SName^SEle:~`Default^SRelease^N20150916.1^SSpecialization^N262^SActions^T^N1^T^SEnabled^B^SScript^Stoggle.interrupts^SAbility^Swind_shear^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SWind~`Shear^t^N2^T^SEnabled^b^SScript^Stoggle.cooldowns&(target.health.pct<25|time>0.500)^SAbility^Sbloodlust^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SHeroism^t^N3^T^SEnabled^B^SScript^Stoggle.cooldowns&(buff.ascendance.up|target.time_to_die<=30)^SArgs^Sname=draenic_intellect^SAbility^Spotion^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SPotion^t^N4^T^SEnabled^B^SScript^Stoggle.cooldowns&(!buff.bloodlust.up&!buff.elemental_mastery.up&buff.ascendance.cooldown_remains=0&(dot.flame_shock.remains>buff.ascendance.duration|level<87))^SAbility^Sberserking^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SBerserking^t^N5^T^SEnabled^B^SScript^Stoggle.cooldowns&(buff.bloodlust.up|buff.ascendance.up|((cooldown.ascendance.remains>10|level<87)&cooldown.fire_elemental_totem.remains>10))^SAbility^Sblood_fury^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SBlood~`Fury^t^N6^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sarcane_torrent^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SArcane~`Torrent^t^N7^T^SEnabled^B^SScript^Stoggle.cooldowns&(action.lava_burst.cast_time>=1.2)^SAbility^Selemental_mastery^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SElemental~`Mastery^t^N8^T^SEnabled^B^SScript^S!buff.ascendance.up^SAbility^Sancestral_swiftness^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SAncestral~`Swiftness^t^N9^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sstorm_elemental_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SStorm~`Elemental~`Totem^t^N10^T^SEnabled^B^SScript^Stoggle.cooldowns&(!active)^SAbility^Sfire_elemental_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFire~`Elemental~`Totem^t^N11^T^SEnabled^B^SScript^Stoggle.cooldowns&(my_enemies>1|(dot.flame_shock.remains>buff.ascendance.duration&(target.time_to_die<20|buff.bloodlust.up|buff.berserking.up|time>=60)&cooldown.lava_burst.remains>0))^SAbility^Sascendance^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SAscendance^t^N12^T^SEnabled^B^SScript^Stoggle.magma&(pet.searing_totem.remains>=15|pet.fire_elemental_totem.remains>=15)^SAbility^Sliquid_magma^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLiquid~`Magma^t^N13^T^SEnabled^B^SScript^Smy_enemies>(2+t18_class_trinket)^SArgs^Sname="Ele:~`AOE"^SAbility^Scall_action_list^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SCall~`Action~`List^t^N14^T^SEnabled^B^SName^SCall~`Action~`List~`(1)^SArgs^Sname="Ele:~`Single"^SAbility^Scall_action_list^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^t^SScript^S^t^^]] )

    storeDefault( 'Ele: Single', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SScript^S^SDefault^B^SRelease^N20150916.1^SSpecialization^N262^SActions^T^N1^T^SEnabled^B^SScript^Smoving^SArgs^S^SAbility^Sunleash_flame^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SUnleash~`Flame^t^N2^T^SEnabled^B^SScript^Smoving&(buff.ascendance.up)^SArgs^S^SAbility^Sspiritwalkers_grace^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SSpiritwalker's~`Grace^t^N3^T^SEnabled^B^SScript^Sbuff.lightning_shield.react=buff.lightning_shield.max_stack^SAbility^Searth_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SEarth~`Shock^t^N4^T^SEnabled^B^SScript^S(talent.elemental_fusion.enabled&buff.elemental_fusion.stack=2&buff.unleash_flame.up&dot.flame_shock.remains<(dot.flame_shock.duration*(0.3+t18_class_trinket*(0.48+talent.unleashed_fury.i_enabled*0.22))))^SArgs^S^SAbility^Sflame_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFlame~`Shock^t^N5^T^SEnabled^B^SScript^S(talent.elemental_fusion.enabled&buff.elemental_fusion.stack=2&buff.unleash_flame.up&dot.flame_shock.remains<(dot.flame_shock.duration*(0.3+t18_class_trinket*(0.48+talent.unleashed_fury.i_enabled*0.22))))^SArgs^Scycle_targets=1^SAbility^Sflame_shock^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SFlame~`Shock~`(1)^t^N6^T^SEnabled^B^SScript^Sdot.flame_shock.remains>cast_time&(buff.ascendance.up|cooldown_react)^SAbility^Slava_burst^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SLava~`Burst^t^N7^T^SEnabled^B^SScript^S(set_bonus.tier17_4pc>0&buff.lightning_shield.react>=12&!buff.lava_surge.up)|(!set_bonus.tier17_4pc>0&buff.lightning_shield.react>15)^SAbility^Searth_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SEarth~`Shock~`(1)^t^N8^T^SEnabled^B^SScript^Sdot.flame_shock.remains<=(dot.flame_shock.duration*0.3)^SArgs^S^SAbility^Sflame_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFlame~`Shock~`(2)^t^N9^T^SEnabled^B^SScript^Sdot.flame_shock.remains<=(dot.flame_shock.duration*0.3)^SArgs^Scycle_targets=1^SAbility^Sflame_shock^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SFlame~`Shock~`(3)^t^N10^T^SEnabled^B^SName^SElemental~`Blast^SAbility^Selemental_blast^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N11^T^SEnabled^B^SScript^Stime>60&remains<=buff.ascendance.duration&cooldown.ascendance.remains+buff.ascendance.duration<duration^SAbility^Sflame_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SFlame~`Shock~`(4)^t^N12^T^SEnabled^B^SScript^S(!talent.liquid_magma.enabled&(!totem.fire.active|(pet.searing_totem.remains<=10&!pet.fire_elemental_totem.active&talent.unleashed_fury.enabled)))|(talent.liquid_magma.enabled&pet.searing_totem.remains<=20&!pet.fire_elemental_totem.active&!buff.liquid_magma.up)^SAbility^Ssearing_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SSearing~`Totem^t^N13^T^SEnabled^B^SScript^Stalent.unleashed_fury.enabled&!buff.ascendance.up|(talent.elemental_fusion.enabled&buff.elemental_fusion.stack=2&(dot.flame_shock.remains)<(dot.flame_shock.duration*(0.3+t18_class_trinket*(0.48+talent.unleashed_fury.i_enabled*0.22)))&cooldown.flame_shock.remains<gcd)^SAbility^Sunleash_flame^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SUnleash~`Flame~`(1)^t^N14^T^SEnabled^B^SScript^Smoving&(((talent.elemental_blast.enabled&cooldown.elemental_blast.remains=0)|(cooldown.lava_burst.remains=0&!buff.lava_surge.up))&cooldown.ascendance.remains>cooldown.spiritwalkers_grace.remains)^SArgs^S^SAbility^Sspiritwalkers_grace^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SSpiritwalker's~`Grace~`(1)^t^N15^T^SEnabled^B^SScript^Sbuff.enhanced_chain_lightning.up^SArgs^S^SAbility^Searthquake^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SEarthquake^t^N16^T^SEnabled^B^SScript^Sbuff.enhanced_chain_lightning.up^SArgs^Scycle_targets=1^SAbility^Searthquake^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SEarthquake~`(1)^t^N17^T^SEnabled^B^SScript^Smy_enemies>=2^SAbility^Schain_lightning^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SChain~`Lightning^t^N18^T^SEnabled^B^SName^SLightning~`Bolt^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N19^T^SEnabled^B^SScript^Smoving^SArgs^S^SAbility^Searth_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SEarth~`Shock~`(2)^t^N20^T^SEnabled^B^SScript^S(!totem.fire.active|(pet.searing_totem.remains<=40&!pet.fire_elemental_totem.active))^SAbility^Ssearing_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SSearing~`Totem~`(1)^t^t^SName^SEle:~`Single^t^^]] )

    storeDefault( 'Ele: AOE', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SName^SEle:~`AOE^SSpecialization^N262^SRelease^N20150916.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Sbuff.enhanced_chain_lightning.up^SArgs^S^SAbility^Searthquake^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SEarthquake^t^N2^T^SEnabled^B^SScript^Sbuff.enhanced_chain_lightning.up^SArgs^Scycle_targets=1^SAbility^Searthquake^SIndicator^Scycle^SRelease^F6923701033084388^f-35^SName^SEarthquake~`(1)^t^N3^T^SEnabled^B^SName^SLava~`Beam^SAbility^Slava_beam^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^N4^T^SEnabled^B^SScript^Sbuff.lightning_shield.react=buff.lightning_shield.max_stack^SAbility^Searth_shock^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SEarth~`Shock^t^N5^T^SEnabled^B^SScript^S(!talent.liquid_magma.enabled&!totem.fire.active)|(talent.liquid_magma.enabled&pet.searing_totem.remains<=20&!pet.fire_elemental_totem.active&!buff.liquid_magma.up)^SAbility^Ssearing_totem^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SSearing~`Totem^t^N6^T^SEnabled^B^SScript^Smy_enemies>=2^SAbility^Schain_lightning^SIndicator^Snone^SRelease^F6923701033084388^f-35^SName^SChain~`Lightning^t^N7^T^SEnabled^B^SName^SLightning~`Bolt^SAbility^Slightning_bolt^SIndicator^Snone^SRelease^F6923701033084388^f-35^t^t^SDefault^B^t^^]] )


    storeDefault( 'Enh: Primary', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPrimary~`Font~`Size^N12^SPrimary~`Caption~`Aura^SMaelstrom~`Weapon^Srel^SCENTER^SUse~`SpellFlash^b^SSpacing^N5^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SEnh:~`Precombat^SName^SEnh:~`Precombat^SRelease^N201506.221^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SEnh:~`Default^SName^SEnh:~`Default^SRelease^N201506.221^t^t^SPvP~`-~`Default~`Alpha^N1^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^N-260^SAOE~`-~`Maximum^N0^SPrimary~`Caption^Sbuff^SRange~`Checking^Sability^SPvE~`-~`Combat~`Alpha^N1^SPvP~`-~`Target~`Alpha^N1^SPvP~`-~`Combat~`Alpha^N1^SPvE~`-~`Target^b^SAction~`Captions^B^SSpecialization^N263^SSpellFlash~`Color^T^Sa^N1^Sb^N1^Sg^N1^Sr^N1^t^SCopy~`To^SEnhancement:~`AOE^SPvP~`-~`Target^b^SQueue~`Direction^SRIGHT^SDefault^B^SQueued~`Icon~`Size^N40^SName^SEnh:~`Primary^SEnabled^B^SFont^SElvUI~`Font^SPrimary~`Icon~`Size^N40^SAOE~`-~`Minimum^N3^Sx^N0^SIcons~`Shown^N4^STalent~`Group^N0^SSingle~`-~`Maximum^N1^SAuto~`-~`Maximum^N0^SPvE~`-~`Target~`Alpha^N1^SAuto~`-~`Minimum^N0^SSingle~`-~`Minimum^N0^SScript^S^SRelease^N20150916.1^SPvE~`-~`Default~`Alpha^N1^SQueue~`Alignment^Sc^t^^]] )

    storeDefault( 'Enh: AOE', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPrimary~`Font~`Size^N12^SPrimary~`Caption~`Aura^SFlame~`Shock^Srel^SCENTER^SUse~`SpellFlash^b^SPvE~`-~`Target^b^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SEnh:~`Precombat^SName^SEnh:~`Precombat^SRelease^N201505.311^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SEnh:~`Default^SName^SEnh:~`Default^SRelease^N201505.311^t^t^SScript^S^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^N-215^Sx^N0^SRelease^N20150916.1^SRange~`Checking^Soff^SPvE~`-~`Combat~`Alpha^N1^SPvP~`-~`Target~`Alpha^N1^SSingle~`-~`Minimum^N3^SPvP~`-~`Default~`Alpha^N1^SPvE~`-~`Default~`Alpha^N1^SPvP~`-~`Combat~`Alpha^N1^SSpellFlash~`Color^T^Sa^N1^Sr^N1^Sg^N1^Sb^N1^t^SCopy~`To^SEnhancement:~`AOE^SPrimary~`Icon~`Size^N40^SQueue~`Direction^SRIGHT^SDefault^B^SQueued~`Icon~`Size^N40^SAuto~`-~`Minimum^N3^SEnabled^B^SPvE~`-~`Target~`Alpha^N1^SAuto~`-~`Maximum^N0^SAOE~`-~`Minimum^N3^SSingle~`-~`Maximum^N0^STalent~`Group^N0^SIcons~`Shown^N4^SSpecialization^N263^SPvP~`-~`Target^b^SFont^SElvUI~`Font^SName^SEnh:~`AOE^SSpacing^N5^SAOE~`-~`Maximum^N0^SPrimary~`Caption^Sratio^SAction~`Captions^B^SQueue~`Alignment^Sc^t^^]] )

    storeDefault( 'Ele: Primary', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPvP~`-~`Target^b^SPrimary~`Caption~`Aura^SLightning~`Shield^Srel^SCENTER^SUse~`SpellFlash^b^SSpacing^N4^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SEle:~`Precombat^SName^SEle:~`Precombat^SRelease^N201506.221^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SEle:~`Default^SName^SEle:~`Default^SRelease^N201506.221^t^t^SScript^S^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^F-4749890768863230^f-44^Sx^N0^SRelease^N20150916.1^SForce~`Targets^N1^SPvE~`-~`Combat~`Alpha^N1^SPrimary~`Icon~`Size^N40^SSingle~`-~`Minimum^N0^SQueue~`Alignment^Sc^SAction~`Captions^B^SPrimary~`Caption^Sbuff^SIcons~`Shown^N4^SSpellFlash~`Color^T^Sa^N1^Sb^N1^Sg^N1^Sr^N1^t^SSpecialization^N262^STalent~`Group^N0^SQueue~`Direction^SRIGHT^SName^SEle:~`Primary^SQueued~`Icon~`Size^N40^SPvE~`-~`Target~`Alpha^N1^SEnabled^B^SPrimary~`Font~`Size^N12^SPvP~`-~`Default~`Alpha^N1^SAOE~`-~`Minimum^N0^SDefault^B^SPvP~`-~`Target~`Alpha^N1^SCopy~`To^Sxxx^SPvE~`-~`Target^b^SAuto~`-~`Maximum^N0^SFont^SElvUI~`Font^SAuto~`-~`Minimum^N0^SSingle~`-~`Maximum^N1^SAOE~`-~`Maximum^N0^SPvP~`-~`Combat~`Alpha^N1^SPvE~`-~`Default~`Alpha^N1^SRange~`Checking^Sability^t^^]] )

    storeDefault( 'Ele: AOE', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPvP~`-~`Target^b^SPrimary~`Caption~`Aura^S^Srel^SCENTER^SPvE~`-~`Target^b^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SEle:~`Precombat^SName^SEle:~`Precombat^SRelease^N201505.311^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SEle:~`Default^SName^SEle:~`Default^SRelease^N201505.311^t^t^SPvP~`-~`Default~`Alpha^N1^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^N-225^SIcons~`Shown^N4^SPrimary~`Caption^Stargets^SForce~`Targets^N3^SAuto~`-~`Maximum^N0^SPvP~`-~`Target~`Alpha^N1^SSingle~`-~`Maximum^N0^SQueue~`Alignment^Sc^SAction~`Captions^B^SRelease^N20150916.1^Sx^N0^SSpellFlash~`Color^T^Sa^N1^Sb^N1^Sg^N1^Sr^N1^t^SSpecialization^N262^SCopy~`To^SEle:~`AOE2^SQueue~`Direction^SRIGHT^SName^SEle:~`AOE^SQueued~`Icon~`Size^N40^SPvE~`-~`Target~`Alpha^N1^SEnabled^B^STalent~`Group^N0^SScript^S^SAOE~`-~`Minimum^N3^SDefault^B^SPrimary~`Icon~`Size^N40^SPrimary~`Font~`Size^N12^SSpacing^N4^SPvE~`-~`Combat~`Alpha^N1^SFont^SElvUI~`Font^SAuto~`-~`Minimum^N3^SSingle~`-~`Minimum^N3^SPvP~`-~`Combat~`Alpha^N1^SAOE~`-~`Maximum^N0^SPvE~`-~`Default~`Alpha^N1^SRange~`Checking^Sability^t^^]] )



  end

end
