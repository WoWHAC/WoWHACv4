# MaxDps_Warrior

## [v10.0.25](https://github.com/kaminaris/MaxDps-Warrior/tree/v10.0.25) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warrior/commits/v10.0.25) [Previous Releases](https://github.com/kaminaris/MaxDps-Warrior/releases)

- Update MaxDps\_Warrior.toc  
