# MaxDps_DeathKnight

## [v10.0.17](https://github.com/kaminaris/MaxDps-DeathKnight/tree/v10.0.17) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-DeathKnight/commits/v10.0.17) [Previous Releases](https://github.com/kaminaris/MaxDps-DeathKnight/releases)

- Update MaxDps\_DeathKnight.toc  
