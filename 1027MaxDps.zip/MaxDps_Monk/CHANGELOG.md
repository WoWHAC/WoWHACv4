# MaxDps_Monk

## [v10.0.14](https://github.com/kaminaris/MaxDps-Monk/tree/v10.0.14) (2024-07-09)
[Full Changelog](https://github.com/kaminaris/MaxDps-Monk/commits/v10.0.14) [Previous Releases](https://github.com/kaminaris/MaxDps-Monk/releases)

- Update MaxDps\_Monk.toc  
- Repo Update  
- Packager Updates  
- Update MaxDps\_Monk.toc  
- Update MaxDps\_Monk.toc  
- Update MaxDps\_Monk.toc  
- Update WIndwalker  
- Update MaxDps\_Monk.toc  
- Update Print  
- Update MaxDps\_Monk.toc  
- Update Mistweaver  
- Update MaxDps\_Monk.toc  
- Update Windwalker  
- Update MaxDps\_Monk.toc  
- Update Brewmaster  
- Update MaxDps\_Monk.toc  
- Update Brewmaster  
- Update MaxDps\_Monk.toc  
- Update Windwalker  
- Update MaxDps\_Monk.toc  
- Update Brewmaster  
- Update MaxDps\_Monk.toc  
- Update Windwalker  
- Update MaxDps\_Monk.toc  
- Update MaxDps\_Monk.toc  
- Update Misweaver  
- Update MaxDps\_Monk.toc  
- Update Brewmaster  
- Merge pull request #3 from doadin/patch-1  
    Update Mistweaver  
- Interface version bump  
- Update Mistweaver  
- v9.0.0 - Brewmaster update  
- v8.3.0 - Interface version bump  
- v8.2.5 - Interface version bump  
- v8.2.1 - Azerite Essences Support  
- v8.2.0 - Brewmaster Fix  
- v8.1.5 - Brewmaster SIMC  
- v8.1.0 - WhirlingDragonPunch talent fixes  
- v8.0.1.2 - BoK, RWJ fixes  
- v8.0.1.1 - Chi Wave Fix  
- v8.0.1 - WW Simcraft update  
- v8.0.0 - Beta WW  
- v7.3.0 - Version bump  
- v7.2.5 - Partial Serenity Support, Compatibility with MaxDps 7.2.5  
- v7.1.0.1 - Hit combo fixes  
- v7.1.0 - Initial windwalker support  
