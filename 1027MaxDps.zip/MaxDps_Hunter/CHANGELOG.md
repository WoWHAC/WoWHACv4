# MaxDps_Hunter

## [v10.0.9](https://github.com/kaminaris/MaxDps-Hunter/tree/v10.0.9) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-Hunter/commits/v10.0.9) [Previous Releases](https://github.com/kaminaris/MaxDps-Hunter/releases)

- Update MaxDps\_Hunter.toc  
