# MaxDps_Warlock

## [v10.0.17](https://github.com/kaminaris/MaxDps-Warlock/tree/v10.0.17) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warlock/commits/v10.0.17) [Previous Releases](https://github.com/kaminaris/MaxDps-Warlock/releases)

- Update MaxDps\_Warlock.toc  
