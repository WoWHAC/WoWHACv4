# MaxDps_Druid

## [v11.1.40](https://github.com/kaminaris/MaxDps-Druid/tree/v11.1.40) (2025-08-17)
[Full Changelog](https://github.com/kaminaris/MaxDps-Druid/compare/v11.1.39...v11.1.40) [Previous Releases](https://github.com/kaminaris/MaxDps-Druid/releases)

- Update MoP Feral  
