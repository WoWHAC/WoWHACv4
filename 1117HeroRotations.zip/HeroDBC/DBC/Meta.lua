HeroDBC.DBC.metaVersion = "11.1.7.61967"
HeroDBC.DBC.metaTime = "2025-07-30T18:51:23.862587"
