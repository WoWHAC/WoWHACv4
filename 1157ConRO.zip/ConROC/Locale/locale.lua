ConROC.Localise = LibStub( "AceLocale-3.0" ):GetLocale( "ConROC" )
