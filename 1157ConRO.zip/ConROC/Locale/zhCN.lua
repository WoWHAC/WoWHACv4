local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "zhCN" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "您当前不知道这里要列出的任何法术或选项。"
