local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "koKR" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "현재 여기에 나열되어야 할 주문이나 옵션을 알지 못합니다."
