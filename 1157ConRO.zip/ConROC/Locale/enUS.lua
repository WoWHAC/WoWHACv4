local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "enUS", true, false )
if not L then return end

	L["NO_SPELLS_TO_LIST"] = "You currently don't know any of the spells or options that is to be listed here."
