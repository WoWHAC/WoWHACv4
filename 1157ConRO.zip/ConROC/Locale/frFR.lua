local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "frFR" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "Vous ne connaissez actuellement aucun des sorts ou options qui doivent être répertoriés ici."
