local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "zhTW" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "您目前不知道此處要列出的任何法術或選項。"
