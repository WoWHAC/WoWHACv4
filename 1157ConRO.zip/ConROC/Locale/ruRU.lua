local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "ruRU" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "В настоящее время у вас нет знания ни одного из заклинаний или опций, которые должны быть здесь перечислены."
