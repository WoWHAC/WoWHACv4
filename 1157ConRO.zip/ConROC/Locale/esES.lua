local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "esES" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "Actualmente no conoces ninguno de los hechizos u opciones que se enumerarán aquí."
