local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "ptBR" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "Você atualmente não conhece nenhum dos feitiços ou opções que devem ser listados aqui."
