# MaxDps_Rogue

## [v11.1.20](https://github.com/kaminaris/MaxDps-Rogue/tree/v11.1.20) (2025-07-29)
[Full Changelog](https://github.com/kaminaris/MaxDps-Rogue/compare/v11.1.19...v11.1.20) [Previous Releases](https://github.com/kaminaris/MaxDps-Rogue/releases)

- Update All MoP  
