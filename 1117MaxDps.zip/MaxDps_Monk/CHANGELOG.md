# MaxDps_Monk

## [v11.1.15](https://github.com/kaminaris/MaxDps-Monk/tree/v11.1.15) (2025-08-06)
[Full Changelog](https://github.com/kaminaris/MaxDps-Monk/compare/v11.1.14...v11.1.15) [Previous Releases](https://github.com/kaminaris/MaxDps-Monk/releases)

- Update Retail WW  
- Update Retail Mist  
- Update Retail BM  
