# MaxDps_Warlock

## [v11.1.22](https://github.com/kaminaris/MaxDps-Warlock/tree/v11.1.22) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warlock/compare/v11.1.21...v11.1.22) [Previous Releases](https://github.com/kaminaris/MaxDps-Warlock/releases)

- Update Retail Destruction  
- Update Retail Affliction  
- Update Retail Destruction  
- Update Retail Affliction  
- Update Retail Demo  
