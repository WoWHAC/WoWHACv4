# MaxDps_Shaman

## [v11.1.23](https://github.com/kaminaris/MaxDps-Shaman/tree/v11.1.23) (2025-08-04)
[Full Changelog](https://github.com/kaminaris/MaxDps-Shaman/compare/v11.1.22...v11.1.23) [Previous Releases](https://github.com/kaminaris/MaxDps-Shaman/releases)

- Update MoP Elemental  
- Update .luacheckrc  
