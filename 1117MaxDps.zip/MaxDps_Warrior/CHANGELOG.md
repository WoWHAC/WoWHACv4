# MaxDps_Warrior

## [v11.1.24](https://github.com/kaminaris/MaxDps-Warrior/tree/v11.1.24) (2025-08-07)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warrior/compare/v11.1.23...v11.1.24) [Previous Releases](https://github.com/kaminaris/MaxDps-Warrior/releases)

- Update MoP Fury  
- Update MoP Arms  
