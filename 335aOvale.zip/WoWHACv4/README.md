# WoWHACv4 addon | Compatibility with Hekili and MaxDPS
Addon for World of Warcraft that encrypts the recommended ability to click into a pixel for further reading by external software
https://wowhac.fun/
