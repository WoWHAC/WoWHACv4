# [2.18.4](https://github.com/WeakAuras/WeakAuras2/tree/2.18.4) (2020-09-04)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.18.3...2.18.4)

## Highlights

 - Update lib 

## Commits

Stanzilla (1):

- Ignore .DS_Store

