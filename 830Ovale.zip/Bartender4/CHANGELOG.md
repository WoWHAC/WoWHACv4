# Bartender4

## [4.9.0](https://github.com/Nevcairiel/Bartender4/tree/4.9.0) (2020-01-27)
[Full Changelog](https://github.com/Nevcairiel/Bartender4/compare/4.8.9...4.9.0)

- Update TOC for 8.3  
- Update Pet Bar on PLAYER\_MOUNT\_DISPLAY\_CHANGED and PLAYER\_TARGET\_CHANGED  
    The default UI updates the pet bar on these events, so make sure we  
    follow suit  
- Update the pet bar on PET\_BAR\_UPDATE\_USABLE  
    Max fix issue #11  
