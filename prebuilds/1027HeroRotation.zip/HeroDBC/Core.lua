--- ============================ HEADER ============================
--- ======= LOCALIZE =======
-- Addon
local addonName, HDBC = ...

--- ======= GLOBALIZE =======
HeroDBC = HDBC
HDBC.DBC = {}
