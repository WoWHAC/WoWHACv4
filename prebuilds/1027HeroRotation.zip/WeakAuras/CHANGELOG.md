# [5.15.4](https://github.com/WeakAuras/WeakAuras2/tree/5.15.4) (2024-07-27)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/5.15.3...5.15.4)

## Highlights

 - Class and Specialzation triggers now support class/spec conditions 

## Commits

Boneshock (1):

- fix error when creating new reputation trigger

InfusOnWoW (6):

- Class and Specialization Trigger: Add condition for class/spec
- Triggers: Don't set state.icon if the icon is unknown
- Model Sub Element: Fix model frame level
- Model+Model Sub Element: Remove model_path
- Model Sub Element: Fix Model option
- Fix custom text function returning a table leading to a lua error

mrbuds (3):

- Fix transmission of auras
- submodel: change default on classic for an existing model
- Model: change default on classic for an existing model

