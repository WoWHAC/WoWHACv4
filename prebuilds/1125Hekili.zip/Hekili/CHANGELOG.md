# Hekili

## [v11.2.0-1.0.1h](https://github.com/Hekili/hekili/tree/v11.2.0-1.0.1h) (2025-09-13)
[Full Changelog](https://github.com/Hekili/hekili/compare/v11.2.0-1.0.1g...v11.2.0-1.0.1h) [Previous Releases](https://github.com/Hekili/hekili/releases)

- Merge pull request #5308 from joshjau/ret-cleanup  
    ret: removed fading light  
- Merge pull request #5311 from syrifgit/beast-apl  
    BM APL Update  
- Merge pull request #5313 from syrifgit/windwalker-i-guess  
    WW Tweaks  
- Merge pull request #5314 from syrifgit/drood  
    Guardian: Remove usable restrictions on defensives  
- Merge pull request #5315 from syrifgit/weave-more-storms  
    Support Stormweaver pvptalent  
- Merge pull request #5316 from syrifgit/low-level-user-warning  
    Low Level Warning Tweak  
- Merge pull request #5317 from johnnylam88/fix/reshii-wraps  
    fix: add tank-specialization damage absorb buffs from Reshii Wraps  
- fix: add tank-specialization damage absorb buffs from Reshii Wraps  
- Low Level Warning Tweak  
    Be more clear/explicit about the intended use.  
    Redo of https://github.com/Hekili/hekili/pull/5057, dropped the incomplete spec part for now.  
- Addstacks too  
- Support Stormweaver pvptalent  
    Redo of https://github.com/Hekili/hekili/pull/4932  
- Guardian: Remove usable restrictions on defensives  
    All of these abilities are already handled by the APL in terms of tanking, damage taken, etc. No reason to restrict them in the LUA and prevent user APL customization.  
    Fixes https://github.com/Hekili/hekili/issues/5223  
- pls stop changing the APL thanks  
- BM Withering Fire Updates  
- WW Updates  
- Update PaladinRetribution.lua  
- wowhead link cleanup.  
- ret: removed fading light  
    Patch 11.0.5 (2024-10-22): Removed.  
