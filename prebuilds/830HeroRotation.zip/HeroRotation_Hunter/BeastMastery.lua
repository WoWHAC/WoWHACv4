--- ============================ HEADER ============================
--- ======= LOCALIZE =======
-- Addon
local addonName, addonTable = ...
-- HeroLib
local HL         = HeroLib
local Cache      = HeroCache
local Unit       = HL.Unit
local Player     = Unit.Player
local Target     = Unit.Target
local Pet        = Unit.Pet
local Spell      = HL.Spell
local MultiSpell = HL.MultiSpell
local Item       = HL.Item
-- HeroRotation
local HR         = HeroRotation
-- Lua
local mathmax    = math.max;
-- Azerite Essence Setup
local AE         = HL.Enum.AzeriteEssences
local AESpellIDs = HL.Enum.AzeriteEssenceSpellIDs

--- ============================ CONTENT ===========================
--- ======= APL LOCALS =======
-- luacheck: max_line_length 9999

-- Spells
if not Spell.Hunter then Spell.Hunter = {} end
Spell.Hunter.BeastMastery = {
  -- Pet Care Abilities
  SummonPet                             = Spell(883),
  SummonPet2                            = Spell(83242),
  SummonPet3                            = Spell(83243),
  SummonPet4                            = Spell(83244),
  SummonPet5                            = Spell(83245),
  MendPet                               = Spell(136),
  RevivePet                             = Spell(982),
  -- Player Abilities
  AnimalCompanion                       = Spell(267116),
  AspectoftheWildBuff                   = Spell(193530),
  AspectoftheWild                       = Spell(193530),
  PrimalInstinctsBuff                   = Spell(279810),
  PrimalInstincts                       = Spell(279806),
  BestialWrathBuff                      = Spell(19574),
  BestialWrathPetBuff                   = Spell(186254),
  BestialWrath                          = Spell(19574),
  AncestralCall                         = Spell(274738),
  Fireblood                             = Spell(265221),
  Berserking                            = Spell(26297),
  BerserkingBuff                        = Spell(26297),
  KillerInstinct                        = Spell(273887),
  BloodFury                             = Spell(20572),
  BloodFuryBuff                         = Spell(20572),
  LightsJudgment                        = Spell(255647),
  BagofTricks                           = Spell(312411),
  FrenzyBuff                            = Spell(272790),
  BarbedShot                            = Spell(217200),
  Multishot                             = Spell(2643),
  BeastCleaveBuff                       = Spell(118455, "pet"),
  BeastCleavePlayerBuff                 = Spell(268877),
  Stampede                              = Spell(201430),
  ChimaeraShot                          = Spell(53209),
  AMurderofCrows                        = Spell(131894),
  Barrage                               = Spell(120360),
  KillCommand                           = Spell(34026),
  RapidReload                           = Spell(278530),
  DireBeast                             = Spell(120679),
  CobraShot                             = Spell(193455),
  SpittingCobra                         = Spell(194407),
  OneWithThePack                        = Spell(199528),
  Intimidation                          = Spell(19577),
  CounterShot                           = Spell(147362),
  Exhilaration                          = Spell(109304),
  RazorCoralDebuff                      = Spell(303568),
  DanceofDeath                          = Spell(274441),
  DanceofDeathBuff                      = Spell(274443),
  -- Essences
  BloodoftheEnemy                       = Spell(297108),
  MemoryofLucidDreams                   = Spell(298357),
  PurifyingBlast                        = Spell(295337),
  RippleInSpace                         = Spell(302731),
  ConcentratedFlame                     = Spell(295373),
  TheUnboundForce                       = Spell(298452),
  WorldveinResonance                    = Spell(295186),
  FocusedAzeriteBeam                    = Spell(295258),
  GuardianofAzeroth                     = Spell(295840),
  GuardianofAzerothBuff                 = Spell(295855),
  ReapingFlames                         = Spell(310690),
  LifebloodBuff                         = MultiSpell(295137, 305694),
  RecklessForceCounter                  = MultiSpell(298409, 302917),
  RecklessForceBuff                     = Spell(302932),
  ConcentratedFlameBurn                 = Spell(295368),
  -- Misc
  PoolFocus                             = Spell(9999000010),
};
local S = Spell.Hunter.BeastMastery;

-- Items
if not Item.Hunter then Item.Hunter = {} end
Item.Hunter.BeastMastery = {
  PotionofUnbridledFury            = Item(169299),
  GalecallersBoon                  = Item(159614, {13, 14}),
  PocketsizedComputationDevice     = Item(167555, {13, 14}),
  AshvanesRazorCoral               = Item(169311, {13, 14}),
  AzsharasFontofPower              = Item(169314, {13, 14})
};
local I = Item.Hunter.BeastMastery;

-- Create table to exclude above trinkets from On Use function
local OnUseExcludes = {
  I.GalecallersBoon:ID(),
  I.PocketsizedComputationDevice:ID(),
  I.AshvanesRazorCoral:ID(),
  I.AzsharasFontofPower:ID()
}

-- Rotation Var
local ShouldReturn; -- Used to get the return string
local EnemiesCount, GCDMax;

-- GUI Settings
local Everyone = HR.Commons.Everyone
local Hunter = HR.Commons.Hunter
local Settings = {
  General = HR.GUISettings.General,
  Commons = HR.GUISettings.APL.Hunter.Commons,
  BeastMastery = HR.GUISettings.APL.Hunter.BeastMastery
};

-- Stuns
local StunInterrupts = {
  {S.Intimidation, "Cast Intimidation (Interrupt)", function () return true; end},
};

-- Pet Spells
local SummonPetSpells = {
  S.SummonPet,
  S.SummonPet2,
  S.SummonPet3,
  S.SummonPet4,
  S.SummonPet5
}

local EnemyRanges = {40}
local function UpdateRanges()
  for _, i in ipairs(EnemyRanges) do
    HL.GetEnemies(i);
  end
end

local function GetEnemiesCount(range)
  -- Unit Update - Update differently depending on if splash data is being used
  if HR.AoEON() then
    if Settings.BeastMastery.UseSplashData then
      HL.GetEnemies(range, nil, true, Target)
      return Cache.EnemiesCount[range]
    else
      UpdateRanges()
      Everyone.AoEToggleEnemiesUpdate()
      return Cache.EnemiesCount[40]
    end
  else
    return 1
  end
end

local function UpdateGCDMax()
  -- GCD Max + Latency Grace Period
  -- BM APL uses a lot of gcd.max specific timing that is slightly tight for real-world suggestions
  GCDMax = Player:GCD() + 0.150
  -- Aspect of the Wild reduces GCD by 0.2s, before Haste modifiers are applied, reduce the benefit since Haste is applied in Player:GCD()
  if Player:BuffP(S.AspectoftheWildBuff) then
    GCDMax = mathmax(0.75, GCDMax - 0.2 / (1 + Player:HastePct() / 100))
  end
end

HL:RegisterForEvent(function()
  S.ConcentratedFlame:RegisterInFlight();
end, "LEARNED_SPELL_IN_TAB")
S.ConcentratedFlame:RegisterInFlight()

local function num(val)
  if val then return 1 else return 0 end
end

local function bool(val)
  return val ~= 0
end

-- target_if=min:dot.barbed_shot.remains
local function EvaluateTargetIfFilterBarbedShot74(TargetUnit)
  return TargetUnit:DebuffRemainsP(S.BarbedShot)
end

-- if=pet.turtle.buff.frenzy.up&pet.turtle.buff.frenzy.remains<=gcd.max
local function EvaluateTargetIfBarbedShot75(TargetUnit)
  return (Pet:BuffP(S.FrenzyBuff) and Pet:BuffRemainsP(S.FrenzyBuff) <= GCDMax)
end

-- if=full_recharge_time<gcd.max&cooldown.bestial_wrath.remains
local function EvaluateTargetIfBarbedShot85(TargetUnit)
  return (S.BarbedShot:FullRechargeTimeP() < GCDMax and bool(S.BestialWrath:CooldownRemainsP()))
end

-- if=pet.turtle.buff.frenzy.down&(charges_fractional>1.8|buff.bestial_wrath.up)|cooldown.aspect_of_the_wild.remains<pet.turtle.buff.frenzy.duration-gcd&azerite.primal_instincts.enabled|charges_fractional>1.4|target.time_to_die<9
local function EvaluateTargetIfBarbedShot123(TargetUnit)
  return (Pet:BuffDownP(S.FrenzyBuff) and (S.BarbedShot:ChargesFractionalP() > 1.8 or Player:BuffP(S.BestialWrathBuff))
    or S.AspectoftheWild:CooldownRemainsP() < S.FrenzyBuff:BaseDuration() - GCDMax and S.PrimalInstincts:AzeriteEnabled()
    or S.BarbedShot:ChargesFractionalP() > 1.4 or Target:BossTimeToDie() < 9)
end

local function Precombat()
  -- flask
  -- augmentation
  -- food
  -- summon_pet
  -- snapshot_stats
  if Everyone.TargetIsValid() then
    -- use_item,name=azsharas_font_of_power
    if I.AzsharasFontofPower:IsEquipReady() and Settings.Commons.UseTrinkets then
      if HR.Cast(I.AzsharasFontofPower, nil, Settings.Commons.TrinketDisplayStyle) then return "azsharas_font_of_power"; end
    end
    -- worldvein_resonance
    if S.WorldveinResonance:IsCastableP() then
      if HR.Cast(S.WorldveinResonance, nil, Settings.Commons.EssenceDisplayStyle) then return "worldvein_resonance"; end
    end
    -- guardian_of_azeroth
    if S.GuardianofAzeroth:IsCastableP() then
      if HR.Cast(S.GuardianofAzeroth, nil, Settings.Commons.EssenceDisplayStyle) then return "guardian_of_azeroth"; end
    end
    -- memory_of_lucid_dreams
    if S.MemoryofLucidDreams:IsCastableP() then
      if HR.Cast(S.MemoryofLucidDreams, nil, Settings.Commons.EssenceDisplayStyle) then return "memory_of_lucid_dreams"; end
    end
    -- use_item,effect_name=cyclotronic_blast,if=!raid_event.invulnerable.exists&(trinket.1.has_cooldown+trinket.2.has_cooldown<2|equipped.variable_intensity_gigavolt_oscillating_reactor)
    -- Needs to be updated to the 2nd half of the condition
    if Everyone.CyclotronicBlastReady() and Settings.Commons.UseTrinkets then
      if HR.Cast(I.PocketsizedComputationDevice, nil, Settings.Commons.TrinketDisplayStyle, 40) then return "cyclotronic_blast precombat"; end
    end
    -- focused_azerite_beam,if=!raid_event.invulnerable.exists
    if S.FocusedAzeriteBeam:IsCastableP() then
      if HR.Cast(S.FocusedAzeriteBeam, nil, Settings.Commons.EssenceDisplayStyle) then return "focused_azerite_beam"; end
    end
    -- aspect_of_the_wild,precast_time=1.3,if=!azerite.primal_instincts.enabled&!essence.essence_of_the_focusing_iris.major&(equipped.azsharas_font_of_power|!equipped.cyclotronic_blast)
    if S.AspectoftheWild:IsCastableP() and HR.CDsON() and (not S.PrimalInstincts:AzeriteEnabled() and not Spell:MajorEssenceEnabled(AE.EssenceoftheFocusingIris) and (I.AzsharasFontofPower:IsEquipped() or not Everyone.PSCDEquipped())) then
      if HR.Cast(S.AspectoftheWild, Settings.BeastMastery.GCDasOffGCD.AspectoftheWild) then return "aspect_of_the_wild 8"; end
    end
    -- bestial_wrath,precast_time=1.5,if=azerite.primal_instincts.enabled&!essence.essence_of_the_focusing_iris.major&(equipped.azsharas_font_of_power|!equipped.cyclotronic_blast)
    if S.BestialWrath:IsCastableP() and HR.CDsON() and (S.PrimalInstincts:AzeriteEnabled() and not Spell:MajorEssenceEnabled(AE.EssenceoftheFocusingIris) and (I.AzsharasFontofPower:IsEquipped() or not Everyone.PSCDEquipped())) then
      if HR.Cast(S.BestialWrath, Settings.BeastMastery.GCDasOffGCD.BestialWrath) then return "bestial_wrath 16"; end
    end
    -- potion
    if I.PotionofUnbridledFury:IsReady() and Settings.Commons.UsePotions then
      if HR.CastSuggested(I.PotionofUnbridledFury) then return "battle_potion_of_agility 6"; end
    end
  end
end

local function Cds()
  -- ancestral_call,if=cooldown.bestial_wrath.remains>30
  if S.AncestralCall:IsCastableP() and (S.BestialWrath:CooldownRemainsP() > 30) then
    if HR.Cast(S.AncestralCall, Settings.Commons.OffGCDasOffGCD.Racials) then return "ancestral_call 24"; end
  end
  -- fireblood,if=cooldown.bestial_wrath.remains>30
  if S.Fireblood:IsCastableP() and (S.BestialWrath:CooldownRemainsP() > 30) then
    if HR.Cast(S.Fireblood, Settings.Commons.OffGCDasOffGCD.Racials) then return "fireblood 28"; end
  end
  -- blood_of_the_enemy,if=focus<focus.max&(raid_event.adds.remains>90|!raid_event.adds.exists|active_enemies>1)
  if S.BloodoftheEnemy:IsCastableP() and (Player:FocusPredicted() < Player:FocusMax()) then
    if HR.Cast(S.BloodoftheEnemy, Settings.Commons.OffGCDasOffGCD.Racials) then return "blood_of_the_enemy 30"; end
  end
  -- berserking,if=buff.aspect_of_the_wild.up&(target.time_to_die>cooldown.berserking.duration+duration|(target.health.pct<35|!talent.killer_instinct.enabled))|target.time_to_die<13
  if S.Berserking:IsCastableP() and (Player:BuffP(S.AspectoftheWildBuff) and (Target:BossTimeToDie() > 180 + S.BerserkingBuff:BaseDuration() or (Target:HealthPercentage() < 35 or not S.KillerInstinct:IsAvailable())) or Target:BossTimeToDie() < 13) then
    if HR.Cast(S.Berserking, Settings.Commons.OffGCDasOffGCD.Racials) then return "berserking 32"; end
  end
  -- blood_fury,if=buff.aspect_of_the_wild.up&(target.time_to_die>cooldown.blood_fury.duration+duration|(target.health.pct<35|!talent.killer_instinct.enabled))|target.time_to_die<16
  if S.BloodFury:IsCastableP() and (Player:BuffP(S.AspectoftheWildBuff) and (Target:BossTimeToDie() > 120 + S.BloodFuryBuff:BaseDuration() or (Target:HealthPercentage() < 35 or not S.KillerInstinct:IsAvailable())) or Target:BossTimeToDie() < 16) then
    if HR.Cast(S.BloodFury, Settings.Commons.OffGCDasOffGCD.Racials) then return "blood_fury 46"; end
  end
  -- lights_judgment,if=pet.turtle.buff.frenzy.up&pet.turtle.buff.frenzy.remains>gcd.max|!pet.turtle.buff.frenzy.up
  if S.LightsJudgment:IsCastableP() and (Pet:BuffRemainsP(S.FrenzyBuff) > GCDMax or Pet:BuffDownP(S.FrenzyBuff)) then
    if HR.Cast(S.LightsJudgment, Settings.Commons.OffGCDasOffGCD.Racials, nil, 40) then return "lights_judgment 60"; end
  end
  -- potion,if=buff.bestial_wrath.up&buff.aspect_of_the_wild.up&target.health.pct<35|((consumable.potion_of_unbridled_fury|consumable.unbridled_fury)&target.time_to_die<61|target.time_to_die<26)
  if Settings.Commons.UsePotions and I.PotionofUnbridledFury:IsReady() and (Player:BuffP(S.BestialWrathBuff) and Player:BuffP(S.AspectoftheWildBuff) and Target:HealthPercentage() < 35 or Target:BossTimeToDie() < 61) then
    if HR.CastSuggested(I.PotionofUnbridledFury) then return "battle_potion_of_agility 68"; end
  end
  -- worldvein_resonance,if=(prev_gcd.1.aspect_of_the_wild|cooldown.aspect_of_the_wild.remains<gcd|target.time_to_die<20)|!essence.vision_of_perfection.minor
  if S.WorldveinResonance:IsCastableP() and ((Player:PrevGCDP(1, S.AspectoftheWild) or S.AspectoftheWild:CooldownRemainsP() < Player:GCD() or Target:BossTimeToDie() < 20) or not Spell:EssenceEnabled(AE.VisionofPerfection)) then
    if HR.Cast(S.WorldveinResonance, nil, Settings.Commons.EssenceDisplayStyle) then return "worldvein_resonance"; end
  end
  -- guardian_of_azeroth,if=cooldown.aspect_of_the_wild.remains<10|target.time_to_die>cooldown+duration|target.time_to_die<30
  if S.GuardianofAzeroth:IsCastableP() and (S.AspectoftheWild:CooldownRemainsP() < 10 or Target:BossTimeToDie() > 210 or Target:BossTimeToDie() < 30) then
    if HR.Cast(S.GuardianofAzeroth, nil, Settings.Commons.EssenceDisplayStyle) then return "guardian_of_azeroth"; end
  end
  -- ripple_in_space
  if S.RippleInSpace:IsCastableP() then
    if HR.Cast(S.RippleInSpace, nil, Settings.Commons.EssenceDisplayStyle) then return "ripple_in_space"; end
  end
  -- memory_of_lucid_dreams
  if S.MemoryofLucidDreams:IsCastableP() then
    if HR.Cast(S.MemoryofLucidDreams, nil, Settings.Commons.EssenceDisplayStyle) then return "memory_of_lucid_dreams"; end
  end
  -- reaping_flames,if=target.health.pct>80|target.health.pct<=20|target.time_to_pct_20>30
  ShouldReturn = Everyone.ReapingFlamesCast(Settings.Commons.EssenceDisplayStyle);
  if ShouldReturn then return ShouldReturn; end
end

local function Cleave()
  -- barbed_shot,target_if=min:dot.barbed_shot.remains,if=pet.turtle.buff.frenzy.up&pet.turtle.buff.frenzy.remains<=gcd.max
  if S.BarbedShot:IsCastableP() then
    if HR.CastTargetIf(S.BarbedShot, 40, "min", EvaluateTargetIfFilterBarbedShot74, EvaluateTargetIfBarbedShot75) then return "barbed_shot 76"; end
    if EvaluateTargetIfBarbedShot75(Target) then
      if HR.Cast(S.BarbedShot, nil, nil, 40) then return "barbed_shot 76 fallback"; end
  end
  end
  -- barbed_shot,target_if=min:dot.barbed_shot.remains,if=full_recharge_time<gcd.max&cooldown.bestial_wrath.remains
  -- NOTE: Moved TargetIf logic above the Beast Cleave refresh to avoid flickering. This is a 0 DPS loss according to SimC.
  if S.BarbedShot:IsCastableP() then
    if HR.CastTargetIf(S.BarbedShot, 40, "min", EvaluateTargetIfFilterBarbedShot74, EvaluateTargetIfBarbedShot85) then return "barbed_shot 86"; end
    if EvaluateTargetIfBarbedShot85(Target) then
      if HR.Cast(S.BarbedShot, nil, nil, 40) then return "barbed_shot 86 fallback"; end
  end
  end
  -- multishot,if=gcd.max-pet.turtle.buff.beast_cleave.remains>0.25
  -- Check both the player and pet buffs since the pet buff can be impacted by latency
  if S.Multishot:IsReadyP() and Pet:BuffRemainsP(S.BeastCleaveBuff) < GCDMax then
    if HR.Cast(S.Multishot, nil, nil, 40) then return "multishot 82"; end
  end
  -- aspect_of_the_wild
  if S.AspectoftheWild:IsCastableP() and HR.CDsON() then
    if HR.Cast(S.AspectoftheWild, Settings.BeastMastery.GCDasOffGCD.AspectoftheWild) then return "aspect_of_the_wild 94"; end
  end
  -- stampede,if=buff.aspect_of_the_wild.up&buff.bestial_wrath.up|target.time_to_die<15
  if S.Stampede:IsCastableP() and (Player:BuffP(S.AspectoftheWildBuff) and Player:BuffP(S.BestialWrathBuff) or Target:BossTimeToDie() < 15) then
    if HR.Cast(S.Stampede, Settings.BeastMastery.GCDasOffGCD.Stampede, nil, 30) then return "stampede 96"; end
  end
  -- bestial_wrath,if=cooldown.aspect_of_the_wild.remains>20|talent.one_with_the_pack.enabled|target.time_to_die<15
  if S.BestialWrath:IsCastableP() and HR.CDsON() and (S.AspectoftheWild:CooldownRemainsP() > 20 or S.OneWithThePack:IsAvailable() or Target:BossTimeToDie() < 15) then
    if HR.Cast(S.BestialWrath, Settings.BeastMastery.GCDasOffGCD.BestialWrath) then return "bestial_wrath 102"; end
  end
  -- chimaera_shot
  if S.ChimaeraShot:IsCastableP() then
    if HR.Cast(S.ChimaeraShot, nil, nil, 40) then return "chimaera_shot 106"; end
  end
  -- a_murder_of_crows
  if S.AMurderofCrows:IsReadyP() then
    if HR.Cast(S.AMurderofCrows, Settings.BeastMastery.GCDasOffGCD.AMurderofCrows, nil, 40) then return "a_murder_of_crows 108"; end
  end
  -- barrage
  if S.Barrage:IsReadyP() then
    if HR.Cast(S.Barrage, nil, nil, 40) then return "barrage 110"; end
  end
  -- kill_command,if=active_enemies<4|!azerite.rapid_reload.enabled
  if S.KillCommand:IsReadyP() and (EnemiesCount < 4 or not S.RapidReload:AzeriteEnabled()) then
    if HR.Cast(S.KillCommand, nil, nil, 50) then return "kill_command 112"; end
  end
  -- dire_beast
  if S.DireBeast:IsReadyP() then
    if HR.Cast(S.DireBeast, nil, nil, 40) then return "dire_beast 122"; end
  end
  -- barbed_shot,target_if=min:dot.barbed_shot.remains,if=pet.turtle.buff.frenzy.down&(charges_fractional>1.8|buff.bestial_wrath.up)|cooldown.aspect_of_the_wild.remains<pet.turtle.buff.frenzy.duration-gcd&azerite.primal_instincts.enabled|charges_fractional>1.4|target.time_to_die<9
  if S.BarbedShot:IsCastableP() then
    if HR.CastTargetIf(S.BarbedShot, 40, "min", EvaluateTargetIfFilterBarbedShot74, EvaluateTargetIfBarbedShot123) then return "barbed_shot 124"; end
    if EvaluateTargetIfBarbedShot123(Target) then
      if HR.Cast(S.BarbedShot, nil, nil, 40) then return "barbed_shot 124 fallback"; end
  end
  end
  -- focused_azerite_beam
  if S.FocusedAzeriteBeam:IsCastableP() then
    if HR.Cast(S.FocusedAzeriteBeam, nil, Settings.Commons.EssenceDisplayStyle) then return "focused_azerite_beam 126"; end
  end
  -- purifying_blast
  if S.PurifyingBlast:IsCastableP() then
    if HR.Cast(S.PurifyingBlast, nil, Settings.Commons.EssenceDisplayStyle, 40) then return "purifying_blast 128"; end
  end
  -- concentrated_flame
  if S.ConcentratedFlame:IsCastableP() then
    if HR.Cast(S.ConcentratedFlame, nil, Settings.Commons.EssenceDisplayStyle, 40) then return "concentrated_flame 130"; end
  end
  -- the_unbound_force,if=buff.reckless_force.up|buff.reckless_force_counter.stack<10
  if S.TheUnboundForce:IsCastableP() and (Player:BuffP(S.RecklessForceBuff) or Player:BuffStackP(S.RecklessForceCounter) < 10) then
    if HR.Cast(S.TheUnboundForce, nil, Settings.Commons.EssenceDisplayStyle, 40) then return "the_unbound_force 134"; end
  end
  -- multishot,if=azerite.rapid_reload.enabled&active_enemies>2
  if S.Multishot:IsCastableP() and (S.RapidReload:AzeriteEnabled() and EnemiesCount > 2) then
    if HR.CastPooling(S.Multishot, nil, 40) then return "multishot 140"; end
  end
  -- NOTE: Experimental line here for non-RR builds. SimC seems to show this as a gain. Submitted for consideration.
  -- multishot,if=cooldown.kill_command.remains>focus.time_to_max&active_enemies>8
  if S.Multishot:IsCastableP() and (S.KillCommand:CooldownRemainsP() > Player:FocusTimeToMaxPredicted() and EnemiesCount > 8) then
    if HR.CastPooling(S.Multishot, nil, 40) then return "multishot focus dump"; end
  end
  -- cobra_shot,if=cooldown.kill_command.remains>focus.time_to_max&(active_enemies<3|!azerite.rapid_reload.enabled)
  if S.CobraShot:IsCastableP() and (S.KillCommand:CooldownRemainsP() > Player:FocusTimeToMaxPredicted() and (EnemiesCount < 3 or not S.RapidReload:AzeriteEnabled())) then
    if HR.CastPooling(S.CobraShot, nil, 40) then return "cobra_shot 150"; end
  end
  -- spitting_cobra
  if S.SpittingCobra:IsCastableP() then
    if HR.Cast(S.SpittingCobra, Settings.BeastMastery.GCDasOffGCD.SpittingCobra) then return "spitting_cobra 162"; end
  end
end

local function St()
  -- barbed_shot,if=pet.turtle.buff.frenzy.up&pet.turtle.buff.frenzy.remains<gcd|cooldown.bestial_wrath.remains&(full_recharge_time<gcd|azerite.primal_instincts.enabled&cooldown.aspect_of_the_wild.remains<gcd)
  if S.BarbedShot:IsCastableP() and (Pet:BuffP(S.FrenzyBuff) and Pet:BuffRemainsP(S.FrenzyBuff) < GCDMax
    or bool(S.BestialWrath:CooldownRemainsP()) and (S.BarbedShot:FullRechargeTimeP() < GCDMax
    or S.PrimalInstincts:AzeriteEnabled() and S.AspectoftheWild:CooldownRemainsP() < GCDMax)) then
    if HR.Cast(S.BarbedShot, nil, nil, 40) then return "barbed_shot 164"; end
  end
  -- concentrated_flame,if=focus+focus.regen*gcd<focus.max&buff.bestial_wrath.down&(!dot.concentrated_flame_burn.remains&!action.concentrated_flame.in_flight)|full_recharge_time<gcd|target.time_to_die<5
  if S.ConcentratedFlame:IsCastableP() and (Player:FocusPredicted() + Player:FocusRegen() * Player:GCD() < Player:FocusMax() and Player:BuffDownP(S.BestialWrathBuff) and (Target:DebuffDownP(S.ConcentratedFlameBurn) and not S.ConcentratedFlame:InFlight()) or S.ConcentratedFlame:FullRechargeTimeP() < Player:GCD() or Target:TimeToDie() < 5) then
    if HR.Cast(S.ConcentratedFlame, nil, Settings.Commons.EssenceDisplayStyle, 40) then return "concentrated_flame 165"; end
  end
  -- aspect_of_the_wild,if=buff.aspect_of_the_wild.down&(cooldown.barbed_shot.charges<1|!azerite.primal_instincts.enabled)
  if S.AspectoftheWild:IsCastableP() and HR.CDsON() and (Player:BuffDownP(S.AspectoftheWildBuff) and (S.BarbedShot:ChargesP() < 1 or not S.PrimalInstincts:AzeriteEnabled())) then
    if HR.Cast(S.AspectoftheWild, Settings.BeastMastery.GCDasOffGCD.AspectoftheWild) then return "aspect_of_the_wild 180"; end
  end
  -- stampede,if=buff.aspect_of_the_wild.up&buff.bestial_wrath.up|target.time_to_die<15
  if S.Stampede:IsCastableP() and (Player:BuffP(S.AspectoftheWildBuff) and Player:BuffP(S.BestialWrathBuff) or Target:TimeToDie() < 15) then
    if HR.Cast(S.Stampede, Settings.BeastMastery.GCDasOffGCD.Stampede, nil, 30) then return "stampede 182"; end
  end
  -- a_murder_of_crows
  if S.AMurderofCrows:IsReadyP() then
    if HR.Cast(S.AMurderofCrows, Settings.BeastMastery.GCDasOffGCD.AMurderofCrows, nil, 40) then return "a_murder_of_crows 183"; end
  end
  -- focused_azerite_beam,if=buff.bestial_wrath.down|target.time_to_die<5
  if S.FocusedAzeriteBeam:IsCastableP() and (Player:BuffDownP(S.BestialWrathBuff) or Target:TimeToDie() < 5) then
    if HR.Cast(S.FocusedAzeriteBeam, nil, Settings.Commons.EssenceDisplayStyle) then return "focused_azerite_beam 184"; end
  end
  -- the_unbound_force,if=buff.reckless_force.up|buff.reckless_force_counter.stack<10|target.time_to_die<5
  if S.TheUnboundForce:IsCastableP() and (Player:BuffP(S.RecklessForceBuff) or Player:BuffStackP(S.RecklessForceCounter) < 10 or Target:TimeToDie() < 5) then
    if HR.Cast(S.TheUnboundForce, nil, Settings.Commons.EssenceDisplayStyle, 40) then return "the_unbound_force 185"; end
  end
  -- bestial_wrath,if=talent.one_with_the_pack.enabled&buff.bestial_wrath.remains<gcd|buff.bestial_wrath.down&cooldown.aspect_of_the_wild.remains>15|target.time_to_die<15+gcd
  if S.BestialWrath:IsCastableP() and HR.CDsON() and (S.OneWithThePack:IsAvailable() and Player:BuffRemainsP(S.BestialWrathBuff) < GCDMax or Player:BuffDownP(S.BestialWrathBuff) and S.AspectoftheWild:CooldownRemainsP() > 15 or Target:TimeToDie() < 15 + GCDMax) then
    if HR.Cast(S.BestialWrath, Settings.BeastMastery.GCDasOffGCD.BestialWrath) then return "bestial_wrath 190"; end
  end
  -- barbed_shot,if=azerite.dance_of_death.rank>1&buff.dance_of_death.remains<gcd
  if S.BarbedShot:IsCastableP() and (S.DanceofDeath:AzeriteRank() > 1 and Player:BuffRemainsP(S.DanceofDeathBuff) < GCDMax) then
    if HR.Cast(S.BarbedShot, nil, nil, 40) then return "barbed_shot 192"; end
  end
  -- kill_command
  if S.KillCommand:IsReadyP() then
    if HR.Cast(S.KillCommand, nil, nil, 50) then return "kill_command 194"; end
  end
  -- bag_of_tricks,if=buff.bestial_wrath.down|target.time_to_die<5
  if S.BagofTricks:IsCastableP() and (Player:BuffDownP(S.BestialWrathBuff) or Target:TimeToDie() < 5) then
    if HR.Cast(S.BagofTricks, Settings.Commons.OffGCDasOffGCD.Racials, nil, 40) then return "bag_of_tricks"; end
  end
  -- chimaera_shot
  if S.ChimaeraShot:IsCastableP() then
    if HR.Cast(S.ChimaeraShot, nil, nil, 40) then return "chimaera_shot 196"; end
  end
  -- dire_beast
  if S.DireBeast:IsReadyP() then
    if HR.Cast(S.DireBeast, nil, nil, 40) then return "dire_beast 198"; end
  end
  -- barbed_shot,if=talent.one_with_the_pack.enabled&charges_fractional>1.5|charges_fractional>1.8|cooldown.aspect_of_the_wild.remains<pet.turtle.buff.frenzy.duration-gcd&azerite.primal_instincts.enabled|target.time_to_die<9
  if S.BarbedShot:IsCastableP() and (S.OneWithThePack:IsAvailable() and S.BarbedShot:ChargesFractionalP() > 1.5 or S.BarbedShot:ChargesFractionalP() > 1.8
    or S.AspectoftheWild:CooldownRemainsP() < S.FrenzyBuff:BaseDuration() - GCDMax and S.PrimalInstincts:AzeriteEnabled() or Target:TimeToDie() < 9) then
    if HR.Cast(S.BarbedShot, nil, nil, 40) then return "barbed_shot 200"; end
  end
  -- purifying_blast,if=buff.bestial_wrath.down|target.time_to_die<8
  if S.PurifyingBlast:IsCastableP() and (Player:BuffDownP(S.BestialWrathBuff) or Target:TimeToDie() < 8) then
    if HR.Cast(S.PurifyingBlast, nil, Settings.Commons.EssenceDisplayStyle, 40) then return "focused_azerite_beam"; end
  end
  -- barrage
  if S.Barrage:IsReadyP() then
    if HR.Cast(S.Barrage, nil, nil, 40) then return "barrage 216"; end
  end
  -- cobra_shot,if=(focus-cost+focus.regen*(cooldown.kill_command.remains-1)>action.kill_command.cost|cooldown.kill_command.remains>1+gcd|buff.memory_of_lucid_dreams.up)&cooldown.kill_command.remains>1
  if S.CobraShot:IsReadyP() and ((Player:FocusPredicted() - S.CobraShot:Cost() + Player:FocusRegen() * (S.KillCommand:CooldownRemainsP() - 1) > S.KillCommand:Cost()
    or S.KillCommand:CooldownRemainsP() > 1 + GCDMax or Player:BuffP(S.MemoryofLucidDreams)) and S.KillCommand:CooldownRemainsP() > 1) then
    -- Special pooling line for HeroRotation -- negiligible effective DPS loss (0.1%), but better for prediction accounting for latency
    -- Avoids cases where Cobra Shot would be suggested but the GCD of Cobra Shot + latency would allow Barbed Shot to fall off
    -- wait,if=!buff.bestial_wrath.up&pet.turtle.buff.frenzy.up&pet.turtle.buff.frenzy.remains<=gcd.max*2&focus.time_to_max>gcd.max*2
    if Player:BuffDownP(S.BestialWrathBuff) and Pet:BuffP(S.FrenzyBuff) and Pet:BuffRemainsP(S.FrenzyBuff) <= GCDMax * 2 and Player:FocusTimeToMaxPredicted() > GCDMax * 2 then
      if HR.Cast(S.PoolFocus) then return "Barbed Shot Pooling"; end
    end
    if HR.Cast(S.CobraShot, nil, nil, 40) then return "cobra_shot 218"; end
  end
  -- spitting_cobra
  if S.SpittingCobra:IsCastableP() then
    if HR.Cast(S.SpittingCobra, Settings.BeastMastery.GCDasOffGCD.SpittingCobra) then return "spitting_cobra 234"; end
  end
  -- barbed_shot,if=pet.turtle.buff.frenzy.duration-gcd>full_recharge_time
  if S.BarbedShot:IsCastableP() and (S.FrenzyBuff:BaseDuration() - GCDMax > S.BarbedShot:FullRechargeTimeP()) then
    if HR.Cast(S.BarbedShot, nil, nil, 40) then return "barbed_shot 235"; end
  end
end

--- ======= ACTION LISTS =======
local function APL()
  EnemiesCount = GetEnemiesCount(8)
  HL.GetEnemies(40) -- Populate Cache.Enemies[40] for CastTargetIf
  UpdateGCDMax()    -- Update the GCDMax variable

  -- Pet Management
  if S.SummonPet:IsCastableP() then
    if HR.Cast(SummonPetSpells[Settings.Commons.SummonPetSlot], Settings.BeastMastery.GCDasOffGCD.SummonPet) then return "summon_pet"; end
  end
  if Pet:IsDeadOrGhost() and S.RevivePet:IsCastableP() then
    if HR.Cast(S.RevivePet, Settings.BeastMastery.GCDasOffGCD.RevivePet) then return "revive_pet"; end
  end
  if S.AnimalCompanion:IsAvailable() and Hunter.PetTable.LastPetSpellCount == 1 and Player:AffectingCombat() then
    -- Show a reminder that the Animal Companion has not spawned yet
    HR.CastSuggested(S.AnimalCompanion);
  end

  -- call precombat
  if not Player:AffectingCombat() then
    local ShouldReturn = Precombat(); if ShouldReturn then return ShouldReturn; end
  end
  if Everyone.TargetIsValid() then
    -- Self heal, if below setting value
    if S.Exhilaration:IsCastableP() and Player:HealthPercentage() <= Settings.Commons.ExhilarationHP then
      if HR.Cast(S.Exhilaration, Settings.Commons.GCDasOffGCD.Exhilaration) then return "exhilaration"; end
    end
    -- Interrupts
    local ShouldReturn = Everyone.Interrupt(40, S.CounterShot, Settings.Commons.OffGCDasOffGCD.CounterShot, StunInterrupts); if ShouldReturn then return ShouldReturn; end
    -- auto_shot
    -- use_items,if=prev_gcd.1.aspect_of_the_wild|target.time_to_die<20
    -- NOTE: Above line is very non-optimal and feedback has been given to the SimC APL devs, following logic will be used for now:
    --  if=buff.aspect_of_the_wild.remains>10|cooldown.aspect_of_the_wild.remains>60|target.time_to_die<20
    if Player:BuffRemainsP(S.AspectoftheWildBuff) > 10 or S.AspectoftheWild:CooldownRemainsP() > 60 or Target:BossTimeToDie() < 20 then
      local TrinketToUse = HL.UseTrinkets(OnUseExcludes)
      if TrinketToUse then
        if HR.Cast(TrinketToUse, nil, Settings.Commons.TrinketDisplayStyle) then return "Generic use_items for " .. TrinketToUse:Name(); end
      end
    end
    -- use_item,name=azsharas_font_of_power,if=cooldown.aspect_of_the_wild.remains_guess<15&target.time_to_die>10
    if I.AzsharasFontofPower:IsEquipReady() and Settings.Commons.UseTrinkets and (S.AspectoftheWild:CooldownRemainsP() < 15 and Target:BossTimeToDie() > 10) then
      if HR.Cast(I.AzsharasFontofPower, nil, Settings.Commons.TrinketDisplayStyle) then return "azsharas_font_of_power"; end
    end
    -- use_item,name=ashvanes_razor_coral,if=debuff.razor_coral_debuff.up&(!equipped.azsharas_font_of_power|trinket.azsharas_font_of_power.cooldown.remains>86|essence.blood_of_the_enemy.major)&(prev_gcd.1.aspect_of_the_wild|!equipped.cyclotronic_blast&buff.aspect_of_the_wild.remains>9)&(!essence.condensed_lifeforce.major|buff.guardian_of_azeroth.up)&(target.health.pct<35|!essence.condensed_lifeforce.major|!talent.killer_instinct.enabled)|(debuff.razor_coral_debuff.down|target.time_to_die<26)&target.time_to_die>(24*(cooldown.cyclotronic_blast.remains+4<target.time_to_die))
    if I.AshvanesRazorCoral:IsEquipReady() and Settings.Commons.UseTrinkets and (Target:DebuffP(S.RazorCoralDebuff) and (not I.AzsharasFontofPower:IsEquipped() or I.AzsharasFontofPower:CooldownRemains() > 86 or Spell:MajorEssenceEnabled(AE.BloodoftheEnemy)) and (Player:PrevGCDP(1, S.AspectoftheWild) or not Everyone.PSCDEquipped() and Player:BuffRemainsP(S.AspectoftheWildBuff) > 9) and (not Spell:MajorEssenceEnabled(AE.CondensedLifeForce) or Player:BuffP(S.GuardianofAzerothBuff)) and (Target:HealthPercentage() < 35 or not Spell:MajorEssenceEnabled(AE.CondensedLifeForce) or not S.KillerInstinct:IsAvailable()) or (Target:DebuffDownP(S.RazorCoralDebuff) or Target:TimeToDie() < 26) and Target:TimeToDie() > (24 * num(I.PocketsizedComputationDevice:CooldownRemains() + 4 < Target:TimeToDie()))) then
      if HR.Cast(I.AshvanesRazorCoral, nil, Settings.Commons.TrinketDisplayStyle, 40) then return "ashvanes_razor_coral"; end
    end
    -- use_item,name=galecallers_boon,if=buff.aspect_of_the_wild.remains>10|cooldown.aspect_of_the_wild.remains>45|target.time_to_die<11
    if I.GalecallersBoon:IsEquipReady() and (Player:BuffRemainsP(S.AspectoftheWildBuff) > 10 or S.AspectoftheWild:CooldownRemainsP() > 45 or Target:TimeToDie() < 11) then
      if HR.Cast(I.GalecallersBoon, nil, Settings.Commons.TrinketDisplayStyle) then return "galecallers_boon"; end
    end
    -- use_item,effect_name=cyclotronic_blast,if=buff.bestial_wrath.down|target.time_to_die<5
    if Everyone.CyclotronicBlastReady() and Settings.Commons.UseTrinkets and (Player:BuffDownP(S.BestialWrathBuff) or Target:BossTimeToDie() < 5) then
      if HR.Cast(I.PocketsizedComputationDevice, nil, Settings.Commons.TrinketDisplayStyle, 40) then return "cyclotronic_blast"; end
    end
    -- call_action_list,name=cds
    if (HR.CDsON()) then
      local ShouldReturn = Cds(); if ShouldReturn then return ShouldReturn; end
    end
    -- call_action_list,name=st,if=active_enemies<2
    if (EnemiesCount < 2) then
      local ShouldReturn = St(); if ShouldReturn then return ShouldReturn; end
    end
    -- call_action_list,name=cleave,if=active_enemies>1
    if (EnemiesCount > 1) then
      local ShouldReturn = Cleave(); if ShouldReturn then return ShouldReturn; end
    end
    if HR.Cast(S.PoolFocus) then return "Pooling Focus"; end
  end
end

local function Init ()
  -- Register Splash Data Nucleus Abilities
  HL.RegisterNucleusAbility(2643, 8, 6)               -- Multi-Shot
  HL.RegisterNucleusAbility(194392, 8, 6)             -- Volley
  HL.RegisterNucleusAbility({171454, 171457}, 8, 6)   -- Chimaera Shot
  HL.RegisterNucleusAbility(118459, 10, 6)            -- Beast Cleave
  HL.RegisterNucleusAbility(201754, 8, 6)             -- Stomp
  HL.RegisterNucleusAbility(271686, 3, 6)             -- Head My Call
  HL.RegisterNucleusAbility(295305, 8, 6)             -- Purification Protocol (Minor)
  HL.RegisterNucleusAbility(297108, 12, 6)            -- Blood of the Enemy (Major)
end

HR.SetAPL(253, APL, Init)
