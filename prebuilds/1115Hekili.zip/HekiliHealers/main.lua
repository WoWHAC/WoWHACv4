-- Hekili Healers Packs
-- An addon to provide custom Hekili profiles for Priest specializations
local ADDON_NAME, Private = ...

Private.name = "Hekili Healers Packs"
Private.shortName = "Bolt's"
Private.class = UnitClassBase("player")
Private.lowerClass = string.lower(Private.class)

Private.hekili = _G.Hekili

if Private.hekili then
    local Hekili = Private.hekili

    local function LoadSpecPacks()
        if Private.class == "PRIEST" then
            -- Load only Holy Priest specialization pack
            local fileName = string.format("%s_holy", Private.lowerClass)
            print("|cFF00FF00Hekili Healer Packs:|r Holy Priest pack should be registered by " .. fileName)
        end
    end

    local frame = CreateFrame("Frame")
    frame:RegisterEvent("PLAYER_LOGIN")
    frame:SetScript("OnEvent", function(self, event, ...)
        if event == "PLAYER_LOGIN" then
            if not _G.Hekili then
                print("|cFFFF0000Hekili Healer Packs:|r Hekili not detected. This addon requires Hekili to function.")
                return
            end
            Private.hekili = _G.Hekili
            LoadSpecPacks()
        end
    end)
end

-- Optional: Hook Hekili.RunOneTimeFixes if needed for profile cleanups (similar to sample)
if Private.hekili then
    local hookedFunc = Hekili.RunOneTimeFixes
    if hookedFunc then
        local oneTimeFixes = {
            priestPacksCanonicalizeNames_20250411 = function(p)
                -- Canonicalize package names if needed
                for id, spec in pairs(p.specs) do
                    if id == 257 and spec.package == "Holy PriestPack" then
                        spec.package = "priestpacks_priest_holy"
                    end
                end
                local newPacks = {}
                for name, pack in pairs(p.packs) do
                    if name == "Holy PriestPack" then
                        newPacks["priestpacks_priest_holy"] = pack
                    else
                        newPacks[name] = pack
                    end
                end
                p.packs = newPacks
            end,
        }

        Hekili.RunOneTimeFixes = function(self)
            local profile = Hekili.DB.profile
            if profile then
                profile.runOnce = profile.runOnce or {}

                for k, v in pairs(oneTimeFixes) do
                    if not profile.runOnce[k] then
                        profile.runOnce[k] = true
                        local ok, err = pcall(v, profile)
                        if err then
                            Hekili:Error("One-time update failed: " .. k .. ": " .. err)
                            profile.runOnce[k] = nil
                        end
                    end
                end

                hookedFunc(self)
            end
        end
    end
end 