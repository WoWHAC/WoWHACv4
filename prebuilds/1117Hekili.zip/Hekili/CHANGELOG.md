# Hekili

## [v11.2.0-1.0.0b](https://github.com/Hekili/hekili/tree/v11.2.0-1.0.0b) (2025-08-06)
[Full Changelog](https://github.com/Hekili/hekili/compare/v11.2.0-1.0.0a...v11.2.0-1.0.0b) [Previous Releases](https://github.com/Hekili/hekili/releases)

- Merge pull request #5006 from syrifgit/11-2-mage-apls  
    Frost Mage APL Update  
- Merge pull request #5004 from syrifgit/11-2-priest-apls  
    Shadow Priest Fixes  
- Frost Mage APL Update  
    SimC Sync: https://github.com/simulationcraft/simc/commit/441ff8d49efd504bb99fb9bb7ee7398b45f819ac  
- Shadow Priest Fixes  
    - Fixes Mind Flay issue  
    - FIxes Shadow Crash issue  
