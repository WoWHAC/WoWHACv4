# MaxDps_DemonHunter

## [v10.0.10](https://github.com/kaminaris/MaxDps-DemonHunter/tree/v10.0.10) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-DemonHunter/commits/v10.0.10) [Previous Releases](https://github.com/kaminaris/MaxDps-DemonHunter/releases)

- Update MaxDps\_DemonHunter.toc  
