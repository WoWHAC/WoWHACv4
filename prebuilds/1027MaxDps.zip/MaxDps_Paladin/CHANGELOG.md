# MaxDps_Paladin

## [v10.0.16](https://github.com/kaminaris/MaxDps-Paladin/tree/v10.0.16) (2024-07-22)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/commits/v10.0.16) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- Update MaxDps\_Paladin.toc  
