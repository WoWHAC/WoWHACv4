# MaxDps_Rogue

## [v10.0.25](https://github.com/kaminaris/MaxDps-Rogue/tree/v10.0.25) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-Rogue/commits/v10.0.25) [Previous Releases](https://github.com/kaminaris/MaxDps-Rogue/releases)

- Update MaxDps\_Rogue.toc  
