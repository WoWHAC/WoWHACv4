# MaxDps_Mage

## [v10.0.5](https://github.com/kaminaris/MaxDps-Mage/tree/v10.0.5) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-Mage/commits/v10.0.5) [Previous Releases](https://github.com/kaminaris/MaxDps-Mage/releases)

- Update MaxDps\_Mage.toc  
