# MaxDps_Shaman

## [v10.0.16](https://github.com/kaminaris/MaxDps-Shaman/tree/v10.0.16) (2024-07-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-Shaman/commits/v10.0.16) [Previous Releases](https://github.com/kaminaris/MaxDps-Shaman/releases)

- Update MaxDps\_Shaman.toc  
