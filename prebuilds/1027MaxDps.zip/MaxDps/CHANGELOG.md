# MaxDps

## [v10.0.52](https://github.com/kaminaris/MaxDps/tree/v10.0.52) (2024-07-20)
[Full Changelog](https://github.com/kaminaris/MaxDps/commits/v10.0.52) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- Update MaxDps.toc  
