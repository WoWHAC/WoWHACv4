# MaxDps_Evoker

## [v11.1.9](https://github.com/kaminaris/MaxDps-Evoker/tree/v11.1.9) (2025-07-09)
[Full Changelog](https://github.com/kaminaris/MaxDps-Evoker/compare/v11.1.8...v11.1.9) [Previous Releases](https://github.com/kaminaris/MaxDps-Evoker/releases)

- Update TOC  
