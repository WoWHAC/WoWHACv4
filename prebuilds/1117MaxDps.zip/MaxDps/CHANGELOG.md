# MaxDps

## [v11.1.80](https://github.com/kaminaris/MaxDps/tree/v11.1.80) (2025-08-07)
[Full Changelog](https://github.com/kaminaris/MaxDps/compare/v11.1.79...v11.1.80) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- [SpellData] Update Retail  
