# MaxDps_DemonHunter

## [v11.1.8](https://github.com/kaminaris/MaxDps-DemonHunter/tree/v11.1.8) (2025-08-07)
[Full Changelog](https://github.com/kaminaris/MaxDps-DemonHunter/compare/v11.1.7...v11.1.8) [Previous Releases](https://github.com/kaminaris/MaxDps-DemonHunter/releases)

- Update Havoc  
- Update Vengeance  
