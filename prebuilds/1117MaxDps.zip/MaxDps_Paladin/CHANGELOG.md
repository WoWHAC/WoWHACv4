# MaxDps_Paladin

## [v11.1.23](https://github.com/kaminaris/MaxDps-Paladin/tree/v11.1.23) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/compare/v11.1.22...v11.1.23) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- Update Retail Ret  
