# MaxDps_Mage

## [v11.1.32](https://github.com/kaminaris/MaxDps-Mage/tree/v11.1.32) (2025-08-04)
[Full Changelog](https://github.com/kaminaris/MaxDps-Mage/compare/v11.1.31...v11.1.32) [Previous Releases](https://github.com/kaminaris/MaxDps-Mage/releases)

- Update MoP Arcane  
