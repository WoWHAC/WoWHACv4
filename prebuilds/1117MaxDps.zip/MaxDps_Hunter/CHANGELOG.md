# MaxDps_Hunter

## [v11.1.26](https://github.com/kaminaris/MaxDps-Hunter/tree/v11.1.26) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Hunter/compare/v11.1.25...v11.1.26) [Previous Releases](https://github.com/kaminaris/MaxDps-Hunter/releases)

- Update Retail Survival  
- Update Retail MM  
- Update Retail BM  
