# MaxDps_DeathKnight

## [v11.1.31](https://github.com/kaminaris/MaxDps-DeathKnight/tree/v11.1.31) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-DeathKnight/compare/v11.1.30...v11.1.31) [Previous Releases](https://github.com/kaminaris/MaxDps-DeathKnight/releases)

- Update Retail Unholy  
