# MaxDps_Druid

## [v11.1.37](https://github.com/kaminaris/MaxDps-Druid/tree/v11.1.37) (2025-08-02)
[Full Changelog](https://github.com/kaminaris/MaxDps-Druid/compare/v11.1.36...v11.1.37) [Previous Releases](https://github.com/kaminaris/MaxDps-Druid/releases)

- Update MoP Feral  
