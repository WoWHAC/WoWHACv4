# Hekili

## [v9.2.7-1.0.0b](https://github.com/Hekili/hekili/tree/v9.2.7-1.0.0b) (2022-09-15)
[Full Changelog](https://github.com/Hekili/hekili/compare/v9.2.7-1.0.0a...v9.2.7-1.0.0b) [Previous Releases](https://github.com/Hekili/hekili/releases)

- Fix some equipment checks not showing debug values in snapshots.  Weird.  
- Support some simc key variants for trinket cooldowns.  
