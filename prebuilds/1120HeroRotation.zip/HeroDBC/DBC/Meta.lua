HeroDBC.DBC.metaVersion = "11.2.0.62493"
HeroDBC.DBC.metaTime = "2025-08-11T20:10:25.358485"
