# MaxDps_Druid

## [v11.1.18](https://github.com/kaminaris/MaxDps-Druid/tree/v11.1.18) (2025-06-15)
[Full Changelog](https://github.com/kaminaris/MaxDps-Druid/compare/v11.1.17...v11.1.18) [Previous Releases](https://github.com/kaminaris/MaxDps-Druid/releases)

- Update Cata Balance  
