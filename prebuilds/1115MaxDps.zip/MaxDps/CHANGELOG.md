# MaxDps

## [v11.1.23](https://github.com/kaminaris/MaxDps/tree/v11.1.23) (2025-06-04)
[Full Changelog](https://github.com/kaminaris/MaxDps/compare/v11.1.22...v11.1.23) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- [Core] Update LoadModule  
