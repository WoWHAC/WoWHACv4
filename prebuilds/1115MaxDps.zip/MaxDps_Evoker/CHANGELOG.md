# MaxDps_Evoker

## [v11.1.6](https://github.com/kaminaris/MaxDps-Evoker/tree/v11.1.6) (2025-05-15)
[Full Changelog](https://github.com/kaminaris/MaxDps-Evoker/compare/v11.1.5...v11.1.6) [Previous Releases](https://github.com/kaminaris/MaxDps-Evoker/releases)

- Update Devastation  
