# MaxDps_DeathKnight

## [v11.1.5](https://github.com/kaminaris/MaxDps-DeathKnight/tree/v11.1.5) (2025-06-16)
[Full Changelog](https://github.com/kaminaris/MaxDps-DeathKnight/compare/v11.1.4...v11.1.5) [Previous Releases](https://github.com/kaminaris/MaxDps-DeathKnight/releases)

- Update Cata Blood and Frost CDs  
