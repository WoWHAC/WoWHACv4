# MaxDps_Paladin

## [v11.1.5](https://github.com/kaminaris/MaxDps-Paladin/tree/v11.1.5) (2025-06-04)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/compare/v11.1.4...v11.1.5) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- Update Classic Ret  
