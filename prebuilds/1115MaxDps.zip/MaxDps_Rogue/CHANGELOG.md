# MaxDps_Rogue

## [v11.1.8](https://github.com/kaminaris/MaxDps-Rogue/tree/v11.1.8) (2025-05-28)
[Full Changelog](https://github.com/kaminaris/MaxDps-Rogue/compare/v11.1.7...v11.1.8) [Previous Releases](https://github.com/kaminaris/MaxDps-Rogue/releases)

- Update Classic Combat  
