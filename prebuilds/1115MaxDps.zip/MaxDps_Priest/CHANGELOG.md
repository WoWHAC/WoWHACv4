# MaxDps_Priest

## [v11.1.1](https://github.com/kaminaris/MaxDps-Priest/tree/v11.1.1) (2025-04-22)
[Full Changelog](https://github.com/kaminaris/MaxDps-Priest/compare/v11.1.0...v11.1.1) [Previous Releases](https://github.com/kaminaris/MaxDps-Priest/releases)

- Update TOC  
