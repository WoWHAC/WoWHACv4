# MaxDps_Warlock

## [v11.1.8](https://github.com/kaminaris/MaxDps-Warlock/tree/v11.1.8) (2025-06-16)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warlock/compare/v11.1.7...v11.1.8) [Previous Releases](https://github.com/kaminaris/MaxDps-Warlock/releases)

- Update Cata Demo CDs  
