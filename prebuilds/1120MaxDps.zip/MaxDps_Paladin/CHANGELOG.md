# MaxDps_Paladin

## [v11.1.29](https://github.com/kaminaris/MaxDps-Paladin/tree/v11.1.29) (2025-08-12)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/compare/v11.1.28...v11.1.29) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- Update Retail Ret  
- Update Retail Prot  
