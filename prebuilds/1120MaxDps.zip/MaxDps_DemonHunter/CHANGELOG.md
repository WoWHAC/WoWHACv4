# MaxDps_DemonHunter

## [v11.1.9](https://github.com/kaminaris/MaxDps-DemonHunter/tree/v11.1.9) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-DemonHunter/compare/v11.1.8...v11.1.9) [Previous Releases](https://github.com/kaminaris/MaxDps-DemonHunter/releases)

- Bump Retail TOC  
