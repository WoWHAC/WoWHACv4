# MaxDps

## [v11.1.94](https://github.com/kaminaris/MaxDps/tree/v11.1.94) (2025-08-17)
[Full Changelog](https://github.com/kaminaris/MaxDps/compare/v11.1.93...v11.1.94) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- [Modules] Max IDs Optional with debug mode  
