# MaxDps_Warlock

## [v11.1.25](https://github.com/kaminaris/MaxDps-Warlock/tree/v11.1.25) (2025-08-11)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warlock/compare/v11.1.24...v11.1.25) [Previous Releases](https://github.com/kaminaris/MaxDps-Warlock/releases)

- Update Retail Destruction  
