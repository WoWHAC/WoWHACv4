# MaxDps_Evoker

## [v11.1.10](https://github.com/kaminaris/MaxDps-Evoker/tree/v11.1.10) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Evoker/compare/v11.1.9...v11.1.10) [Previous Releases](https://github.com/kaminaris/MaxDps-Evoker/releases)

- Bump Retail TOC  
- Update .luacheckrc  
