# MaxDps_Warrior

## [v11.1.26](https://github.com/kaminaris/MaxDps-Warrior/tree/v11.1.26) (2025-08-16)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warrior/compare/v11.1.25...v11.1.26) [Previous Releases](https://github.com/kaminaris/MaxDps-Warrior/releases)

- Update Retail Fury  
- Update Retail Arms  
