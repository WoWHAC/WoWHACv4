# MaxDps_Monk

## [v11.1.16](https://github.com/kaminaris/MaxDps-Monk/tree/v11.1.16) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Monk/compare/v11.1.15...v11.1.16) [Previous Releases](https://github.com/kaminaris/MaxDps-Monk/releases)

- Bump Retail TOC  
