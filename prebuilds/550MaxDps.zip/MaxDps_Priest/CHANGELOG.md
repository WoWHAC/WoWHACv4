# MaxDps_Priest

## [v11.1.10](https://github.com/kaminaris/MaxDps-Priest/tree/v11.1.10) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Priest/compare/v11.1.9...v11.1.10) [Previous Releases](https://github.com/kaminaris/MaxDps-Priest/releases)

- Bump Retail TOC  
