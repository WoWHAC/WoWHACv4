# MaxDps_Rogue

## [v11.1.21](https://github.com/kaminaris/MaxDps-Rogue/tree/v11.1.21) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Rogue/compare/v11.1.20...v11.1.21) [Previous Releases](https://github.com/kaminaris/MaxDps-Rogue/releases)

- Bump Retail TOC  
- Update .luacheckrc  
