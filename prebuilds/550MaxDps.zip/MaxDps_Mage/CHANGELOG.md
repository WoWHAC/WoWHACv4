# MaxDps_Mage

## [v11.1.33](https://github.com/kaminaris/MaxDps-Mage/tree/v11.1.33) (2025-08-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Mage/compare/v11.1.32...v11.1.33) [Previous Releases](https://github.com/kaminaris/MaxDps-Mage/releases)

- Bump Retail TOC  
