# Hekili

## [v11.2.0-1.0.0r](https://github.com/Hekili/hekili/tree/v11.2.0-1.0.0r) (2025-08-18)
[Full Changelog](https://github.com/Hekili/hekili/compare/v11.2.0-1.0.0q...v11.2.0-1.0.0r) [Previous Releases](https://github.com/Hekili/hekili/releases)

- Fix Frost DK target counts (again)  
- Initialize more trinket data.  
