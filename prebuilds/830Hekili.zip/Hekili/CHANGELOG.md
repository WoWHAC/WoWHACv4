# Hekili

## [v8.3.7-04](https://github.com/Hekili/hekili/tree/v8.3.7-04) (2020-10-03)
[Full Changelog](https://github.com/Hekili/hekili/compare/v8.3.7-03...v8.3.7-04) [Previous Releases](https://github.com/Hekili/hekili/releases)

- Add pet-based target detection to Retail.  
    More iteration on ElvUI keybind detection.  
