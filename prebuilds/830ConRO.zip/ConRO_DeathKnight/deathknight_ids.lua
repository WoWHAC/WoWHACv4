local ConRO_DeathKnight, ids = ...;

--Generic
	ids.Racial = {
		ArcanePulse = 260364,
		ArcaneTorrent = 50613,
		Berserking = 26297,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.DeathKnight_AzTrait = {
		BonesoftheDamned = 278484,
	}
	ids.DeathKnight_AzTraitBuff = {

	}
	ids.AzEssence = {
		BloodoftheEnemy = 298273,
		ConcentratedFlame = 295373,
		FocusedAzeriteBeam =295258,
		GuardianofAzeroth = 299358,
		MemoryofLucidDream = 298357,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}
	ids.AzEssenceBuff = {
		MemoryofLucidDream = 298357,
	}
	ids.AzEssenceDebuff = {	
		ConcentratedFlame = 295368,
	}
	
--Blood
	ids.Blood_Ability = {
		AntiMagicShell = 48707,
		Asphyxiate = 221562,
		BloodBoil = 50842,
		ControlUndead = 111673,
		DancingRuneWeapon = 49028,
		DarkCommand = 56222,
		DeathandDecay = 43265,
		DeathGate = 50977,
		DeathGrip = 49576,
		DeathStrike = 49998,
		DeathsAdvance = 48265,
		DeathsCaress = 195292,
		GorefiendsGrasp = 108199,
		HeartStrike = 206930,
		IceboundFortitude = 48792,
		Marrowrend = 195182,
		MindFreeze = 47528,
		PathofFrost = 3714,
		RaiseAlly = 61999,
		Runeforging = 53428,
		VampiricBlood = 55233,
	}
	ids.Blood_Passive = {
		CrimsonScourge = 81136,
		MasteryBloodShield = 77513,
		OnaPaleHorse = 51986,
		VeteranoftheThirdWar = 48263,
	}
	ids.Blood_Talent = {
		--56
		Heartbreaker = 221536,		
		Blooddrinker = 206931,		
		RuneStrike = 210764,
		--57		
		RapidDecomposition = 194662,
		Hemostasis = 273946,
		Consumption = 274156,
		--58		
		FoulBulwark = 206974,
		Ossuary = 219786,
		Tombstone = 219809,		
		--60
		WilloftheNecropolis = 206967,
		AntiMagicBarrier = 205727,
		RuneTap = 194679,
		--75
		GripoftheDead = 273952,
		TighteningGrasp = 206970,
		WraithWalk = 212552,
		--90
		Voracious = 273953,
		Bloodworms = 195679,
		MarkofBlood = 206940,		
		--100
		Purgatory = 114556,
		RedThirst = 205723,
		Bonestorm = 194844,
	}
	ids.Blood_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		UnholyCommand = 202727,
		WalkingDead = 202731,
		Strangulate = 47476,
		BloodforBlood = 233411,
		LastDance = 233412,
		DeathChain = 203173,
		MurderousIntent = 207018,
		AntiMagicZone = 51052,
		NecroticAura = 199642,
		DecomposingAura = 199720,
		DarkSimulacrum = 77606,
	}
	ids.Blood_Form = {
	
	}
	ids.Blood_Buff = {
		BloodforBlood = 233411,
		BloodShield = 77535,
		BoneShield = 195181,
		CrimsonScourge = 81141,
		DancingRuneWeapon = 81256,
		DeathandDecay = 188290,
		Hemostasis = 273947,
	}
	ids.Blood_Debuff = {
		BloodPlague = 55078,
	}
	ids.Blood_PetAbility = {
			
	}
		
--Frost
	ids.Frost_Ability = {
		AntiMagicShell = 48707,
		ChainsofIce = 45524,
		ControlUndead = 111673,
		DarkCommand = 56222,
		DeathGate = 50977,
		DeathGrip = 49576,
		DeathStrike = 49998,
		DeathsAdvance = 48265,
		EmpowerRuneWeapon = 47568,
		FrostStrike = 49143,
		HowlingBlast = 49184,
		IceboundFortitude = 48792,
		MindFreeze = 47528,
		Obliterate = 49020,
		PathofFrost = 3714,
		PillarofFrost = 51271,
		RaiseAlly = 61999,
		RemorselessWinter = 196770,
		Runeforging = 53428,
	}
	ids.Frost_Passive = {
		DarkSuccor = 178819,
		KillingMachine = 51128,
		MasteryFrozenHeart = 77514,
		OnaPaleHorse = 51986,
		Rime = 59057,
		RunicEmpowerment = 81229,
	}
	ids.Frost_Talent = {
		--56
		InexorableAssault = 253593,
		IcyTalons = 194878,		
		ColdHeart = 281208,
		--57
		RunicAttenuation = 207104,
		MurderousEfficiency = 207061,
		HornofWinter = 57330,
		--58		
		DeathsReach = 276079,
		Asphyxiate = 108194,
		BlindingSleet = 207167,		
		--60		
		Avalanche = 207142,
		FrozenPulse = 194909,
		Frostscythe = 207230,
		--75
		Permafrost = 207200,
		WraithWalk = 212552,
		DeathPact = 48743,
		--90
		GatheringStorm = 194912,
		GlacialAdvance = 194913,
		FrostwyrmsFury = 279302,
		--100
		Icecap = 207126,
		Obliteration = 281238,
		BreathofSindragosa = 152279,
	}
	ids.Frost_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		ChillStreak = 305392,
--		LifeandDeath = 288855,
--		DarkSimulacrum = 77606,		
--		AntiMagicZone = 51052,
--		NectroticStrike = 223829,
--		Reanimation = 210128,
--		CadaverousPallor = 201995,
--		NecroticAura = 199642,		
--		DecomposingAura = 199720,
--		NecromancersBargain = 288848,
--		RaiseAbomination = 288853,
--		Transfusion = 288977,
--		Lichborne = 287081,		
	}
	ids.Frost_Form = {
		BreathofSindragosa = 152279,
	}
	ids.Frost_Buff = {
		ColdHeart = 281209,
		DarkSuccor = 101568,
		IcyTalons = 194879,
		InexorableAssault = 253595,
		KillingMachine = 51124,
		PillarofFrost = 51271,
		RemorselessWinter = 196770,
		Rime = 59052,
		UnholyStrength = 53365,
	}
	ids.Frost_Debuff = {
		FrostFever = 55095,
		RazorIce = 51714,
	}
	ids.Frost_PetAbility = {
		
	}

--Unholy
	ids.Unholy_Ability = {
		AntiMagicShell = 48707,
		Apocalypse = 275699,
		ArmyoftheDead = 42650,
		ChainsofIce = 45524,
		ControlUndead = 111673,
		DarkCommand = 56222,
		DarkTransformation = 63560,
		DeathandDecay = 43265,
		DeathCoil = 47541,
		DeathGate = 50977,
		DeathGrip = 49576,
		DeathStrike = 49998,
		DeathsAdvance = 48265,
		FesteringStrike = 85948,
		IceboundFortitude = 48792,
		MindFreeze = 47528,
		Outbreak = 77575,
		PathofFrost = 3714,
		RaiseAlly = 61999,
		RaiseDead = 46584,
		Runeforging = 53428,
		ScourgeStrike = 55090,
	}
	ids.Unholy_Passive = {
		DarkSuccor = 178819,
		MasteryDreadblade = 77515,
		OnaPaleHorse = 51986,
		RunicCorruption = 51462,
		SuddenDoom = 49530,
	}
	ids.Unholy_Talent = {
		--56
		InfectedClaws = 207272,		
		AllWillServe = 194916,		
		ClawingShadows = 207311,		
		--57		
		BurstingSores = 207264,		
		EbonFever = 207269,	
		UnholyBlight = 115989,
		--58		
		GripoftheDead = 273952,
		DeathsReach = 276079,
		Asphyxiate = 108194,		
		--60		
		PestilentPustules = 194917,		
		HarbingerofDoom = 276023,
		SoulReaper = 130736,		
		--75		
		SpellEater = 207321,
		WraithWalk = 212552,
		DeathPact = 48743,
		--90		
		Pestilence = 277234,
		Defile = 152280,
		Epidemic = 207317,
		--100
		ArmyoftheDamned = 276837,
		UnholyFrenzy = 207289,
		SummonGargoyle = 49206,
	}
	ids.Unholy_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		LifeandDeath = 288855,
		DarkSimulacrum = 77606,		
		AntiMagicZone = 51052,
		NectroticStrike = 223829,
		Reanimation = 210128,
		CadaverousPallor = 201995,
		NecroticAura = 199642,		
		DecomposingAura = 199720,
		NecromancersBargain = 288848,
		RaiseAbomination = 288853,
		Transfusion = 288977,
		Lichborne = 287081,
	}	
	ids.Unholy_Form = {
		
	}
	ids.Unholy_Buff = {
		DarkSuccor = 101568,
		DeathandDecay = 188290,
		SuddenDoom = 81340,
		SoulReaper = 215711,
		Transfusion = 288977,		
	}
	ids.Unholy_Debuff = {
		FesteringWound = 194310,
		NectroticStrike = 223929,		
		ScourgeofWorlds = 191748,
		SoulReaper = 130736,
		VirulentPlague = 191587,
	}
	ids.Unholy_PetAbility = {
		
	}