local ConRO_DemonHunter, ids = ...;

--Generic
	ids.Racial = {
		ArcaneTorrent = 202719,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.DemonHunter_AzTrait = {

	}
	ids.DemonHunter_AzTraitBuff = {

	}
	ids.AzEssence = {
		ConcentratedFlame = 295373,
		MemoryofLucidDream = 298357,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}
	
--Havoc
	ids.Havoc_Ability = {
		Annihilation = 201427,
		BladeDance = 188499,
		Blur = 198589,
		ChaosNova = 179057,
		ChaosStrike = 162794,
		ConsumeMagic = 278326,
		Darkness = 196718,
		DeathSweep = 210152,
		DemonsBite = 162243,
		Disrupt = 183752,
		EyeBeam = 198013,
		FelRush = 195072,
		Glide = 131347,
		Imprison = 217832,
		Metamorphosis = 191427,
		SpectralSight = 188501,
		ThrowGlaive = 185123,
		Torment = 281854,
		VengefulRetreat = 198793,
	}
	ids.Havoc_Passive = {
		ChaosBrand = 255260,
		DemonicWards = 278386,
		DoubleJump = 196055,
		MasteryDemonicPresence = 185164,
		ShatteredSouls = 178940,
	}
	ids.Havoc_Talent = {
		--99
		BlindFury = 203550,
		DemonicAppetite = 206478,
		Felblade = 232893,
		--100
		InsatiableHunger = 258876,
		DemonBlades = 203555,
		ImmolationAura = 258920,
		--102
		TrailofRuin = 258881,
		FelMastery = 192939,
		FelBarrage = 258925,
		--104
		SoulRending = 204909,
		DesperateInstincts = 205411,
		Netherwalk = 196555,
		--106
		CycleofHatred = 258887,
		FirstBlood = 206416,
		DarkSlash = 258860,
		--108		
		UnleashedPower = 206477,
		MasteroftheGlaive = 203556,
		FelEruption = 211881,
		--110
		Demonic = 213410,
		Momentum = 206476,
		Nemesis = 206491,		
	}
	ids.Havoc_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		Solitude = 211509,
		ReverseMagic = 205604,
		EyeofLeotheras = 206649,
		ManaRift = 235903,
		DemonicOrigins = 235893,
		RainfromAbove = 206803,
		Detainment = 205596,
		ManaBreak = 203704,
		CoverofDarkness = 227635,
		Glimpse = 203468,
		UnendingHatred = 213480,
	}	
	ids.Havoc_Form = {
	
	}
	ids.Havoc_Buff = {
		ChaosBlades = 247938,
		Metamorphosis = 162264,
		Momentum = 208628,
	}
	ids.Havoc_Debuff = {
		Bloodlet = 207690,
		DarkSlash = 258860,
		Nemesis = 206491,
	}
	ids.Havoc_PetAbility = {

	}
		
--Vengeance
	ids.Ven_Ability = {
		ConsumeMagic = 278326,
		DemonSpikes = 203720,
		Disrupt = 183752,
		FieryBrand = 204021,
		Glide = 13147,
		ImmolationAura = 178740,
		Imprison = 217832,
		InfernalStrike = 189110,
		Metamorphosis = 187827,
		Shear = 203782,
		SigilofFlame = 204596,
		SigilofMisery = 207684,
		SigilofSilence = 202137,
		SoulCleave = 228477,
		SpectralSight = 188501,
		ThrowGlaive = 204157,
		Torment = 185245,
	}
	ids.Ven_Passive = {
		ChaosBrand = 281242,
		DemonicWards = 203513,
		DoubleJump = 196055,
		MasteryFelBlood = 203747,
		ShatteredSouls = 204254,
	}
	ids.Ven_Talent = {
		--99
		AbyssalStrike = 207550,
		AgonizingFlames = 207548,
		RazorSpikes = 209400,
		--100
		FeastofSouls = 207697,
		Fallout = 227174,
		BurningAlive = 207739,
		--102
		FlameCrash = 227322,
		CharredFlesh = 264002,
		Felblade = 232893,
		--104
		SoulRending = 217996,		
		FeedtheDemon = 218612,
		Fracture = 263642,
		--106
		ConcentratedSigils = 207666,
			SigilofFlame = 204513,
			SigilofMisery = 202140,
			SigilofSilence = 207682,
		QuickenedSigils = 209281,
		SigilofChains = 202138,
		--108
		Gluttony = 264004,
		SpiritBomb = 247454,
		FelDevastation = 212084,
		--110
		LastResort = 209258,
		VoidReaver = 268175,
		SoulBarrier = 263648,
	}
	ids.Ven_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		Solitude = 211509,
		CleansedbyFlame = 205625,
		EverlastingHunt = 205626,
		JaggedSpikes = 205627,
		IllidansGrasp = 205630,
		Tormentor = 207029,
		SigilMastery = 211489,
		DemonicTrample = 205629,
		ReverseMagic = 205604,
		Detainment = 205596,
		UnendingHatred = 213480,
	}		
	ids.Ven_Form = {
		SoulFragments = 203981,
	}
	ids.Ven_Buff = {
		DemonSpikes = 203819,
		ImmolationAura = 178740,
		Metamorphosis = 187827,
		SoulBarrier = 263648,
	}
	ids.Ven_Debuff = {
		FieryBrand = 207744,
		FieryDemise = 212818,
		Frailty = 247456,
		SigilofFlame = 204598,
	}
	ids.Ven_PetAbility = {

	}