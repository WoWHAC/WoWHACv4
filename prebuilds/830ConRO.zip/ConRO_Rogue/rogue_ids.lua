local ConRO_Rogue, ids = ...;

--Generic
	ids.Racial = {
		ArcanePulse = 260364,
		ArcaneTorrent = 25046,
		Berserking = 26297,
		Shadowmeld = 58984,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.Rogue_AzTrait = {
		AceUpYourSleeve = 278676,
		Deadshot = 272935,
		KeepYourWitsAboutYou = 288979,
		NightsVengeance = 273418,
		SnakeEyes = 275846,
		ShroudedSuffocation = 278666,
	}
	ids.Rogue_AzTraitBuff = {
		Deadshot = 272940,
		KeepYourWitsAboutYou = 288988,
	}

	ids.AzEssence = {
		BloodoftheEnemy = 298273,
		ConcentratedFlame = 295373,
		FocusedAzeriteBeam =295258,
		GuardianofAzeroth = 299358,
		MemoryofLucidDream = 298357,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}
	ids.AzEssenceBuff = {
		MemoryofLucidDream = 298357,	
	}
	
--Assassination
	ids.Ass_Ability = {
		Blind = 2094,
		CheapShot = 1833,
		CloakofShadows = 31224,
		CrimsonVial = 185311,
		Detection = 56814,
		Distract = 1725,
		Envenom = 32645,
		Evasion = 5277,
		FanofKnives = 51723,
		Feint = 1966,
		Garrote = 703,
		Kick = 1766,
		KidneyShot = 408,
		Mutilate = 1329,
		PickLock = 1804,
		PickPocket = 921,
		PoisonedKnife = 185565,
		Poisons = nil,
			DeadlyPoison = 2823,
			WoundPoison = 8679,
			CripplingPoison = 3408,
		Rupture = 1943,
		Sap = 6770,
		Shadowstep = 36554,
		ShroudofConcealment = 114018,
		Sprint = 2983,
		Stealth = 1784,
		TricksoftheTrade = 57934,
		Vanish = 1856,
		Vendetta = 79140,
	}
	ids.Ass_Passive = {
		FleetFooted = 31209,
		MasteryPotentAssassin = 76803,
		SealFate = 14190,
		VenomousWounds = 79134,
	}
	ids.Ass_Talent = {
		--15
		MasterPoisoner = 196864,
		ElaboratePlanning = 193640,
		Blindside = 111240,
		--30
		Nightstalker = 14062,
		Subterfuge = 108208,
			SubStealth = 115191,
		MasterAssassin = 255989,
		--45
		Vigor = 14983,
		DeeperStratagem = 193531,
		MarkedforDeath = 137619,
		--60
		LeechingPoison = 280716,
		CheatDeath = 31230,
		Elusiveness = 79008,
		--75
		InternalBleeding = 154904,
		IronWire = 196861,
		PreyontheWeak = 131511,
		--90
		VenomRush = 152152,
		ToxicBlade = 245388,
		Exsanguinate = 200806,
		--100
		PoisonBomb = 255544,
		HiddenBlades = 270061,
		CrimsonTempest = 121411,
	}
	ids.Ass_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--

	}
	ids.Ass_Form = {
		Stealth = 1784,
	}
	ids.Ass_Buff = {
		Blindside = 121153,
		CrimsonTempest = 121411,
		CripplingPoison = 3408,
		DeadlyPoison = 2823,
		ElaboratePlanning = 193641,
		Envenom = 32645,
		HiddenBlades = 270070,
		InternalBleeding = 154953,
		MasterAssassin = 256735,
		Subterfuge = 115192,
		Vanish = 11327,		
		WoundPoison = 8679,
	}
	ids.Ass_Debuff = {
		CrimsonTempest = 121411,
		DeadlyPoison = 2818,
		Garrote = 703,
		MarkedforDeath = 137619,
		Rupture = 1943,
		ToxicBlade = 245389,		
		Vendetta = 79140,
	}
	ids.Ass_PetAbility = {
			
	}
		
--Outlaw
	ids.Out_Ability = {
		AdrenalineRush = 13750,
		Ambush = 8676,
		BetweentheEyes = 199804,
		BladeFlurry = 13877,
		Blind = 2094,
		CheapShot = 1833,
		CloakofShadows = 31224,
		CrimsonVial = 185311,
		Detection = 56814,
		Dispatch = 2098,
		Distract = 1725,
		Feint = 1966,
		Gouge = 1776,
		GrapplingHook = 195457,
		Kick = 1766,
		PickLock = 1804,
		PickPocket = 921,
		PistolShot = 185763,
		Riposte = 199754,
		RolltheBones = 193316,
		Sap = 6770,
		ShroudofConcealment = 114018,
		SinisterStrike = 193315,
		Sprint = 2983,
		Stealth = 1784,
		TricksoftheTrade = 57934,
		Vanish = 1856,
	}
	ids.Out_Passive = {
		CombatPotency = 61329,
		FleetFooted = 31209,
		MasteryMainGauche = 76806,
		RestlessBlades = 79096,
		Ruthlessness = 14161,
	}
	ids.Out_Talent = {
		--15
		Weaponmaster = 200733,
		QuickDraw = 196938,
		GhostlyStrike = 196937,
		--30
		AcrobaticStrikes = 196924,
		RetractableHook = 256188,
		HitandRun = 196922,
		--45
		Vigor = 14983,
		DeeperStratagem = 193531,
		MarkedforDeath = 137619,
		--60
		IronStomach = 193546,
		CheatDeath = 31230,
		Elusiveness = 79008,
		--75
		DirtyTricks = 108216,
		BlindingPowder = 256165,
		PreyontheWeak = 131511,
		--90
		LoadedDice = 256170,
		Alacrity = 193539,
		SliceandDice = 5171,
		--100
		DancingSteel = 272026,
		BladeRush = 271877,
		KillingSpree = 51690,
	}
	ids.Out_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		Maneuverability = 197000,
		TakeYourCut = 198265,
		ControlisKing = 212217,
		DrinkUpMeHearties = 212210,
		CheapTricks = 212035,
		Dismantle = 207777,
		PlunderArmor = 198529,
		BoardingParty = 209752,
		ThickasThieves = 221622,
		TurntheTables = 198020,
		Shiv = 248744,
		HonorAmongThieves = 198032,
		SmokeBomb = 212182,
		DeathfromAbove = 269513,
	}
	ids.Out_Form = {
	
	}
	ids.Out_Buff = {
		AdrenalineRush = 13750,
		BladeFlurry = 13877,
		Broadside = 193356,
		BuriedTreasure = 199600,
		GrandMelee = 193358,
		Opportunity = 195627,
		RuthlessPrecision = 193357,
		SkullandCrossbones = 199603,
		SliceandDice = 5171,
		TrueBearing = 193359,
	}
	ids.Out_Debuff = {
		GhostlyStrike = 196937,
		MarkedforDeath = 137619,
	}
	ids.Out_PetAbility = {
		
	}

--Subtlety
	ids.Sub_Ability = {
		Backstab = 53,
		Blind = 2094,
		CheapShot = 1833,
		CloakofShadows = 31224,
		CrimsonVial = 185311,
		Detection = 56814,
		Distract = 1725,
		Evasion = 5277,
		Eviscerate = 196819,
		Feint = 1966,
		Kick = 1766,
		KidneyShot = 408,
		Nightblade = 195452,
		PickLock = 1804,
		PickPocket = 921,
		Sap = 6770,
		ShadowBlades = 121471,
		ShadowDance = 185313,
		Shadowstep = 36554,
		Shadowstrike = 185438,
		ShroudofConcealment = 114018,
		ShurikenStorm = 197835,
		ShurikenToss = 114014,
		Sprint = 2983,
		Stealth = 1784,
		SymbolsofDeath = 212283,
		TricksoftheTrade = 57934,
		Vanish = 1856,
	}
	ids.Sub_Passive = {
		DeepeningShadows = 185314,
		FleetFooted = 31209,
		MasteryExecutioner = 76808,
		RelentlessStrikes = 58423,
		ShadowTechniques = 196912,
		ShadowsGrasp = 277950,
		ShurikenCombo = 245639,
	}
	ids.Sub_Talent = {
		--15
		Weaponmaster = 193537,
		FindWeakness = 91023,
		Gloomblade = 200758,
		--30
		Nightstalker = 14062,
		Subterfuge = 108208,
			SubStealth = 115191,
		ShadowFocus = 108209,
		--45
		Vigor = 14983,
		DeeperStratagem = 193531,
		MarkedforDeath = 137619,
		--60
		SoothingDarkness = 200759,
		CheatDeath = 31230,
		Elusiveness = 79008,
		--75
		ShotintheDark = 257505,
		NightTerrors = 277953,
		PreyontheWeak = 131511,
		--90
		DarkShadow = 245687,
		Alacrity = 193539,
		EnvelopingShadows = 238104,
		--100
		MasterofShadows = 196976,
		SecretTechnique = 280719,
		ShurikenTornado = 277925,
	}
	ids.Sub_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--

	}
	ids.Sub_Form = {

	}
	ids.Sub_Buff = {
		ShadowBlades = 121471,
		ShadowDance = 185422,
		ShurikenCombo = 245640,
		SymbolsofDeath = 212283,
		Vanish = 11327,
	}
	ids.Sub_Debuff = {
		FindWeakness = 91021,
		MarkedforDeath = 137619,
		Nightblade = 195452,
	}
	ids.Sub_PetAbility = {
		
	}