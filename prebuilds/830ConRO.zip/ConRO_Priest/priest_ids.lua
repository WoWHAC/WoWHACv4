local ConRO_Priest, ids = ...;

--Generic
	ids.Racial = {
		ArcaneTorrent = 232633,
		ArcanePulse = 260364,
	}
	ids.Glyph = {
		Lightspawn = 254224,
		Sha = 132603,
		Voidling = 254232,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.Priest_AzTrait = {
		DeathThroes = 278659,
		ThoughtHarvester = 288340,
	}
	ids.Priest_AzTraitBuff = {
		ThoughtHarvester = 288343,
	}
	ids.AzEssence = {
		BloodoftheEnemy = 298273,
		ConcentratedFlame = 295373,
		FocusedAzeriteBeam =295258,
		GuardianofAzeroth = 299358,
		MemoryofLucidDream = 298357,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,
	}
	ids.AzEssenceBuff = {
		MemoryofLucidDream = 298357,
	}
	ids.AzEssenceDebuff = {
		ConcentratedFlame = 295368,
	}

--Discipline
	ids.Disc_Ability = {
		DesperatePrayer = 19236,
		DispelMagic = 528,
		Fade = 586,
		HolyNova = 132157,
		LeapofFaith = 73325,
		Levitate = 1706,
		MassDispel = 32375,
		MassResurrection = 212036,
		MindControl = 605,
		MindVision = 2096,
		PainSuppression = 33206,
		Penance = 47540,
		Plea = 200829,
		PowerWordBarrier = 62618,
		PowerWordFortitude = 21562,
		PowerWordRadiance = 194509,
		PowerWordShield = 17,
		PsychicScream = 8122,
		Purify = 527,
		Rapture = 47536,
		Resurrection = 2006,
		ShackleUndead = 9484,
		ShadowMend = 186263,
		ShadowWordPain = 589,
		Shadowfiend = 34433,
		Smite = 585,
	}
	ids.Disc_Passive = {
		Atonement = 81749,
		FocusedWill = 45243,
		MasteryGrace = 271534,
		PoweroftheDarkSide = 198068,
	}
	ids.Disc_Talent = {
		--15
		Castigation = 193134,		
		TwistofFate = 265259,
		Schism = 214621,
		--30
		BodyandSoul = 64129,		
		Masochism = 193063,		
		AngelicFeather = 121536,
		--45
		ShieldDiscipline = 197045,		
		Mindbender = 123040,		
		PowerWordSolace = 129250,
		--60
		PsychicVoice = 196704,
		DominantMind = 205367,
		ShiningForce = 204263,
		--75
		SinsoftheMany = 280391,
		Contrition = 197419,
		ShadowCovenant = 204065,
		--90
		PurgetheWicked = 204197,
		DivineStar = 110744,
		Halo = 120517,
		--100
		Lenience = 238063,
		LuminousBarrier = 271466,
		Evangelism = 246287,
	}
	ids.Disc_Form = {
	
	}
	ids.Disc_Buff = {
		Atonement = 194384,
		PowerWordFortitude = 21562,
		PoweroftheDarkSide = 198069,
	}
	ids.Disc_Debuff = {
		PurgetheWicked = 204213,
		ShadowWordPain = 589,
		WeakenedSoul = 6788,		
	}
	ids.Disc_PetAbility = {
			
	}
		
--Holy
	ids.Holy_Ability = {
		DesperatePrayer = 19236,
		DispelMagic = 528,
		DivineHymn = 64843,
		Fade = 586,
		FlashHeal = 2061,
		GuardianSpirit = 47788,
		Heal = 2060,
		HolyFire = 14914,
		HolyNova = 132157,
		HolyWordChastise = 88625,
		HolyWordSanctify = 34861,
		HolyWordSerenity = 2050,
		LeapofFaith = 73325,
		Levitate = 1706,
		MassDispel = 32375,
		MassResurrection = 212036,
		MindControl = 605,
		MindVision = 2096,
		PowerWordFortitude = 21562,
		PrayerofHealing = 596,
		PrayerofMending = 33076,
		PsychicScream = 8122,
		Purify = 527,
		Renew = 139,
		Resurrection = 2006,
		ShackleUndead = 9484,
		Smite = 585,
		SymbolofHope = 64901,
	}
	ids.Holy_Passive = {
		FocusedWill = 45243,
		MasteryEchoofLight = 77485,
		SpiritofRedemption = 20711,
	}
	ids.Holy_Talent = {
		--15
		Enlightenment = 193155,		
		TrailofLight = 200128,		
		EnduringRenewal = 200153,
		--30
		AngelsMercy = 238100,
		Perseverance = 235189,	
		AngelicFeather = 121536,
		--45
		CosmicRipple = 238136,
		GuardianAngel = 200209,
		Afterlife = 196707,
		--60
		PsychicVoice = 196704,
		Censure = 200199,
		ShiningForce = 204263,
		--75
		SurgeofLight = 109186,
		BindingHeal = 32546,
		CircleofHealing = 204883,
		--90
		Benediction = 193157,
		DivineStar = 110744,
		Halo = 120517,
		--100
		LightoftheNaaru = 196985,
		Apotheosis = 200183,
		HolyWordSalvation = 265202,
	}
	ids.Holy_Form = {
	
	}
	ids.Holy_Buff = {
		PowerWordFortitude = 21562,
	}
	ids.Holy_Debuff = {

	}
	ids.Holy_PetAbility = {
		
	}

--Shadow
	ids.Shad_Ability = {
		DispelMagic = 528,
		Dispersion = 47585,
		Fade = 586,
		LeapofFaith = 73325,
		Levitate = 1706,
		MassDispel = 32375,
		MindBlast = 8092,
		MindControl = 605,
		MindFlay = 15407,
		MindSear = 48045,
		MindVision = 2096,
		PowerWordFortitude = 21562,
		PowerWordShield = 17,
		PsychicScream = 8122,
		PurifyDisease = 213634,
		Resurrection = 2006,
		ShackleUndead = 9484,
		ShadowMend = 186263,
		ShadowWordPain = 589,
		Shadowfiend = 34433,
		Shadowform = 232698,
		Silence = 15487,
		VampiricEmbrace = 15286,
		VampiricTouch = 34914,
		VoidBolt = 205448,
		VoidEruption = 228260,
	}
	ids.Shad_Passive = {
		Hallucinations = 280752,
		MasteryMadness = 77486,
		ShadowyApparitions = 78203,
		VoidBolt = 228266,
		VoidForm = 228264,
	}
	ids.Shad_Talent = {
		--15
		FortressoftheMind = 193195,
		ShadowyInsight = 162452,
		ShadowWordVoid = 205351,
		--30
		BodyandSoul = 64129,
		Sanlayn = 199855,
		Intangibility = 288733,
		--45
		TwistofFate = 109142,
		Misery = 238558,
		DarkVoid = 263346,
		--60
		LastWord = 263716,
		MindBomb = 205369,
		PsychicHorror = 64044,
		--75
		AuspiciousSpirits = 155271,
		ShadowWordDeath = 32379,
		ShadowCrash = 205385,
		--90
		LingeringInsanity = 199849,
		Mindbender = 200174,
		VoidTorrent = 263165,
		--100
		LegacyoftheVoid = 193225,
		DarkAscension = 280711,
		SurrendertoMadness = 193223,
	}
	ids.Shad_Form = {
		Shadowform = 232698,
		Voidform = 194249,
		SurrendertoMadness = 193223,
	}
	ids.Shad_Buff = {
		PowerWordFortitude = 21562,
		PowerWordShield = 17,
		ShadowyInsight = 162452,
		VampiricEmbrace = 15286,
	}
	ids.Shad_Debuff = {
		ShadowWordPain = 589,
		VampiricTouch = 34914,
		WeakenedSoul = 6788,
	}
	ids.Shad_PetAbility = {
		
	}