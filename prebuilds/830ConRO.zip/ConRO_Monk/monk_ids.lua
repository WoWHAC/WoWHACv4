local ConRO_Monk, ids = ...;

--Generic
	ids.Racial = {
		ArcanePulse = 260364,
		ArcaneTorrent = 129597,
		Berserking = 26297,
		GiftoftheNaaru = 59548,
	}
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.Monk_AzTrait = {
		DanceofChiJi = 286585,
		MistyPeaks = 275975,
	}
	ids.Monk_AzTraitBuff = {
		DanceofChiJi = 286587,
	}
	ids.AzEssence = {
		BloodoftheEnemy = 298273,
		ConcentratedFlame = 295373,
		FocusedAzeriteBeam =295258,
		GuardianofAzeroth = 299358,
		MemoryofLucidDream = 298357,
		ReapingFlames = 310690,		
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}
	ids.AzEssenceBuff = {
		MemoryofLucidDream = 298357,	
	}
	ids.AzEssenceDebuff = {	
		ConcentratedFlame = 295368,
	}
	
--Brewmaster
	ids.Bm_Ability = {
		BlackoutStrike = 205523,
		BreathofFire = 115181,
		CracklingJadeLightning = 117952,
		Detox = 218164,
		ExpelHarm = 115072,
		FortifyingBrew = 115203,
		IronskinBrew = 115308,
		KegSmash = 121253,
		LegSweep = 119681,
		Paralysis = 115078,
		Provoke = 115546,
		PurifyingBrew = 119582,
		Resuscitate = 115178,
		Roll = 109132,
		SpearHandStrike = 116705,
		TigerPalm = 100780,
		Transcendence = 101643,
			TranscendenceTransfer = 119996,
		Vivify = 116670,
		ZenMeditation = 115176,
		ZenPilgrimage = 126892,
	}
	ids.Bm_Passive = {
		BrewmastersBalance = 245013,
		CelestialFortune = 216519,
		GiftoftheOx = 124502,
		MasteryElusiveBrawler = 117906,
		MysticTouch = 8647,
		Stagger = 115069,
	}
	ids.Bm_Talent = {
		--15
		EyeoftheTiger = 196607,		
		ChiWave = 115098,		
		ChiBurst = 123986,		
		--30		
		Celerity = 115173,		
		ChiTorpedo = 115008,
		TigersLust = 116841,		
		--45		
		LightBrewing = 196721,
		Spitfire = 242580,
		BlackOxBrew = 115399,		
		--60
		TigerTailSweep = 264348,
		SummonBlackOxStatue = 115315,
		RingofPeace = 116844,
		--75
		BobandWeave = 280515,
		HealingElixir = 122281,
		DampenHarm = 122278,
		--90
		SpecialDelivery = 196730,
		RushingJadeWind = 116847,
		InvokeNiuzaotheBlackOx = 132578,
		--100
		HighTolerance = 196737,
		Guard = 115295,
		BlackoutCombo = 196736,
	}
	ids.Bm_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--	
	}
	ids.Bm_Form = {
	
	}
	ids.Bm_Buff = {
		BlackoutCombo = 228563,
		ChiTorpedo = 119085,
		IronskinBrew = 215479,
		RushingJadeWind = 116847,
	}
	ids.Bm_Debuff = {
		KegSmash = 121253,
		LightStagger = 124275,
		MediumStagger = 124274,
		HighStagger = 124273,
	}
	ids.Bm_PetAbility = {

	}
		
--Mistweaver
	ids.Mw_Ability = {
		BlackoutKick = 100784,
		CracklingJadeLightning = 117952,
		Detox = 115450,
		EnvelopingMist = 124682,
		EssenceFont = 191837,
		FortifyingBrew = 243435,
		LegSweep = 119381,
		LifeCocoon = 116849,
		Paralysis = 115078,
		Provoke = 115546,
		Reawaken = 212051,
		RenewingMist = 115151,
		Resuscitate = 115178,
		Revival = 115310,
		RisingSunKick = 107428,
		Roll = 109132,
		SoothingMist = 115175,
		SpinningCraneKick = 101546,
		ThunderFocusTea = 116680,
		TigerPalm = 100780,
		Transcendence = 101643,
			TranscendenceTransfer = 119996,
		Vivify = 116670,
		ZenPilgrimage = 126892,		
	}
	ids.Mw_Passive = {
		MasteryGustofMists = 117907,
		MysticTouch = 8647,
		TeachingsoftheMonastery = 116645,
	}
	ids.Mw_Talent = {
		--15
		MistWrap = 197900,		
		ChiWave = 115098,		
		ChiBurst = 123986,		
		--30		
		Celerity = 115173,		
		ChiTorpedo = 115008,		
		TigersLust = 116841,		
		--45		
		Lifecycles = 197915,		
		SpiritoftheCrane = 210802,
		ManaTea = 197908,		
		--60		
		TigerTailSweep = 264348,
		SongofChiJi = 198898,		
		RingofPeace = 116844,		
		--75		
		HealingElixir = 122281,	
		DiffuseMagic = 122783,
		DampenHarm = 122278,
		--90
		SummonJadeSerpentStatue = 115313,
		RefreshingJadeWind = 193725,
		InvokeChiJitheRedCrane = 198664,	
		--100
		FocusedThunder = 197895,
		Upwelling = 274963,
		RisingMist = 274909,
	}
	ids.Mw_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--	
	}	
	ids.Mw_Form = {
	
	}
	ids.Mw_Buff = {
		ChiTorpedo = 119085,	
		RenewingMist = 119611,
		TeachingsoftheMonastery = 202090,
	}
	ids.Mw_Debuff = {

	}
	ids.Mw_PetAbility = {

	}

--Windwalker
	ids.Ww_Ability = {
		BlackoutKick = 100784,
		CracklingJadeLightning = 117952,
		Detox = 218164,
		Disable = 116095,
		FistsofFury = 113656,
		FlyingSerpentKick = 101545,
			FlyingSerpentKickStop = 115057,
		LegSweep = 119381,
		Paralysis = 115078,
		Provoke = 115546,
		Resuscitate = 115178,
		RisingSunKick = 107428,
		Roll = 109132,		
		SpearHandStrike = 116705,
		SpinningCraneKick = 101546,	
		StormEarthandFire = 137639,		
		TigerPalm = 100780,
		TouchofDeath = 115080,
		TouchofKarma = 122470,
		Transcendence = 101643,
			TranscendenceTransfer = 119996,
		Vivify = 116670,
		ZenPilgrimage = 126892,
	}
	ids.Ww_Passive = {
		Afterlife = 116092,
		MasteryComboStrikes = 115636,
		MysticTouch = 8647,
		Windwalking = 157411,
	}
	ids.Ww_Talent = {
		--15
		EyeoftheTiger = 196607,
		ChiWave = 115098,
		ChiBurst = 123986,
		--30
		Celerity = 115173,
		ChiTorpedo = 115008,
		TigersLust = 116841,
		--45
		Ascension = 115396,
		FistoftheWhiteTiger = 261947,
		EnergizingElixir = 115288,
		--60
		TigerTailSweep = 264348,
		GoodKarma = 280195,
		RingofPeace = 116844,
		--75
		InnerStrength = 261767,
		DiffuseMagic = 122783,
		DampenHarm = 122278,		
		--90
		HitCombo = 196740,
		RushingJadeWind = 261715,
		InvokeXuentheWhiteTiger = 123904,
		--100
		SpiritualFocus = 280197,
		WhirlingDragonPunch = 152175,
		Serenity = 152173,
	}
	ids.Ww_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--	
		ReverseHarm = 287771,
	}	
	ids.Ww_Form = {
		TheEmperorsCapacitor = 235054,
	}
	ids.Ww_Buff = {
		BlackoutKick = 116768,
		ChiTorpedo = 119085,		
		Serenity = 152173, --DoubleCheck
		StormEarthandFire = 137639,
	}
	ids.Ww_Debuff = {
		MarkoftheCrane = 228287,
	}
	ids.Ww_PetAbility = {
	
	}