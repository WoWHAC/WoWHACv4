local ConRO_Paladin, ids = ...;

--Generic
	ids.Racial = {
		ArcaneTorrent = 155145,
	}
	ids.Glyph = {
		Queen = 212641,	
	}	
	ids.AzTrait = {

	}
	ids.AzTraitBuff = {

	}
	ids.Paladin_AzTrait = {
		EmpyreanPower = 286390,
	}
	ids.Paladin_AzTraitBuff = {
		EmpyreanPower = 286393,	
	}
	ids.AzEssence = {
		BloodoftheEnemy = 298273,
		ConcentratedFlame = 295373,
		GuardianofAzeroth = 299358,
		MemoryofLucidDream = 298357,
		ReapingFlames = 310690,
		TheUnboundForce = 298452,
		WorldveinResonance = 295186,	
	}
	ids.AzEssenceBuff = {
		MemoryofLucidDream = 298357,	
	}
	
--Holy
	ids.Holy_Ability = {
		Absolution = 212056,
		AuraMastery = 31821,
		AvengingWrath = 31884,
		BeaconofLight = 53563,
		BlessingofFreedom = 1044,
		BlessingofProtection = 1022,
		BlessingofSacrifice = 6940,
		Cleanse = 4987,
		Consecration = 26573,
		Contemplation = 121183,
		CrusaderStrike = 35395,
		DivineProtection = 498,
		DivineShield = 642,
		DivineSteed = 190784,
		FlashofLight = 19750,
		HammerofJustice = 853,
		HandofReckoning = 62124,
		HolyLight = 82326,
		HolyShock = 20473,
		Judgment = 275773,
		LayonHands = 633,
		LightofDawn = 85222,
		LightoftheMartyr = 183998,
		Redemption = 7328,
	}
	ids.Holy_Passive = {
		HeartoftheCrusader = 32223,
		InfusionofLight = 53576,
		MasteryLightbringer = 183997,
	}
	ids.Holy_Talent = {
		--15
		CrusadersMight = 196926,
		BestowFaith = 223306,
		LightsHammer = 114158,
		--30
		UnbreakableSpirit = 114154,
		Cavalier = 230332,
		RuleofLaw = 214202,
		--45
		FistofJustice = 198054,
		Repentance = 20066,
		BlindingLight = 115750,
		--60
		DevotionAura = 183425,
		AuraofSacrifice = 183416,
		AuraofMercy = 183415,
		--75
		JudgmentofLight = 183778,
		HolyPrism = 114165,
		HolyAvenger = 105809,
		--90
		SanctifiedWrath = 53376,
		AvengingCrusader = 216331,
		Awakening = 248033,
		--100
		DivinePurpose = 197646,
		BeaconofFaith = 156910,
		BeaconofVirtue = 200025,
	}
	ids.Holy_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--

	}	   
	ids.Holy_Form = {
		BeaconofFaith = 156910,
		BeaconofLight = 53563, 
	}
	ids.Holy_Buff = {
			
	}
	ids.Holy_Debuff = {
		Forbearance = 25771,
	}
	ids.Holy_PetAbility = {
			
	}
		
--Protection
	ids.Prot_Ability = {
		ArdentDefender = 31850,
		AvengersShield = 31935,
		AvengingWrath = 31884,
		BlessingofFreedom = 1044,
		BlessingofProtection = 1022,
		BlessingofSacrifice = 6940,
		CleanseToxins = 213644,
		Consecration = 26573,
		Contemplation = 121183,
		DivineShield = 642,
		DivineSteed = 190784,
		FlashofLight = 19750,
		GuardianofAncientKings = 86659,
		HammerofJustice = 853,
		HammeroftheRighteous = 53595,
		HandofReckoning = 62124,
		Judgment = 275779,
		LayonHands = 633,
		LightoftheProtector = 184092,
		Rebuke = 96231,
		Redemption = 7328,
		ShieldoftheRighteous = 53600,
		GrandCrusader = 85043,
	}
	ids.Prot_Passive = {
		HeartoftheCrusader = 32223,
		MasteryDivineBulwark = 76671,
	}
	ids.Prot_Talent = {
		--15
		HolyShield = 152261,
		Redoubt = 280373,
		BlessedHammer = 204019,
		--30
		FirstAvenger = 203776,
		CrusadersJudgment = 204023,
		BastionofLight = 204035,
		--45
		FistofJustice = 198054,
		Repentance = 20066,
		BlindingLight = 115750,
		--60
		RetributionAura = 203797,
		Cavalier = 230332,
		BlessingofSpellwarding = 204018,
		--75
		UnbreakableSpirit = 114154,
		FinalStand = 204077,
		HandoftheProtector = 213652,
		--90
		JudgmentofLight = 183778,
		ConsecratedGround = 204054,
		AegisofLight = 204150,
		--100
		LastDefender = 203791,
		RighteousProtector = 204074,
		Seraphim = 152262,
	}
	ids.Prot_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--

	}	
	ids.Prot_Form = {
		Consecration = 188370,
	}
	ids.Prot_Buff = {
		AvengersValor = 197561,
		AvengingWrath = 31884,
	}
	ids.Prot_Debuff = {
		BlessedHammer = 204301,
		Forbearance = 25771,
	}
	ids.Prot_PetAbility = {
		
	}

--Retribution
	ids.Ret_Ability = {
		AvengingWrath = 31884,
		BladeofJustice = 184575,
		BlessingofFreedom = 1044,
		BlessingofProtection = 1022,
		CleanseToxins = 213644,
		Contemplation = 121183,
		CrusaderStrike = 35395,
		DivineShield = 642,
		DivineSteed = 190784,
		DivineStorm = 53385,
		FlashofLight = 19750,
		GreaterBlessingofKings = 203538,
		GreaterBlessingofWisdom = 203539,
		HammerofJustice = 853,
		HandofHindrance = 183218,
		HandofReckoning = 62124,
		Judgment = 20271,
		LayonHands = 633,
		Rebuke = 96231,
		Redemption = 7328,
		ShieldofVengeance = 184662,
		TemplarsVerdict = 85256,
	}
	ids.Ret_Passive = {
		ArtofWar = 267344,
		HeartoftheCrusader = 32223,
		MasteryHandofLight = 267316,
		Retribution = 183435,
	}
	ids.Ret_Talent = {
		--15
		Zeal = 269569,
		RighteousVerdict = 267610,
		ExecutionSentence = 267798,
		--30
		FiresofJustice = 203316,
		BladeofWrath = 231832,
		HammerofWrath = 24275,
		--45
		FistofJustice = 234299,
		Repentance = 20066,
		BlindingLight = 115750,
		--60
		DivineJudgment = 271580,
		Consecration = 205228,
		WakeofAshes = 255937,
		--75
		UnbreakableSpirit = 114154,
		Cavalier = 230332,
		EyeforanEye = 205191,
		--90
		SelflessHealer = 85804,
		JusticarsVengeance = 215661,
		WordofGlory = 210191,
		--100
		DivinePurpose = 223817,
		Crusade = 231895,
		Inquisition = 84963,
	}
	ids.Ret_PvPTalent = {
		--Honorable Medallion
		Adaptation = 214027,
		Relentless = 196029,
		GladiatorsMedallion = 208683,
		--
		Luminescence = 199428,
		UnboundFreedom = 305394,
		VengeanceAura = 210323,
		BlessingofSanctuary = 210256,
		UltimateRetribution = 287947,
		Lawbringer = 246806,
		DivinePunisher = 204914,
		HammerofReckoning = 247675,
		Jurisdiction = 204979,
		LawandOrder = 204934,
		CleansingLight = 236186,
	}	
	ids.Ret_Form = {
		GreaterBlessingofKings = 203538,
		GreaterBlessingofWisdom = 203539,
	}
	ids.Ret_Buff = {
		AvengingWrath = 31884,
		Crusade = 231895,
		RighteousVerdict = 267611,
		DivinePurpose = 223819,
		Inquisition = 84963,
	}
	ids.Ret_Debuff = {
		Judgment = 197277,
		Forbearance = 25771,
	}
	ids.Ret_PetAbility = {
		
	}