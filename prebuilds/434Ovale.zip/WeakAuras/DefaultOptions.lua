--[[ Manual override for the default font and font size until proper options are built ]]

WeakAuras.defaultFont = "Friz Quadrata TT"
WeakAuras.defaultFontSize = 12
