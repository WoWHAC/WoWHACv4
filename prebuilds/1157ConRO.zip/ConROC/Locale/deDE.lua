local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "deDE" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "Du kennst derzeit keine der Zauber oder Optionen, die hier aufgelistet werden sollen."
