local L = LibStub( "AceLocale-3.0" ):NewLocale( "ConROC", "itIT" )
if not L then return end

L["NO_SPELLS_TO_LIST"] = "Attualmente non conosci nessuno degli incantesimi o delle opzioni che devono essere elencati qui."
