-- Paladin.lua
-- August 2014

local addon, ns = ...
local Hekili = _G[ addon ]

local class = ns.class
local state = ns.state

local addHook = ns.addHook

local addAbility = ns.addAbility
local modifyAbility = ns.modifyAbility
local addHandler = ns.addHandler

local addAura = ns.addAura
local modifyAura = ns.modifyAura

local addGearSet = ns.addGearSet
local addGlyph = ns.addGlyph
local addMetaFunction = ns.addMetaFunction
local addTalent = ns.addTalent
local addPerk = ns.addPerk
local addResource = ns.addResource
local addStance = ns.addStance

local removeResource = ns.removeResource

local setClass = ns.setClass
local setPotion = ns.setPotion
local setRole = ns.setRole

local RegisterEvent = ns.RegisterEvent
local storeDefault = ns.storeDefault


-- TODO: PUT LAST_JUDGMENT_TARGET BACK IN!

-- This table gets loaded only if there's a supported class/specialization.
if (select(2, UnitClass('player')) == 'PALADIN') then

  ns.initializeClassModule = function ()

    setClass( 'PALADIN' )

    -- addResource( SPELL_POWER_HEALTH )
    addResource( 'mana', true )
    addResource( 'holy_power' )

    addTalent( 'speed_of_light', 85499 )
    addTalent( 'long_arm_of_the_law', 87172 )
    addTalent( 'pursuit_of_justice', 26023 )

    addTalent( 'fist_of_justice', 105593 )
    addTalent( 'repentance', 200066 )
    addTalent( 'blinding_light', 115750 )

    addTalent( 'selfless_healer', 85804 )
    addTalent( 'eternal_flame', 114163 )
    addTalent( 'sacred_shield', 20925 )

    addTalent( 'hand_of_purity', 114039 )
    addTalent( 'unbreakable_spirit', 114154 )
    addTalent( 'clemency', 105622 )

    addTalent( 'holy_avenger', 105809 )
    addTalent( 'sanctified_wrath', 53376 )
    addTalent( 'divine_purpose', 86172 )

    addTalent( 'holy_prism', 114165 )
    addTalent( 'lights_hammer', 114158 )
    addTalent( 'execution_sentence', 114157 )

    addTalent( 'empowered_seals', 152263 )
    addTalent( 'seraphim', 152262 )
    addTalent( 'final_verdict', 157048 )
    addTalent( 'holy_shield', 152261 )

    -- Glyphs.
    -- addGlyph( 'alabaster_shield', 63222 ) -- removed 6.1
    addGlyph( 'ardent_defender', 159548 )
    addGlyph( 'avenging_wrath', 54927 )
    addGlyph( 'battle_healer', 119477 )
    addGlyph( 'beacon_of_light', 63218 )
    addGlyph( 'bladed_judgment', 115934 )
    addGlyph( 'blessed_life', 54943 )
    addGlyph( 'burden_of_guilt', 54931 )
    addGlyph( 'consecration', 54928 )
    addGlyph( 'consecrator', 159557 )
    addGlyph( 'contemplation', 125043 )
    addGlyph( 'dazing_shield', 56414 )
    addGlyph( 'denounce', 56420 )
    addGlyph( 'devotion_aura', 146955 )
    addGlyph( 'divine_protection', 54924 )
    addGlyph( 'divine_shield', 146956 )
    addGlyph( 'divine_storm', 63220 )
    addGlyph( 'divine_wrath', 159572 )
    addGlyph( 'divinity', 54939 )
    addGlyph( 'double_jeopardy', 54992 )
    addGlyph( 'exorcist', 146958 )
    addGlyph( 'falling_avenger', 115931 )
    addGlyph( 'final_wrath', 54935 )
    addGlyph( 'fire_from_the_heavens', 57954 )
    addGlyph( 'flash_of_light', 57955 )
    addGlyph( 'focused_shield', 54930 )
    addGlyph( 'focused_wrath', 115738 )
    addGlyph( 'hammer_of_the_righteous', 63219 )
    addGlyph( 'hand_of_freedom', 159579 )
    addGlyph( 'hand_of_sacrifice', 146957 )
    addGlyph( 'harsh_words', 54938 ) -- holy only in 6.1
    addGlyph( 'holy_shock', 63224 )
    addGlyph( 'holy_wrath', 54923 )
    addGlyph( 'illumination', 54937 )
    addGlyph( 'immediate_truth', 56416 ) -- ret only in 6.1
    addGlyph( 'inquisition', 63225 )
    addGlyph( 'judgment', 159592 )
    addGlyph( 'liberator', 159573 )
    addGlyph( 'light_of_dawn', 54940 )
    addGlyph( 'luminous_charger', 89401 )
    addGlyph( 'mass_exorcism', 122028 )
    addGlyph( 'merciful_wrath', 162604 )
    addGlyph( 'mounted_king', 57958 )
    addGlyph( 'pillar_of_light', 146959 )
    addGlyph( 'protector_of_the_innocent', 93466 )
    addGlyph( 'righteous_retreat', 115933 )
    addGlyph( 'seal_of_blood', 57947 )
    addGlyph( 'templars_verdict', 54926 )
    addGlyph( 'winged_vengeance', 57979 )
    addGlyph( 'word_of_glory', 54936 )

    -- Player Buffs.
    addAura( 'ardent_defender', 31850 )
    addAura( 'avengers_reprieve', 185676, 'duration', 10 )
    addAura( 'avenging_wrath', 31884 )
    addAura( 'bastion_of_power', 144569 )
    addAura( 'bastion_of_glory', 114637, 'max_stack', 5 )
    addAura( 'blazing_contempt', 166831 )
    addAura( 'blessing_of_kings', 20217 )
    addAura( 'blessing_of_might', 19740 )
    addAura( 'divine_crusader', 144595 )
    addAura( 'divine_protection', 498 )
    addAura( 'divine_purpose', 90174 )
    addAura( 'divine_shield', 642 )
    addAura( 'eternal_flame', 156322 )
    addAura( 'execution_sentence', 114157 )
    addAura( 'faith_barricade', 165447, 'duration', 5 )
    addAura( 'forbearance', 25771, 'unit', 'player' )
    addAura( 'final_verdict', 157048 )
    addAura( 'focus_of_vengeance', 184911, 'duration', 10, 'max_stack', 3 )
    addAura( 'grand_crusader', 85043 )
    addAura( 'guardian_of_ancient_kings', 86659 )
    addAura( 'hand_of_freedom', 1044 )
    addAura( 'hand_of_protection', 1022 )
    addAura( 'hand_of_sacrifice', 6940 )
    addAura( 'holy_avenger', 105809 )
    addAura( 'liadrins_righteousness', 156989, 'duration', 20  )
    addAura( 'maraads_truth', 156990, 'duration', 20  )
    addAura( 'righteous_fury', 25780 )
    addAura( 'sacred_shield', 20925, 'fullscan', true, 'friendly', true )
    addAura( 'sacred_shield_proc', 65148, 'fullscan', true, 'friendly', true )
    addAura( 'seal_of_command', 105361 )
    addAura( 'seal_of_insight', 20165 )
    addAura( 'selfless_healer', 114250 )
    addAura( 'seraphim', 152262 )
    addAura( 'shield_of_the_righteous', 132403 )
    addAura( 'turalyons_justice', 156987, 'duration', 20 )
    addAura( 'uthers_insight', 156988, 'duration', 20 )

    -- Perks.
    addPerk( 'empowered_divine_storm', 174718 )
    addPerk( 'empowered_hammer_of_wrath', 157496 )
    addPerk( 'enhanced_hand_of_sacrifice', 157493 )
    addPerk( 'improved_forbearance', 157482 )
    addPerk( 'empowered_avengers_shield', 157485 )
    addPerk( 'improved_block', 157488 )
    addPerk( 'improved_consecration', 157486 )

    -- Stances.
    addStance( 'truth', 31801 )
    addStance( 'righteousness', 20154 )
    addStance( 'justice', 20164 )
    addStance( 'insight', 20165 )

    -- Pick an instant cast ability for checking the GCD.
    -- setGCD( 'blessing_of_kings' )

    -- Gear Sets
    addGearSet( 'tier17', 115565, 115566, 115567, 115568, 115569 )
    addGearSet( 'tier18', 124318, 124328, 124333, 124339, 124345 )
    addGearSet( 't18_class_trinket', 124518 )
    

    -- Seals are stances.
    state.seal = state.stance

    addMetaFunction( 'state', 'time_to_hpg', function ()
      local t = action.hammer_of_wrath.ready_time

      if action.crusader_strike.ready_time < t then t = action.crusader_strike.ready_time end
      if spec.retribution and action.exorcism.ready_time < t then t = action.exorcism.ready_time end
      if action.judgment.ready_time < t then t = action.judgment.ready_time end

      return t
    end )

    addHook( 'specializationChanged', function ()
    
      setPotion( state.spec.retribution and 'draenic_strength' or 'draenic_armor' )
      setRole( state.spec.protection and 'tank' or 'attack' )
      
    end )

    ns.addToggle( 'tier90', true, "Tier 90 Talents", "Toggling this keybinding will enable or disable Tier 90 Talents (|cFFFFD100toggle.tier90|r) in the default action lists." )
    ns.addToggle( 'mitigation', true, "Mitigation", "Toggling this keybinding will enable or disable mitigation abilities (|cFFFFD100toggle.mitigation|r) in the default action lists." )

    ns.addSetting( 'cs_clash', 0, {
      name = "Clash: Crusader Strike",
      type = "range",
      desc = "Provides an additional grace period for Crusader Strike.  The ability is treated as though its cooldown is shorter by this amount.  This overrides the global Cooldown Clash setting.",
      min = 0,
      max = 2,
      step = 0.01,
    } )

    ns.addSetting( 'exo_clash', 0, {
      name = "Clash: Exorcism",
      type = "range",
      desc = "Provides an additional grace period for Exorcism.  The ability is treated as though its cooldown is shorter by this amount.  This overrides the global Cooldown Clash setting.",
      min = 0,
      max = 2,
      step = 0.01,
    } )

    ns.addSetting( 'how_clash', 0, {
      name = "Clash: Hammer of Wrath",
      type = "range",
      desc = "Provides an additional grace period for Hammer of Wrath.  The ability is treated as though its cooldown is shorter by this amount.  This overrides the global Cooldown Clash setting.",
      min = 0,
      max = 2,
      step = 0.01,
    } )

    ns.addSetting( 'j_clash', 0, {
      name = "Clash: Judgment",
      type = "range",
      desc = "Provides an additional grace period for Judgment.  The ability is treated as though its cooldown is shorter by this amount.  This overrides the global Cooldown Clash setting.",
      min = 0,
      max = 2,
      step = 0.01,
    } )

    ns.addWhitespace( 'end_of_clashes', 'double' )

    ns.addSetting( 'mitigate_dp', 15, {
      name = "Mitigation: Divine Protection",
      type = "range",
      desc = "For Divine Protection to be recommended as a damage mitigation cooldown, the addon will require that you have received at least this much damage (as a percentage of maximum health) in the past 1.5 seconds.",
      min = 0,
      max = 100,
      step = 1
    } )

    ns.addSetting( 'mitigate_goak', 30, {
      name = "Mitigation: Guardian of Ancient Kings",
      type = "range",
      desc = "For Guardian of Ancient Kings to be recommended as a damage mitigation cooldown, the addon will require that you have received at least this much damage (as a percentage of maximum health) in the past 1.5 seconds.",
      min = 0,
      max = 100,
      step = 1
    } )

    ns.addSetting( 'mitigate_ad', 40, {
      name = "Mitigation: Ardent Defender",
      type = "range",
      desc = "For Ardent Defender to be recommended as a damage mitigation cooldown, the addon will require that you have received at least this much damage (as a percentage of maximum health) in the past 1.5 seconds.",
      min = 0,
      max = 100,
      step = 1
    } )


    -- inserts clash values
    addHook( "clash", function( clash, ability )
      if ability == 'crusader_strike' then
        return state.settings.cs_clash
      elseif ability == 'exorcism' then
        return state.settings.exo_clash
      elseif ability == 'hammer_of_wrath' then
        return state.settings.how_clash
      elseif ability == 'judgment' then
        return state.settings.j_clash
      end
      return clash
    end )


    RegisterEvent( "UNIT_SPELLCAST_SUCCEEDED", function( _, unit, spell, _, spellID )

        if unit == 'player' and spell == class.abilities[ 'judgment' ].name then
          state.last_judgment_target = UnitGUID( 'target' )
        end

    end )


    addAbility( 'avengers_shield',
      {
        id = 31935,
        spend = 0.07,
        spend_type = 'mana',
        cast = 0,
        gcdType = 'spell',
        cooldown = 15
      } )

    modifyAbility( 'avengers_shield', 'cooldown', function ( x )
      return x * haste
    end )

    addHandler( 'avengers_shield', function ()
      if buff.grand_crusader.up then
        gain( 1, 'holy_power' )
        removeBuff( 'grand_crusader' )
      end
      if set_bonus.tier17_2pc>0 then applyBuff( 'faith_barricade', 10 ) end
      if set_bonus.tier18_2pc>0 then applyBuff( 'avengers_reprieve', 10 ) end
      interrupt()
    end )


    addAbility( 'avenging_wrath',
      {
        id = 31884,
        spend = 0,
        cast = 0,
        gcdType = 'off',
        cooldown = 120,
        charges = 1,
        recharge = 120,
        passive = true,
        toggle = 'cooldowns',
        usable = function () return buff.avenging_wrath.down end
      } )
      
    modifyAbility( 'avenging_wrath', 'charges', function ( x )
      if set_bonus.tier18_2pc == 1 then return 3 end
      return x
    end )

    addHandler( 'avenging_wrath', function ()
      applyBuff( 'avenging_wrath', 20 )
    end )


    addAbility( 'blessing_of_kings',
      {
        id = 20217,
        spend = 0.05,
        cast = 0,
        gcdType = 'spell',
        passive = true,
        cooldown = 0,
        usable = function () return not buff.str_agi_int.up and not buff.mastery.mine end
      } )

    addHandler( 'blessing_of_kings', function ()
      if buff.blessing_of_might.mine then
        removeBuff( 'blessing_of_might' )
        removeBuff( 'mastery' )
      end
      applyBuff( 'blessing_of_kings', 3600 )
      applyBuff( 'str_agi_int', 3600 )
    end )


    addAbility( 'blessing_of_might',
      {
        id = 19740,
        spend = 0.05,
        cast = 0,
        gcdType = 'spell',
        passive = true,
        cooldown = 0,
        usable = function () return not buff.mastery.up and not buff.str_agi_int.mine end
        
      } )

    addHandler( 'blessing_of_might', function ()
      if buff.blessing_of_kings.mine then
        removeBuff( 'blessing_of_kings' )
        removeBuff( 'str_agi_int' )
      end
      applyBuff( 'blessing_of_might', 3600 )
      applyBuff( 'mastery', 3600 )
    end )


    addAbility( 'crusader_strike',
      {
        id = 35395,
        spend = 0.10,
        cast = 0,
        gcdType = 'melee',
        cooldown = 4.5
      } )

    modifyAbility( 'crusader_strike', 'cooldown', function( x )
      return x * haste
    end )

    addHandler( 'crusader_strike', function ()
      gain( buff.holy_avenger.up and 3 or 1, 'holy_power' )
      setCooldown( 'hammer_of_the_righteous', action.crusader_strike.cooldown )
      if spec.retribution and t18_class_trinket == 1 then
        addStack( 'focus_of_vengeance', 10, 1 )
      end
    end )


    addAbility( 'divine_protection',
      {
        id = 498,
        spend = 0.035,
        cast = 0,
        gcdType = 'off',
        cooldown = 30,
        toggle = 'mitigation',
        passive = true,
        usable = function () return incoming_damage_1500ms / health.max >= settings.mitigate_dp / 100 end,
      } )

    addHandler( 'divine_protection', function ()
      applyBuff( 'divine_protection', 8 )
    end )


    addAbility( 'guardian_of_ancient_kings',
      {
        id = 86659,
        spend = 0,
        cast = 0,
        gcdType = 'off',
        cooldown = 180,
        usable = function() return not debuff.forbearance.up and incoming_damage_1500ms / health.max >= settings.mitigate_goak / 100 end,
        passive = true,
        toggle = 'mitigation'
      } )

    addHandler( 'guardian_of_ancient_kings', function ()
      applyDebuff( 'player', 'forbearance', perk.improved_forbearance.enabled and 30 or 60 )
      applyBuff( 'guardian_of_ancient_kings', 8 )
    end )


    addAbility( 'ardent_defender',
      {
        id = 31850,
        spend = 0,
        cast = 0,
        gcdType = 'off',
        cooldown = 180,
        usable = function() return not debuff.forbearance.up and incoming_damage_1500ms / health.max >= settings.mitigate_ad / 100 end,
        passive = true,
        toggle = 'mitigation'
      } )

    addHandler( 'ardent_defender', function ()
      applyBuff( 'ardent_defender', 10 )
    end )


    addAbility( 'eternal_flame',
      {
        id = 114163,
        spend = 1,
        spend_type = 'holy_power',
        cast = 0,
        gcdType = 'off',
        passive = true,
        cooldown = 0
      } )

    modifyAbility( 'eternal_flame', 'spend', function ( x )
      if buff.bastion_of_power.up then return 0 end
      return max( x, min( 3, holy_power.current ) )
    end )

    addHandler( 'eternal_flame', function ()
      applyBuff( 'eternal_flame', 30 )
    end )


    addAbility( 'shield_of_the_righteous',
      {
        id = 53600,
        spend = 3,
        spend_type = 'holy_power',
        cast = 0,
        gcdType = 'off',
        cooldown = 1.5
      } )

    modifyAbility( 'shield_of_the_righteous', 'cooldown', function ( x )
      return x * haste
    end )

    addHandler( 'shield_of_the_righteous', function ()
      applyBuff( 'shield_of_the_righteous', 3 )
      addStack( 'bastion_of_glory', 20, 1 )
      if buff.bastion_of_glory.stack >= 3 then applyBuff( 'bastion_of_power', 20 ) end
    end )


    addAbility( 'divine_storm',
      {
        id = 53385,
        spend = function()
          if buff.divine_purpose.up or buff.divine_crusader.up then return 0, 'holy_power' end
          return 3, 'holy_power'
        end,
        cast = 0,
        gcdType = 'melee',
        cooldown = 0,
        hostile = true
      } )

    addHandler( 'divine_storm', function ()
      if buff.divine_crusader.up then removeBuff( 'divine_crusader' )
      elseif buff.divine_purpose.up then removeBuff( 'divine_purpose' ) end
      removeBuff( 'final_verdict' )
      spend( 3, 'holy_power' )
    end )

    addAbility( 'execution_sentence',
      {
        id = 114157,
        spend = 0.128,
        cast = 0,
        gcdType = 'spell',
        cooldown = 60,
        known = function() return talent.execution_sentence.enabled end,
        hostile = true,
        toggle = 'tier90'
      } )

    addHandler( 'execution_sentence', function ()
      applyDebuff( 'target', 'execution_sentence', 10 )
    end )


    addAbility( 'exorcism',
      {
        id = 879,
        known = 879,
        spend = 0.04,
        cast = 0,
        gcdType = 'spell',
        cooldown = 15,
        hostile = true
      }, 122032 )

    modifyAbility( 'exorcism', 'cooldown', function( x )
      return x * haste
    end )

    modifyAbility( 'exorcism', 'id', function ( x )
      if glyph.mass_exorcism.enabled then return 122032 end
      return x
    end )

    addHandler( 'exorcism', function ()
      if buff.blazing_contempt.up then
        gain( 3, 'holy_power' )
        removeBuff( 'blazing_contempt' )
      else
        gain( buff.holy_avenger.up and 3 or 1, 'holy_power' )
      end
    end )


    addAbility( 'final_verdict',
      {
        id = 157048,
        spend = function()
          if buff.divine_purpose.up then return 0, 'holy_power' end
          return 3, 'holy_power'
        end,
        cast = 0,
        gcdType = 'spell',
        cooldown = 0,
        known = function() return talent.final_verdict.enabled end,
        hostile = true
      } )

    addHandler( 'final_verdict', function()
      applyBuff( 'final_verdict', 30 )
      removeBuff( 'divine_purpose' )
    end )


    addAbility( 'flash_of_light',
      {
        id = 19750,
        spend = 0.20,
        spend_type = 'mana',
        cast = 1.5,
        gcdType = 'spell',
        passive = true,
        cooldown = 0
      } )

    modifyAbility( 'flash_of_light', 'spend', function ( x )
      return x * max( 0, ( 1 - ( 0.35 * buff.selfless_healer.stack ) ) )
    end )

    modifyAbility( 'flash_of_light', 'cast', function ( x )
      return x * max( 0, ( 1 - ( 0.35 * buff.selfless_healer.stack ) ) )
    end )


    addAbility( 'hammer_of_the_righteous',
      {
        id = 53595,
        spend = 0.03,
        cast = 0,
        gcdType = 'melee',
        cooldown = 4.5,
        hostile = true
      } )

    modifyAbility( 'hammer_of_the_righteous', 'cooldown', function( x )
      return x * haste
    end )

    addHandler( 'hammer_of_the_righteous', function ()
      gain( buff.holy_avenger.up and 3 or 1, 'holy_power' )
      setCooldown( 'crusader_strike', action.hammer_of_the_righteous.cooldown )
      if spec.retribution and t18_class_trinket == 1 then
        addStack( 'focus_of_vengeance', 10, 1 )
      end
    end )


    addAbility( 'hammer_of_wrath',
      {
        id = 24275,
        spend = 0.03,
        cast = 0,
        gcdType = 'melee',
        cooldown = 6,
        known = 24275,
        usable = function() return buff.avenging_wrath.up or IsUsableSpell( class.abilities[ 'hammer_of_wrath' ].id ) end,
        hostile = true
      } )
      
    class.abilities[ 158392 ] = class.abilities[ 24275 ]
    
    modifyAbility( 'hammer_of_wrath', 'id', function( x )
      if perk.empowered_hammer_of_wrath.enabled then return 158392 end
      return x
    end )

    modifyAbility( 'hammer_of_wrath', 'cooldown', function( x )
      if talent.sanctified_wrath.enabled and buff.avenging_wrath.up then
        x = x / 2
      end
      return x * haste
    end )

    addHandler( 'hammer_of_wrath', function ()
      if set_bonus.tier17_4pc==1 then applyBuff( "blazing_contempt", 20 ) end
      gain( buff.holy_avenger.up and 3 or 1, 'holy_power' )
    end )


    addAbility( 'harsh_word',
      {
        id = 136494,
        known = function() return glyph.harsh_words.enabled end,
        spend = 1,
        spend_type = 'holy_power',
        cast = 0,
        gcdType = 'off',
        cooldown = 0,
        hostile = true,
        usable = function () return glyph.harsh_words.enabled end
      } )

    modifyAbility( 'harsh_word', 'spend', function ( x )
      return max( x, min( 3, holy_power.current ) )
    end )


    addAbility( 'holy_avenger',
      {
        id = 105809,
        spend = 0,
        cast = 0,
        gcdType = 'spell',
        cooldown = 120,
        passive = true,
        toggle = 'cooldowns'
      } )

    addHandler( 'holy_avenger', function ()
      applyBuff( 'holy_avenger', 18 )
    end )


    addAbility( 'holy_prism',
      {
        id = 114165,
        known = function() return talent.holy_prism.enabled end,
        spend = 0.17,
        cast = 0,
        gcdType = 'spell',
        cooldown = 20,
        hostile = true,
        toggle = 'tier90'
      } )

      
    addAbility( 'holy_wrath',
      {
        id = 119072,
        spend = 0.05,
        spend_type = 'mana',
        cast = 0,
        gcdType = 'spell',
        cooldown = 15
      } )

    modifyAbility( 'holy_wrath', 'cooldown', function( x )
      return x * haste
    end )


    addAbility( 'consecration',
      {
        id = 26573,
        known = 26573,
        spend = 0.07,
        spend_type = 'mana',
        cast = 0,
        gcdType = 'spell',
        cooldown = 9
      }, 116467, 159556 )

    modifyAbility( 'consecration', 'cooldown', function( x )
      return x * haste
    end )

    modifyAbility( 'consecration', 'id', function ( x )
      if glyph.consecration.enabled then return 116467
      elseif glyph.consecrator.enabled then return 159556 end
      return x
    end )


    addAbility( 'judgment',
      {
        id = 20271,
        spend = 0.12,
        cast = 0,
        gcdType = 'spell',
        cooldown = 6,
        hostile = true
      } )

    modifyAbility( 'judgment', 'cooldown', function( x )
      return x * haste
    end )

    addHandler( 'judgment', function ()
      gain( buff.holy_avenger.up and 3 or 1, 'holy_power' )
      if talent.empowered_seals.enabled then
        if seal.justice then applyBuff( 'turalyons_justice', 20 )
        elseif seal.insight then applyBuff( 'uthers_insight', 20 )
        elseif seal.righteousness then applyBuff( 'liadrins_righteousness', 20 )
        elseif seal.truth then applyBuff( 'maraads_truth', 20 )
        end
      end
    end )


    addAbility( 'lights_hammer',
      {
        id = 114158,
        known = function() return talent.lights_hammer.enabled end,
        spend = 0.519,
        cast = 0,
        gcdType = 'spell',
        cooldown = 60,
        hostile = true,
        toggle = 'tier90'
      } )


    addAbility( 'rebuke',
      {
        id = 96231,
        spend =  0.117,
        cast = 0,
        gcdType = 'off',
        cooldown = 15,
        hostile = true,
        toggle = 'interrupts',
        usable = function () return target.casting end
      } )

    addHandler( 'rebuke', function ()
      interrupt()
    end )


    addAbility( 'sacred_shield',
      {
        id = 20925,
        spend = 0,
        cast = 0,
        gcdType = 'spell',
        cooldown = 6,
        passive = true,
        friendly = true
      } )

    addHandler( 'sacred_shield', function ()
      applyBuff( 'sacred_shield', 30 )
    end )


    addAbility( 'seal_of_insight',
      {
        id = 20165,
        spend = 0,
        cast = 0,
        gcdType = 'totem',
        cooldown = 0,
        passive = true,
        usable = function() return not seal.insight end
      } )

    addHandler( 'seal_of_insight', function ()
      setStance( 'insight' )
    end )


    addAbility( 'seal_of_righteousness',
      {
        id = 20154,
        known = 105361,
        spend = 0,
        cast = 0,
        gcdType = 'totem',
        cooldown = 0,
        passive = true,
        usable = function() return not seal.righteousness end
      } )

    addHandler( 'seal_of_righteousness', function ()
      setStance( 'righteousness' )
    end )


    addAbility( 'seal_of_truth',
      {
        id = 31801,
        spend = 0,
        cast = 0,
        gcdType = 'totem',
        cooldown = 0,
        known = 105361,
        passive = true,
        usable = function() return not seal.truth end
      } )

    addHandler( 'seal_of_truth', function ()
      setStance( 'truth' )
    end )


    addAbility( 'seraphim',
      {
        id = 152262,
        known = function() return talent.seraphim.enabled end,
        spend = 5,
        spend_type = 'holy_power',
        cast = 0,
        gcdType = 'spell',
        passive = true,
        cooldown = 30,
      } )

    addHandler( 'seraphim', function ()
      applyBuff( 'seraphim', 15 )
    end )


    addAbility( 'templars_verdict',
      {
        id = 85256,
        spend = function()
          if buff.divine_purpose.up then return 0, 'holy_power' end
          return 3, 'holy_power'
        end,
        cast = 0,
        gcdType = 'spell',
        cooldown = 0,
        known = function() return not talent.final_verdict.enabled end,
        hostile = true
      } )

    addHandler( 'templars_verdict', function ()
      removeBuff( 'divine_purpose' )
    end )

    
    storeDefault( 'Ret: Precombat', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N70^SName^SRet:~`Precombat^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^S!aura.str_agi_int.up^SAbility^Sblessing_of_kings^SIndicator^Snone^SName^SBlessing~`of~`Kings^SRelease^N201506.221^t^N2^T^SEnabled^B^SScript^S!aura.mastery.up^SAbility^Sblessing_of_might^SIndicator^Snone^SName^SBlessing~`of~`Might^SRelease^N201506.221^t^N3^T^SEnabled^B^SScript^Sequipped.empty_drinking_horn&my_enemies<2^SAbility^Sseal_of_truth^SIndicator^Snone^SName^SSeal~`of~`Truth^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Sequipped.empty_drinking_horn&my_enemies>=2^SAbility^Sseal_of_righteousness^SIndicator^Snone^SName^SSeal~`of~`Righteousness^SRelease^N201506.221^t^N5^T^SEnabled^B^SScript^Smy_enemies<3&!equipped.empty_drinking_horn^SAbility^Sseal_of_truth^SIndicator^Snone^SName^SSeal~`of~`Truth~`(1)^SRelease^N201506.221^t^N6^T^SEnabled^B^SScript^Smy_enemies>=3&!equipped.empty_drinking_horn^SAbility^Sseal_of_righteousness^SIndicator^Snone^SName^SSeal~`of~`Righteousness~`(1)^SRelease^N201506.221^t^N7^T^SEnabled^B^SScript^Stoggle.cooldowns^SArgs^Sname=draenic_strength^SAbility^Spotion^SIndicator^Snone^SName^SPotion^SRelease^N201506.221^t^t^SDefault^B^t^^]] )

    storeDefault( 'Ret: Default', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N70^SName^SRet:~`Default^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Stoggle.interrupts^SAbility^Srebuke^SIndicator^Snone^SName^SRebuke^SRelease^N201506.221^t^N2^T^SEnabled^B^SScript^Stoggle.cooldowns&((buff.bloodlust.up|buff.avenging_wrath.up|target.time_to_die<=40))^SArgs^Sname=draenic_strength^SAbility^Spotion^SIndicator^Snone^SName^SPotion^SRelease^N201506.221^t^N3^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&time<2^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Sequipped.empty_drinking_horn&my_enemies<2&!talent.empowered_seals.enabled^SAbility^Sseal_of_truth^SIndicator^Snone^SName^SSeal~`of~`Truth^SRelease^N201506.221^t^N5^T^SEnabled^B^SScript^Sequipped.empty_drinking_horn&my_enemies>=2&!talent.empowered_seals.enabled^SAbility^Sseal_of_righteousness^SIndicator^Snone^SName^SSeal~`of~`Righteousness^SRelease^N201506.221^t^N6^T^SEnabled^B^SScript^Smy_enemies<3&!talent.empowered_seals.enabled&!equipped.empty_drinking_horn^SAbility^Sseal_of_truth^SIndicator^Snone^SName^SSeal~`of~`Truth~`(1)^SRelease^N201506.221^t^N7^T^SEnabled^B^SScript^Smy_enemies>=3&!talent.empowered_seals.enabled&!equipped.empty_drinking_horn^SAbility^Sseal_of_righteousness^SIndicator^Snone^SName^SSeal~`of~`Righteousness~`(1)^SRelease^N201506.221^t^N8^T^SEnabled^B^SScript^Stoggle.tier90&(!talent.seraphim.enabled)^SAbility^Sexecution_sentence^SIndicator^Snone^SName^SExecution~`Sentence^SRelease^N201506.221^t^N9^T^SEnabled^B^SScript^Stoggle.tier90&(action.seraphim.ready&(talent.seraphim.enabled))^SArgs^S^SAbility^Sexecution_sentence^SIndicator^Snone^SName^SExecution~`Sentence~`(1)^SRelease^N201506.221^t^N10^T^SEnabled^B^SScript^Stoggle.tier90&(!talent.seraphim.enabled)^SAbility^Slights_hammer^SIndicator^Snone^SName^SLight's~`Hammer^SRelease^N201506.221^t^N11^T^SEnabled^B^SScript^Stoggle.tier90&(action.seraphim.ready&(talent.seraphim.enabled))^SArgs^S^SAbility^Slights_hammer^SIndicator^Snone^SName^SLight's~`Hammer~`(1)^SRelease^N201506.221^t^N12^T^SEnabled^B^SScript^Stoggle.cooldowns&(action.seraphim.ready&(talent.seraphim.enabled))^SArgs^S^SAbility^Savenging_wrath^SIndicator^Snone^SName^SAvenging~`Wrath^SRelease^N201506.221^t^N13^T^SEnabled^B^SScript^Stoggle.cooldowns&(!talent.seraphim.enabled&set_bonus.tier18_4pc=0)^SAbility^Savenging_wrath^SIndicator^Snone^SName^SAvenging~`Wrath~`(1)^SRelease^N201506.221^t^N14^T^SEnabled^B^SScript^Stoggle.cooldowns&(!talent.seraphim.enabled&time<20&set_bonus.tier18_4pc=1)^SAbility^Savenging_wrath^SIndicator^Snone^SName^SAvenging~`Wrath~`(2)^SRelease^N201506.221^t^N15^T^SEnabled^B^SScript^Stoggle.cooldowns&(prev.execution_sentence&set_bonus.tier18_4pc=1&talent.execution_sentence.enabled&!talent.seraphim.enabled)^SAbility^Savenging_wrath^SIndicator^Snone^SName^SAvenging~`Wrath~`(3)^SRelease^N201506.221^t^N16^T^SEnabled^B^SScript^Stoggle.cooldowns&(prev.lights_hammer&set_bonus.tier18_4pc=1&talent.lights_hammer.enabled&!talent.seraphim.enabled)^SAbility^Savenging_wrath^SIndicator^Snone^SName^SAvenging~`Wrath~`(4)^SRelease^N201506.221^t^N17^T^SEnabled^B^SScript^Stoggle.cooldowns&(action.avenging_wrath.ready&(!talent.seraphim.enabled))^SArgs^S^SAbility^Sholy_avenger^SIndicator^Snone^SName^SHoly~`Avenger^SRelease^N201506.221^t^N18^T^SEnabled^B^SScript^Stoggle.cooldowns&(action.seraphim.ready&(talent.seraphim.enabled))^SArgs^S^SAbility^Sholy_avenger^SIndicator^Snone^SName^SHoly~`Avenger~`(1)^SRelease^N201506.221^t^N19^T^SEnabled^B^SScript^Stoggle.cooldowns&(holy_power.current<=2&!talent.seraphim.enabled)^SAbility^Sholy_avenger^SIndicator^Snone^SName^SHoly~`Avenger~`(2)^SRelease^N201506.221^t^N20^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sblood_fury^SIndicator^Snone^SName^SBlood~`Fury^SRelease^N201506.221^t^N21^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sberserking^SIndicator^Snone^SName^SBerserking^SRelease^N201506.221^t^N22^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sarcane_torrent^SIndicator^Snone^SName^SArcane~`Torrent^SRelease^N201506.221^t^N23^T^SEnabled^B^SName^SSeraphim^SAbility^Sseraphim^SIndicator^Snone^SRelease^N201506.221^t^N24^T^SEnabled^B^SScript^Stalent.seraphim.enabled&cooldown.seraphim.remains>0&cooldown.seraphim.remains<gcd&holy_power.current>=5^SArgs^Ssec=cooldown.seraphim.remains^SAbility^Swait^SIndicator^Snone^SName^SWait^SRelease^N201506.221^t^N25^T^SEnabled^B^SScript^Smy_enemies>=3^SArgs^Sname="Ret:~`Cleave"^SAbility^Scall_action_list^SIndicator^Snone^SName^SCall~`Action~`List^SRelease^N201506.221^t^N26^T^SEnabled^B^SName^SCall~`Action~`List~`(1)^SArgs^Sname="Ret:~`Single"^SAbility^Scall_action_list^SIndicator^Snone^SRelease^N201506.221^t^t^SDefault^B^t^^]] )

    storeDefault( 'Ret: Single', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N70^SName^SRet:~`Single^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&(holy_power.current=5|buff.holy_avenger.up&holy_power.current>=3)&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm^SRelease^N201506.221^t^N2^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&(holy_power.current=5|buff.holy_avenger.up&holy_power.current>=3)&my_enemies=2&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(1)^SRelease^N201506.221^t^N3^T^SEnabled^B^SScript^S(holy_power.current=5|buff.holy_avenger.up&holy_power.current>=3)&my_enemies=2&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(2)^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&(holy_power.current=5|buff.holy_avenger.up&holy_power.current>=3)&(talent.seraphim.enabled&cooldown.seraphim.remains<gcd*4)^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(3)^SRelease^N201506.221^t^N5^T^SEnabled^B^SScript^S(holy_power.current=5|buff.holy_avenger.up&holy_power.current>=3)&(buff.avenging_wrath.down|target.health.pct>35)&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*4)^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict^SRelease^N201506.221^t^N6^T^SEnabled^B^SScript^Sbuff.divine_purpose.up&buff.divine_purpose.remains<3^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict~`(1)^SRelease^N201506.221^t^N7^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&buff.divine_crusader.remains<3&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(4)^SRelease^N201506.221^t^N8^T^SEnabled^B^SScript^Sholy_power.current=5|buff.holy_avenger.up&holy_power.current>=3^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict^SRelease^N201506.221^t^N9^T^SEnabled^B^SScript^Sbuff.divine_purpose.up&buff.divine_purpose.remains<3^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(1)^SRelease^N201506.221^t^N10^T^SEnabled^B^SScript^St18_class_trinket=1&buff.focus_of_vengeance.remains<gcd*2^SAbility^Scrusader_strike^SIndicator^Snone^SName^SCrusader~`Strike^SRelease^N201506.221^t^N11^T^SEnabled^B^SName^SHammer~`of~`Wrath^SAbility^Shammer_of_wrath^SIndicator^Snone^SRelease^N201506.221^t^N12^T^SEnabled^B^SScript^Sbuff.blazing_contempt.up&holy_power.current<=2&buff.holy_avenger.down^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism^SRelease^N201506.221^t^N13^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&buff.final_verdict.up&(buff.avenging_wrath.up|target.health.pct<35)^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(5)^SRelease^N201506.221^t^N14^T^SEnabled^B^SScript^Smy_enemies=2&buff.final_verdict.up&(buff.avenging_wrath.up|target.health.pct<35)^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(6)^SRelease^N201506.221^t^N15^T^SEnabled^B^SScript^Sbuff.avenging_wrath.up|target.health.pct<35^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(2)^SRelease^N201506.221^t^N16^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&my_enemies=2&(buff.avenging_wrath.up|target.health.pct<35)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(7)^SRelease^N201506.221^t^N17^T^SEnabled^B^SScript^Sholy_power.current=5&(buff.avenging_wrath.up|target.health.pct<35)&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*3)^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict~`(2)^SRelease^N201506.221^t^N18^T^SEnabled^B^SScript^Sholy_power.current=4&(buff.avenging_wrath.up|target.health.pct<35)&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*4)^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict~`(3)^SRelease^N201506.221^t^N19^T^SEnabled^B^SScript^Sholy_power.current=3&(buff.avenging_wrath.up|target.health.pct<35)&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*5)^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict~`(4)^SRelease^N201506.221^t^N20^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&seal.truth&buff.maraads_truth.remains<cooldown.judgment.duration*1.5^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment^SRelease^N201506.221^t^N21^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&seal.righteousness&buff.liadrins_righteousness.remains<cooldown.judgment.duration*1.5^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(1)^SRelease^N201506.221^t^N22^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&buff.maraads_truth.remains<(cooldown.judgment.duration|buff.maraads_truth.down)&(buff.avenging_wrath.up|target.health.pct<35)&!buff.wings_of_liberty.up^SAbility^Sseal_of_truth^SIndicator^Snone^SName^SSeal~`of~`Truth^SRelease^N201506.221^t^N23^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&buff.liadrins_righteousness.remains<cooldown.judgment.duration&buff.maraads_truth.remains>cooldown.judgment.duration*1.5&target.health.pct<35&!buff.wings_of_liberty.up&!buff.bloodlust.up^SAbility^Sseal_of_righteousness^SIndicator^Snone^SName^SSeal~`of~`Righteousness^SRelease^N201506.221^t^N24^T^SEnabled^B^SScript^Stalent.seraphim.enabled^SAbility^Scrusader_strike^SIndicator^Snone^SName^SCrusader~`Strike~`(1)^SRelease^N201506.221^t^N25^T^SEnabled^B^SScript^Sholy_power.current<=3|(holy_power.current=4&target.health.pct>=35&buff.avenging_wrath.down)^SAbility^Scrusader_strike^SIndicator^Snone^SName^SCrusader~`Strike~`(2)^SRelease^N201506.221^t^N26^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&(buff.avenging_wrath.up|target.health.pct<35)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(8)^SRelease^N201506.221^t^N27^T^SEnabled^B^SScript^Sglyph.mass_exorcism.enabled&my_enemies>=2&!glyph.double_jeopardy.enabled&!set_bonus.tier17_4pc=1^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism~`(1)^SRelease^N201506.221^t^N28^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&talent.seraphim.enabled&glyph.double_jeopardy.enabled^SArgs^S^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(2)^SRelease^N201506.221^t^N29^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&talent.seraphim.enabled&glyph.double_jeopardy.enabled^SArgs^Scycle_targets=1^SAbility^Sjudgment^SIndicator^Scycle^SName^SJudgment~`(3)^SRelease^N201506.221^t^N30^T^SEnabled^B^SScript^Stalent.seraphim.enabled^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(4)^SRelease^N201506.221^t^N31^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&glyph.double_jeopardy.enabled&(holy_power.current<=3|(holy_power.current=4&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down))^SArgs^S^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(5)^SRelease^N201506.221^t^N32^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&glyph.double_jeopardy.enabled&(holy_power.current<=3|(holy_power.current=4&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down))^SArgs^Scycle_targets=1^SAbility^Sjudgment^SIndicator^Scycle^SName^SJudgment~`(6)^SRelease^N201506.221^t^N33^T^SEnabled^B^SScript^Sholy_power.current<=3|(holy_power.current=4&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down)^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(7)^SRelease^N201506.221^t^N34^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(9)^SRelease^N201506.221^t^N35^T^SEnabled^B^SScript^Smy_enemies=2&holy_power.current>=4&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(10)^SRelease^N201506.221^t^N36^T^SEnabled^B^SScript^Sbuff.divine_purpose.up^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(3)^SRelease^N201506.221^t^N37^T^SEnabled^B^SScript^Sholy_power.current>=4^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(4)^SRelease^N201506.221^t^N38^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&buff.maraads_truth.remains<cooldown.judgment.duration*1.5&buff.liadrins_righteousness.remains>cooldown.judgment.duration*1.5^SAbility^Sseal_of_truth^SIndicator^Snone^SName^SSeal~`of~`Truth~`(1)^SRelease^N201506.221^t^N39^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&buff.liadrins_righteousness.remains<cooldown.judgment.duration*1.5&buff.maraads_truth.remains>cooldown.judgment.duration*1.5&!buff.bloodlust.up^SAbility^Sseal_of_righteousness^SIndicator^Snone^SName^SSeal~`of~`Righteousness~`(1)^SRelease^N201506.221^t^N40^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&my_enemies=2&holy_power.current>=4&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(11)^SRelease^N201506.221^t^N41^T^SEnabled^B^SScript^Sbuff.divine_purpose.up^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict~`(5)^SRelease^N201506.221^t^N42^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(12)^SRelease^N201506.221^t^N43^T^SEnabled^B^SScript^Sholy_power.current>=4&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*5)^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict~`(6)^SRelease^N201506.221^t^N44^T^SEnabled^B^SScript^Stalent.seraphim.enabled^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism~`(2)^SRelease^N201506.221^t^N45^T^SEnabled^B^SScript^Sholy_power.current<=3|(holy_power.current=4&(cooldown.judgment.remains>=gcd*2&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down))^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism~`(3)^SRelease^N201506.221^t^N46^T^SEnabled^B^SScript^Smy_enemies=2&holy_power.current>=3&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(13)^SRelease^N201506.221^t^N47^T^SEnabled^B^SScript^Sholy_power.current>=3^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(5)^SRelease^N201506.221^t^N48^T^SEnabled^B^SScript^Sholy_power.current>=3&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*6)^SAbility^Stemplars_verdict^SIndicator^Snone^SName^STemplar's~`Verdict~`(7)^SRelease^N201506.221^t^N49^T^SEnabled^B^SScript^Stoggle.tier90^SAbility^Sholy_prism^SIndicator^Snone^SName^SHoly~`Prism^SRelease^N201506.221^t^t^SDefault^B^t^^]] )

    storeDefault( 'Ret: Cleave', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N70^SName^SRet:~`Cleave^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Sbuff.final_verdict.down&holy_power.current=5^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict^SRelease^N201506.221^t^N2^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&holy_power.current=5&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm^SRelease^N201506.221^t^N3^T^SEnabled^B^SScript^Sholy_power.current=5&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(1)^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&holy_power.current=5&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(2)^SRelease^N201506.221^t^N5^T^SEnabled^B^SScript^Sholy_power.current=5&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*4)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(3)^SRelease^N201506.221^t^N6^T^SEnabled^B^SName^SHammer~`of~`Wrath^SAbility^Shammer_of_wrath^SIndicator^Snone^SRelease^N201506.221^t^N7^T^SEnabled^B^SScript^St18_class_trinket=1&buff.focus_of_vengeance.remains<gcd*2^SAbility^Shammer_of_the_righteous^SIndicator^Snone^SName^SHammer~`of~`the~`Righteous^SRelease^N201506.221^t^N8^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&seal.righteousness&buff.liadrins_righteousness.remains<cooldown.judgment.duration^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment^SRelease^N201506.221^t^N9^T^SEnabled^B^SScript^Sbuff.blazing_contempt.up&holy_power.current<=2&buff.holy_avenger.down^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism^SRelease^N201506.221^t^N10^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&buff.final_verdict.up&(buff.avenging_wrath.up|target.health.pct<35)^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(4)^SRelease^N201506.221^t^N11^T^SEnabled^B^SScript^Sbuff.final_verdict.up&(buff.avenging_wrath.up|target.health.pct<35)^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(5)^SRelease^N201506.221^t^N12^T^SEnabled^B^SScript^Sbuff.final_verdict.down&(buff.avenging_wrath.up|target.health.pct<35)^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(1)^SRelease^N201506.221^t^N13^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&(buff.avenging_wrath.up|target.health.pct<35)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(6)^SRelease^N201506.221^t^N14^T^SEnabled^B^SScript^Sholy_power.current=5&(buff.avenging_wrath.up|target.health.pct<35)&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*3)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(7)^SRelease^N201506.221^t^N15^T^SEnabled^B^SScript^Sholy_power.current=4&(buff.avenging_wrath.up|target.health.pct<35)&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*4)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(8)^SRelease^N201506.221^t^N16^T^SEnabled^B^SScript^Sholy_power.current=3&(buff.avenging_wrath.up|target.health.pct<35)&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*5)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(9)^SRelease^N201506.221^t^N17^T^SEnabled^B^SScript^Smy_enemies>=4&talent.seraphim.enabled^SAbility^Shammer_of_the_righteous^SIndicator^Snone^SName^SHammer~`of~`the~`Righteous~`(1)^SRelease^N201506.221^t^N18^T^SEnabled^B^SScript^Smy_enemies>=4&(holy_power.current<=3|(holy_power.current=4&target.health.pct>=35&buff.avenging_wrath.down))^SArgs^S^SAbility^Shammer_of_the_righteous^SIndicator^Snone^SName^SHammer~`of~`the~`Righteous~`(2)^SRelease^N201506.221^t^N19^T^SEnabled^B^SScript^Stalent.seraphim.enabled^SAbility^Scrusader_strike^SIndicator^Snone^SName^SCrusader~`Strike^SRelease^N201506.221^t^N20^T^SEnabled^B^SScript^Sholy_power.current<=3|(holy_power.current=4&target.health.pct>=35&buff.avenging_wrath.down)^SAbility^Scrusader_strike^SIndicator^Snone^SName^SCrusader~`Strike~`(1)^SRelease^N201506.221^t^N21^T^SEnabled^B^SScript^Sglyph.mass_exorcism.enabled&!set_bonus.tier17_4pc=1^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism~`(1)^SRelease^N201506.221^t^N22^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&talent.seraphim.enabled&glyph.double_jeopardy.enabled^SArgs^S^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(1)^SRelease^N201506.221^t^N23^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&talent.seraphim.enabled&glyph.double_jeopardy.enabled^SArgs^Scycle_targets=1^SAbility^Sjudgment^SIndicator^Scycle^SName^SJudgment~`(2)^SRelease^N201506.221^t^N24^T^SEnabled^B^SScript^Stalent.seraphim.enabled^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(3)^SRelease^N201506.221^t^N25^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&glyph.double_jeopardy.enabled&(holy_power.current<=3|(holy_power.current=4&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down))^SArgs^S^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(4)^SRelease^N201506.221^t^N26^T^SEnabled^B^SScript^Slast_judgment_target!=target.unit&glyph.double_jeopardy.enabled&(holy_power.current<=3|(holy_power.current=4&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down))^SArgs^Scycle_targets=1^SAbility^Sjudgment^SIndicator^Scycle^SName^SJudgment~`(5)^SRelease^N201506.221^t^N27^T^SEnabled^B^SScript^Sholy_power.current<=3|(holy_power.current=4&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down)^SAbility^Sjudgment^SIndicator^Snone^SName^SJudgment~`(6)^SRelease^N201506.221^t^N28^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(10)^SRelease^N201506.221^t^N29^T^SEnabled^B^SScript^Sbuff.divine_purpose.up&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(11)^SRelease^N201506.221^t^N30^T^SEnabled^B^SScript^Sholy_power.current>=4&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(12)^SRelease^N201506.221^t^N31^T^SEnabled^B^SScript^Sbuff.divine_purpose.up&buff.final_verdict.down^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(2)^SRelease^N201506.221^t^N32^T^SEnabled^B^SScript^Sholy_power.current>=4&buff.final_verdict.down^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(3)^SRelease^N201506.221^t^N33^T^SEnabled^B^SScript^Sbuff.divine_crusader.up&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(13)^SRelease^N201506.221^t^N34^T^SEnabled^B^SScript^Sholy_power.current>=4&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*5)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(14)^SRelease^N201506.221^t^N35^T^SEnabled^B^SScript^Stalent.seraphim.enabled^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism~`(2)^SRelease^N201506.221^t^N36^T^SEnabled^B^SScript^Sholy_power.current<=3|(holy_power.current=4&(cooldown.judgment.remains>=gcd*2&cooldown.crusader_strike.remains>=gcd*2&target.health.pct>35&buff.avenging_wrath.down))^SAbility^Sexorcism^SIndicator^Snone^SName^SExorcism~`(3)^SRelease^N201506.221^t^N37^T^SEnabled^B^SScript^Sholy_power.current>=3&(!talent.seraphim.enabled|cooldown.seraphim.remains>gcd*6)&!talent.final_verdict.enabled^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(15)^SRelease^N201506.221^t^N38^T^SEnabled^B^SScript^Sholy_power.current>=3&buff.final_verdict.up^SAbility^Sdivine_storm^SIndicator^Snone^SName^SDivine~`Storm~`(16)^SRelease^N201506.221^t^N39^T^SEnabled^B^SScript^Sholy_power.current>=3&buff.final_verdict.down^SAbility^Sfinal_verdict^SIndicator^Snone^SName^SFinal~`Verdict~`(4)^SRelease^N201506.221^t^N40^T^SEnabled^B^SScript^Stoggle.tier90^SArgs^Starget=self^SAbility^Sholy_prism^SIndicator^Snone^SName^SHoly~`Prism^SRelease^N201506.221^t^t^SDefault^B^t^^]] )

    storeDefault( 'Prot: Max Survival', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N66^SDefault^B^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sblood_fury^SIndicator^Snone^SRelease^N201506.221^SName^SBlood~`Fury^t^N2^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sberserking^SIndicator^Snone^SRelease^N201506.221^SName^SBerserking^t^N3^T^SEnabled^B^SName^SArcane~`Torrent^SAbility^Sarcane_torrent^SIndicator^Snone^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sholy_avenger^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Avenger^t^N5^T^SEnabled^B^SScript^Stoggle.cooldowns&(buff.shield_of_the_righteous.down&buff.seraphim.down&buff.divine_protection.down&buff.guardian_of_ancient_kings.down&buff.ardent_defender.down)^SArgs^Sname=draenic_armor^SAbility^Spotion^SIndicator^Snone^SRelease^N201506.221^SName^SPotion^t^N6^T^SEnabled^B^SScript^Stoggle.mitigation&(time<5|!talent.seraphim.enabled|(buff.seraphim.down&cooldown.seraphim.remains>5&cooldown.seraphim.remains<9))^SAbility^Sdivine_protection^SIndicator^Snone^SRelease^N201506.221^SName^SDivine~`Protection^t^N7^T^SEnabled^B^SScript^Sbuff.divine_protection.down&cooldown.divine_protection.remains>0^SAbility^Sseraphim^SIndicator^Snone^SRelease^N201506.221^SName^SSeraphim^t^N8^T^SEnabled^B^SScript^Stoggle.mitigation&(buff.holy_avenger.down&buff.shield_of_the_righteous.down&buff.divine_protection.down)^SAbility^Sguardian_of_ancient_kings^SIndicator^Snone^SRelease^N201506.221^SName^SGuardian~`of~`Ancient~`Kings^t^N9^T^SEnabled^B^SScript^Stoggle.mitigation&(buff.holy_avenger.down&buff.shield_of_the_righteous.down&buff.divine_protection.down&buff.guardian_of_ancient_kings.down)^SAbility^Sardent_defender^SIndicator^Snone^SRelease^N201506.221^SName^SArdent~`Defender^t^N10^T^SEnabled^B^SScript^Sbuff.eternal_flame.remains<2&buff.bastion_of_glory.react>2&(holy_power.current>=3|buff.divine_purpose.up|buff.bastion_of_power.up)^SAbility^Seternal_flame^SIndicator^Snone^SRelease^N201506.221^SName^SEternal~`Flame^t^N11^T^SEnabled^B^SScript^Sbuff.bastion_of_power.up&buff.bastion_of_glory.react>=5^SAbility^Seternal_flame^SIndicator^Snone^SRelease^N201506.221^SName^SEternal~`Flame~`(1)^t^N12^T^SEnabled^B^SScript^Sbuff.divine_purpose.up^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous^t^N13^T^SEnabled^B^SScript^S(holy_power.current>=5|incoming_damage_1500ms>=health.max*0.3)&(!talent.seraphim.enabled|cooldown.seraphim.remains>5)^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous~`(1)^t^N14^T^SEnabled^B^SScript^Sbuff.holy_avenger.remains>time_to_hpg&(!talent.seraphim.enabled|cooldown.seraphim.remains>time_to_hpg)^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous~`(2)^t^N15^T^SEnabled^B^SScript^Smy_enemies>=3^SAbility^Shammer_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SHammer~`of~`the~`Righteous^t^N16^T^SEnabled^B^SName^SCrusader~`Strike^SAbility^Scrusader_strike^SIndicator^Snone^SRelease^N201506.221^t^N17^T^SEnabled^B^SScript^Scooldown.crusader_strike.remains>0&cooldown.crusader_strike.remains<=0.35^SArgs^Ssec=cooldown.crusader_strike.remains^SAbility^Swait^SIndicator^Snone^SRelease^N201506.221^SName^SWait^t^N18^T^SEnabled^B^SScript^Sglyph.double_jeopardy.enabled&last_judgment_target!=target.unit^SArgs^S^SAbility^Sjudgment^SIndicator^Snone^SRelease^N201506.221^SName^SJudgment^t^N19^T^SEnabled^B^SScript^Sglyph.double_jeopardy.enabled&last_judgment_target!=target.unit^SArgs^Scycle_targets=1^SAbility^Sjudgment^SIndicator^Scycle^SRelease^N201506.221^SName^SJudgment~`(1)^t^N20^T^SEnabled^B^SName^SJudgment~`(2)^SAbility^Sjudgment^SIndicator^Snone^SRelease^N201506.221^t^N21^T^SEnabled^B^SScript^Scooldown.judgment.remains>0&cooldown.judgment.remains<=0.35^SArgs^Ssec=cooldown.judgment.remains^SAbility^Swait^SIndicator^Snone^SRelease^N201506.221^SName^SWait~`(1)^t^N22^T^SEnabled^B^SScript^Sbuff.grand_crusader.up&my_enemies>1^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield^t^N23^T^SEnabled^B^SScript^Stalent.sanctified_wrath.enabled^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Wrath^t^N24^T^SEnabled^B^SScript^Sbuff.grand_crusader.up^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield~`(1)^t^N25^T^SEnabled^B^SScript^Starget.dot.sacred_shield.remains<2^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^SName^SSacred~`Shield^t^N26^T^SEnabled^B^SName^SAvenger's~`Shield~`(2)^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^t^N27^T^SEnabled^B^SScript^Stoggle.tier90^SAbility^Slights_hammer^SIndicator^Snone^SRelease^N201506.221^SName^SLight's~`Hammer^t^N28^T^SEnabled^B^SScript^Stoggle.tier90^SAbility^Sholy_prism^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Prism^t^N29^T^SEnabled^B^SScript^Starget.debuff.flying.down&my_enemies>=3^SAbility^Sconsecration^SIndicator^Snone^SRelease^N201506.221^SName^SConsecration^t^N30^T^SEnabled^B^SScript^Stoggle.tier90^SAbility^Sexecution_sentence^SIndicator^Snone^SRelease^N201506.221^SName^SExecution~`Sentence^t^N31^T^SEnabled^B^SScript^Stalent.selfless_healer.enabled&buff.selfless_healer.stack>=3^SAbility^Sflash_of_light^SIndicator^Snone^SRelease^N201506.221^SName^SFlash~`of~`Light^t^N32^T^SEnabled^B^SName^SHammer~`of~`Wrath^SAbility^Shammer_of_wrath^SIndicator^Snone^SRelease^N201506.221^t^N33^T^SEnabled^B^SScript^Starget.dot.sacred_shield.remains<8^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^SName^SSacred~`Shield~`(1)^t^N34^T^SEnabled^B^SScript^Sglyph.final_wrath.enabled&target.health.pct<=20^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Wrath~`(1)^t^N35^T^SEnabled^B^SScript^Starget.debuff.flying.down&!ticking^SAbility^Sconsecration^SIndicator^Snone^SRelease^N201506.221^SName^SConsecration~`(1)^t^N36^T^SEnabled^B^SName^SHoly~`Wrath~`(2)^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^t^N37^T^SEnabled^B^SName^SSacred~`Shield~`(2)^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^t^t^SName^SProt:~`Max~`Survival^t^^]] )

    storeDefault( 'Prot: Max Dps', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N66^SDefault^B^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sblood_fury^SIndicator^Snone^SRelease^N201506.221^SName^SBlood~`Fury^t^N2^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sberserking^SIndicator^Snone^SRelease^N201506.221^SName^SBerserking^t^N3^T^SEnabled^B^SName^SArcane~`Torrent^SAbility^Sarcane_torrent^SIndicator^Snone^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sholy_avenger^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Avenger^t^N5^T^SEnabled^B^SScript^Stoggle.cooldowns&(buff.holy_avenger.up|(!talent.holy_avenger.enabled&(buff.seraphim.up|(!talent.seraphim.enabled&buff.bloodlust.up)))|target.time_to_die<=20)^SArgs^Sname=draenic_armor^SAbility^Spotion^SIndicator^Snone^SRelease^N201506.221^SName^SPotion^t^N6^T^SEnabled^B^SName^SSeraphim^SAbility^Sseraphim^SIndicator^Snone^SRelease^N201506.221^t^N7^T^SEnabled^B^SScript^Sbuff.divine_purpose.up^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous^t^N8^T^SEnabled^B^SScript^S(holy_power.current>=5|talent.holy_avenger.enabled)&(!talent.seraphim.enabled|cooldown.seraphim.remains>5)^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous~`(1)^t^N9^T^SEnabled^B^SScript^Sbuff.holy_avenger.remains>time_to_hpg&(!talent.seraphim.enabled|cooldown.seraphim.remains>time_to_hpg)^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous~`(2)^t^N10^T^SEnabled^B^SScript^Sbuff.grand_crusader.up&my_enemies>1&!glyph.focused_shield.enabled^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield^t^N11^T^SEnabled^B^SScript^Stalent.sanctified_wrath.enabled&(buff.seraphim.up|(glyph.final_wrath.enabled&target.health.pct<=20))^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Wrath^t^N12^T^SEnabled^B^SScript^Smy_enemies>=3^SAbility^Shammer_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SHammer~`of~`the~`Righteous^t^N13^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&buff.liadrins_righteousness.down^SAbility^Sjudgment^SIndicator^Snone^SRelease^N201506.221^SName^SJudgment^t^N14^T^SEnabled^B^SName^SCrusader~`Strike^SAbility^Scrusader_strike^SIndicator^Snone^SRelease^N201506.221^t^N15^T^SEnabled^B^SScript^Scooldown.crusader_strike.remains>0&cooldown.crusader_strike.remains<=0.35^SArgs^Ssec=cooldown.crusader_strike.remains^SAbility^Swait^SIndicator^Snone^SRelease^N201506.221^SName^SWait^t^N16^T^SEnabled^B^SScript^Sglyph.double_jeopardy.enabled&last_judgment_target!=target.unit^SArgs^S^SAbility^Sjudgment^SIndicator^Snone^SRelease^N201506.221^SName^SJudgment~`(1)^t^N17^T^SEnabled^B^SScript^Sglyph.double_jeopardy.enabled&last_judgment_target!=target.unit^SArgs^Scycle_targets=1^SAbility^Sjudgment^SIndicator^Scycle^SRelease^N201506.221^SName^SJudgment~`(2)^t^N18^T^SEnabled^B^SName^SJudgment~`(3)^SAbility^Sjudgment^SIndicator^Snone^SRelease^N201506.221^t^N19^T^SEnabled^B^SScript^Scooldown.judgment.remains>0&cooldown.judgment.remains<=0.35^SArgs^Ssec=cooldown.judgment.remains^SAbility^Swait^SIndicator^Snone^SRelease^N201506.221^SName^SWait~`(1)^t^N20^T^SEnabled^B^SScript^Smy_enemies>1&!glyph.focused_shield.enabled^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield~`(1)^t^N21^T^SEnabled^B^SScript^Stalent.sanctified_wrath.enabled^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Wrath~`(1)^t^N22^T^SEnabled^B^SScript^Sbuff.grand_crusader.up^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield~`(2)^t^N23^T^SEnabled^B^SScript^Stoggle.tier90&(my_enemies<3)^SAbility^Sexecution_sentence^SIndicator^Snone^SRelease^N201506.221^SName^SExecution~`Sentence^t^N24^T^SEnabled^B^SScript^Sglyph.final_wrath.enabled&target.health.pct<=20^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Wrath~`(2)^t^N25^T^SEnabled^B^SName^SAvenger's~`Shield~`(3)^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^t^N26^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&!seal.righteousness^SAbility^Sseal_of_righteousness^SIndicator^Snone^SRelease^N201506.221^SName^SSeal~`of~`Righteousness^t^N27^T^SEnabled^B^SScript^Stoggle.tier90^SAbility^Slights_hammer^SIndicator^Snone^SRelease^N201506.221^SName^SLight's~`Hammer^t^N28^T^SEnabled^B^SScript^Stoggle.tier90^SAbility^Sholy_prism^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Prism^t^N29^T^SEnabled^B^SScript^Starget.debuff.flying.down&my_enemies>=3^SAbility^Sconsecration^SIndicator^Snone^SRelease^N201506.221^SName^SConsecration^t^N30^T^SEnabled^B^SScript^Stoggle.tier90^SAbility^Sexecution_sentence^SIndicator^Snone^SRelease^N201506.221^SName^SExecution~`Sentence~`(1)^t^N31^T^SEnabled^B^SName^SHammer~`of~`Wrath^SAbility^Shammer_of_wrath^SIndicator^Snone^SRelease^N201506.221^t^N32^T^SEnabled^B^SScript^Starget.debuff.flying.down^SAbility^Sconsecration^SIndicator^Snone^SRelease^N201506.221^SName^SConsecration~`(1)^t^N33^T^SEnabled^B^SName^SHoly~`Wrath~`(3)^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^t^N34^T^SEnabled^B^SName^SSacred~`Shield^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^t^N35^T^SEnabled^B^SScript^Stalent.selfless_healer.enabled&buff.selfless_healer.stack>=3^SAbility^Sflash_of_light^SIndicator^Snone^SRelease^N201506.221^SName^SFlash~`of~`Light^t^t^SName^SProt:~`Max~`Dps^t^^]] )

    storeDefault( 'Prot: Default', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N66^SDefault^B^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sblood_fury^SIndicator^Snone^SRelease^N201506.221^SName^SBlood~`Fury^t^N2^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sberserking^SIndicator^Snone^SRelease^N201506.221^SName^SBerserking^t^N3^T^SEnabled^B^SName^SArcane~`Torrent^SAbility^Sarcane_torrent^SIndicator^Snone^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Stoggle.cooldowns^SAbility^Sholy_avenger^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Avenger^t^N5^T^SEnabled^B^SScript^Stoggle.cooldowns&(buff.shield_of_the_righteous.down&buff.seraphim.down&buff.divine_protection.down&buff.guardian_of_ancient_kings.down&buff.ardent_defender.down)^SArgs^Sname=draenic_armor^SAbility^Spotion^SIndicator^Snone^SRelease^N201506.221^SName^SPotion^t^N6^T^SEnabled^B^SName^SSeraphim^SAbility^Sseraphim^SIndicator^Snone^SRelease^N201506.221^t^N7^T^SEnabled^B^SScript^Stoggle.mitigation&(time<5|!talent.seraphim.enabled|(buff.seraphim.down&cooldown.seraphim.remains>5&cooldown.seraphim.remains<9))^SAbility^Sdivine_protection^SIndicator^Snone^SRelease^N201506.221^SName^SDivine~`Protection^t^N8^T^SEnabled^B^SScript^Stoggle.mitigation&(time<5|(buff.holy_avenger.down&buff.shield_of_the_righteous.down&buff.divine_protection.down))^SAbility^Sguardian_of_ancient_kings^SIndicator^Snone^SRelease^N201506.221^SName^SGuardian~`of~`Ancient~`Kings^t^N9^T^SEnabled^B^SScript^Stoggle.mitigation&(time<5|(buff.holy_avenger.down&buff.shield_of_the_righteous.down&buff.divine_protection.down&buff.guardian_of_ancient_kings.down))^SAbility^Sardent_defender^SIndicator^Snone^SRelease^N201506.221^SName^SArdent~`Defender^t^N10^T^SEnabled^B^SScript^Sbuff.eternal_flame.remains<2&buff.bastion_of_glory.react>2&(holy_power.current>=3|buff.divine_purpose.up|buff.bastion_of_power.up)^SAbility^Seternal_flame^SIndicator^Snone^SRelease^N201506.221^SName^SEternal~`Flame^t^N11^T^SEnabled^B^SScript^Sbuff.bastion_of_power.up&buff.bastion_of_glory.react>=5^SAbility^Seternal_flame^SIndicator^Snone^SRelease^N201506.221^SName^SEternal~`Flame~`(1)^t^N12^T^SEnabled^B^SScript^Sbuff.divine_purpose.up^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous^t^N13^T^SEnabled^B^SScript^S(holy_power.current>=5|incoming_damage_1500ms>=health.max*0.3)&(!talent.seraphim.enabled|cooldown.seraphim.remains>5)^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous~`(1)^t^N14^T^SEnabled^B^SScript^Sbuff.holy_avenger.remains>time_to_hpg&(!talent.seraphim.enabled|cooldown.seraphim.remains>time_to_hpg)^SAbility^Sshield_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SShield~`of~`the~`Righteous~`(2)^t^N15^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&!seal.insight&buff.uthers_insight.remains<cooldown.judgment.remains^SAbility^Sseal_of_insight^SIndicator^Snone^SRelease^N201506.221^SName^SSeal~`of~`Insight^t^N16^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&!seal.righteousness&buff.uthers_insight.remains>cooldown.judgment.remains&buff.liadrins_righteousness.down^SAbility^Sseal_of_righteousness^SIndicator^Snone^SRelease^N201506.221^SName^SSeal~`of~`Righteousness^t^N17^T^SEnabled^B^SScript^Sbuff.grand_crusader.up&my_enemies>1&!glyph.focused_shield.enabled^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield^t^N18^T^SEnabled^B^SScript^Smy_enemies>=3^SAbility^Shammer_of_the_righteous^SIndicator^Snone^SRelease^N201506.221^SName^SHammer~`of~`the~`Righteous^t^N19^T^SEnabled^B^SName^SCrusader~`Strike^SAbility^Scrusader_strike^SIndicator^Snone^SRelease^N201506.221^t^N20^T^SEnabled^B^SScript^Scooldown.crusader_strike.remains>0&cooldown.crusader_strike.remains<=0.35^SArgs^Ssec=cooldown.crusader_strike.remains^SAbility^Swait^SIndicator^Snone^SRelease^N201506.221^SName^SWait^t^N21^T^SEnabled^B^SScript^Sglyph.double_jeopardy.enabled&last_judgment_target!=target.unit^SArgs^S^SAbility^Sjudgment^SIndicator^Snone^SRelease^N201506.221^SName^SJudgment^t^N22^T^SEnabled^B^SScript^Sglyph.double_jeopardy.enabled&last_judgment_target!=target.unit^SArgs^Scycle_targets=1^SAbility^Sjudgment^SIndicator^Scycle^SRelease^N201506.221^SName^SJudgment~`(1)^t^N23^T^SEnabled^B^SName^SJudgment~`(2)^SAbility^Sjudgment^SIndicator^Snone^SRelease^N201506.221^t^N24^T^SEnabled^B^SScript^Scooldown.judgment.remains>0&cooldown.judgment.remains<=0.35^SArgs^Ssec=cooldown.judgment.remains^SAbility^Swait^SIndicator^Snone^SRelease^N201506.221^SName^SWait~`(1)^t^N25^T^SEnabled^B^SScript^Smy_enemies>1&!glyph.focused_shield.enabled^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield~`(1)^t^N26^T^SEnabled^B^SScript^Stalent.sanctified_wrath.enabled^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Wrath^t^N27^T^SEnabled^B^SScript^Sbuff.grand_crusader.up^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^SName^SAvenger's~`Shield~`(2)^t^N28^T^SEnabled^B^SScript^Starget.dot.sacred_shield.remains<2^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^SName^SSacred~`Shield^t^N29^T^SEnabled^B^SScript^Sglyph.final_wrath.enabled&target.health.pct<=20^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Wrath~`(1)^t^N30^T^SEnabled^B^SName^SAvenger's~`Shield~`(3)^SAbility^Savengers_shield^SIndicator^Snone^SRelease^N201506.221^t^N31^T^SEnabled^B^SScript^Stoggle.tier90&(!talent.seraphim.enabled|buff.seraphim.remains>10|cooldown.seraphim.remains<6)^SAbility^Slights_hammer^SIndicator^Snone^SRelease^N201506.221^SName^SLight's~`Hammer^t^N32^T^SEnabled^B^SScript^Stoggle.tier90&(!talent.seraphim.enabled|buff.seraphim.up|cooldown.seraphim.remains>5|time<5)^SAbility^Sholy_prism^SIndicator^Snone^SRelease^N201506.221^SName^SHoly~`Prism^t^N33^T^SEnabled^B^SScript^Starget.debuff.flying.down&my_enemies>=3^SAbility^Sconsecration^SIndicator^Snone^SRelease^N201506.221^SName^SConsecration^t^N34^T^SEnabled^B^SScript^Stoggle.tier90&(!talent.seraphim.enabled|buff.seraphim.up|time<12)^SAbility^Sexecution_sentence^SIndicator^Snone^SRelease^N201506.221^SName^SExecution~`Sentence^t^N35^T^SEnabled^B^SName^SHammer~`of~`Wrath^SAbility^Shammer_of_wrath^SIndicator^Snone^SRelease^N201506.221^t^N36^T^SEnabled^B^SScript^Starget.dot.sacred_shield.remains<8^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^SName^SSacred~`Shield~`(1)^t^N37^T^SEnabled^B^SScript^Starget.debuff.flying.down^SAbility^Sconsecration^SIndicator^Snone^SRelease^N201506.221^SName^SConsecration~`(1)^t^N38^T^SEnabled^B^SName^SHoly~`Wrath~`(2)^SAbility^Sholy_wrath^SIndicator^Snone^SRelease^N201506.221^t^N39^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&!seal.insight&buff.uthers_insight.remains<=buff.liadrins_righteousness.remains^SAbility^Sseal_of_insight^SIndicator^Snone^SRelease^N201506.221^SName^SSeal~`of~`Insight~`(1)^t^N40^T^SEnabled^B^SScript^Stalent.empowered_seals.enabled&!seal.righteousness&buff.liadrins_righteousness.remains<=buff.uthers_insight.remains^SAbility^Sseal_of_righteousness^SIndicator^Snone^SRelease^N201506.221^SName^SSeal~`of~`Righteousness~`(1)^t^N41^T^SEnabled^B^SName^SSacred~`Shield~`(2)^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^t^N42^T^SEnabled^B^SScript^Stalent.selfless_healer.enabled&buff.selfless_healer.stack>=3^SAbility^Sflash_of_light^SIndicator^Snone^SRelease^N201506.221^SName^SFlash~`of~`Light^t^t^SName^SProt:~`Default^t^^]] )

    storeDefault( 'Prot: Precombat', 'actionLists', 20160203.1, [[^1^T^SEnabled^B^SSpecialization^N66^SDefault^B^SRelease^N20160203.1^SScript^S^SActions^T^N1^T^SEnabled^B^SScript^S(!aura.str_agi_int.up)&(aura.mastery.up)^SAbility^Sblessing_of_kings^SIndicator^Snone^SRelease^N201506.221^SName^SBlessing~`of~`Kings^t^N2^T^SEnabled^B^SScript^S!aura.mastery.up^SAbility^Sblessing_of_might^SIndicator^Snone^SRelease^N201506.221^SName^SBlessing~`of~`Might^t^N3^T^SEnabled^B^SName^SSeal~`of~`Insight^SAbility^Sseal_of_insight^SIndicator^Snone^SRelease^N201506.221^t^N4^T^SEnabled^B^SScript^Srole.attack|using_apl.max_dps^SAbility^Sseal_of_righteousness^SIndicator^Snone^SRelease^N201506.221^SName^SSeal~`of~`Righteousness^t^N5^T^SEnabled^B^SName^SSacred~`Shield^SAbility^Ssacred_shield^SIndicator^Snone^SRelease^N201506.221^t^N6^T^SEnabled^B^SScript^Stoggle.cooldowns^SArgs^Sname=draenic_armor^SAbility^Spotion^SIndicator^Snone^SRelease^N201506.221^SName^SPotion^t^t^SName^SProt:~`Precombat^t^^]] )


    storeDefault( 'Ret: Primary', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPrimary~`Font~`Size^N12^SPrimary~`Caption~`Aura^SCensure^Srel^SCENTER^SUse~`SpellFlash^b^SPvE~`-~`Target^b^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SRet:~`Precombat^SName^SRet:~`Precombat^SRelease^N201506.221^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SRet:~`Default^SName^SRet:~`Default^SRelease^N201506.221^t^t^SScript^S^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^F-4749890768863230^f-44^SAOE~`-~`Maximum^N0^SPrimary~`Caption^Sdebuff^SRange~`Checking^Sability^SAuto~`-~`Maximum^N0^SPvP~`-~`Target~`Alpha^N1^SSingle~`-~`Minimum^N0^SPvP~`-~`Default~`Alpha^N1^SPvE~`-~`Default~`Alpha^N1^SSpellFlash~`Color^T^Sa^N1^Sb^N1^Sg^N1^Sr^N1^t^SCopy~`To^SRetribution:~`AOE^SSpecialization^N70^SQueue~`Direction^SRIGHT^SPvP~`-~`Combat~`Alpha^N1^SQueued~`Icon~`Size^N40^SPvE~`-~`Combat~`Alpha^N1^SEnabled^B^SAuto~`-~`Minimum^N0^SPvE~`-~`Target~`Alpha^N1^SAOE~`-~`Minimum^N3^SSpacing^N5^SSingle~`-~`Maximum^N1^STalent~`Group^N0^SIcons~`Shown^N4^SName^SRet:~`Primary^SFont^SElvUI~`Font^SDefault^B^SPrimary~`Icon~`Size^N40^SPvP~`-~`Target^b^SRelease^N20160203.1^SAction~`Captions^B^Sx^N0^t^^]] )

    storeDefault( 'Ret: AOE', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPrimary~`Font~`Size^N12^SPrimary~`Caption~`Aura^S^Srel^SCENTER^SUse~`SpellFlash^b^SPvE~`-~`Target^b^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SRet:~`Precombat^SName^SRet:~`Precombat^SRelease^N201505.311^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SRet:~`Default^SName^SRet:~`Default^SRelease^N201505.311^t^t^SScript^S^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^N-225^SAOE~`-~`Maximum^N0^SPrimary~`Caption^Stargets^SRange~`Checking^Sability^SPvE~`-~`Combat~`Alpha^N1^SPrimary~`Icon~`Size^N40^SSingle~`-~`Minimum^N3^SRelease^N20160203.1^SAction~`Captions^B^SSpellFlash~`Color^T^Sa^N1^Sr^N1^Sg^N1^Sb^N1^t^SSpecialization^N70^Sx^N0^SQueue~`Direction^SRIGHT^SPvP~`-~`Target^b^SQueued~`Icon~`Size^N40^SPvP~`-~`Target~`Alpha^N1^SEnabled^B^SDefault^B^SFont^SElvUI~`Font^SAOE~`-~`Minimum^N3^SName^SRet:~`AOE^SIcons~`Shown^N4^STalent~`Group^N0^SSingle~`-~`Maximum^N0^SSpacing^N5^SPvE~`-~`Target~`Alpha^N1^SAuto~`-~`Minimum^N3^SAuto~`-~`Maximum^N0^SPvP~`-~`Combat~`Alpha^N1^SPvP~`-~`Default~`Alpha^N1^SPvE~`-~`Default~`Alpha^N1^SCopy~`To^SRetribution:~`AOE^t^^]] )

    storeDefault( 'Prot: Primary', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPvP~`-~`Target^b^SPrimary~`Caption~`Aura^S^Srel^SCENTER^SUse~`SpellFlash^b^SSpacing^N5^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SProt:~`Precombat^SName^SProt:~`Precombat^SRelease^N201506.221^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SProt:~`Default^SName^SProt:~`Default^SRelease^N201506.221^t^t^SScript^S^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^F-4749890768863230^f-44^SAOE~`-~`Maximum^N0^SRelease^N20160203.1^SRange~`Checking^Sability^SAuto~`-~`Maximum^N0^SPrimary~`Icon~`Size^N40^SSingle~`-~`Minimum^N0^Sx^N0^SAction~`Captions^B^SSpellFlash~`Color^T^Sa^N1^Sr^N1^Sg^N1^Sb^N1^t^SCopy~`To^SProt:~`AOE^SPvE~`-~`Target^b^SQueue~`Direction^SRIGHT^SPrimary~`Font~`Size^N12^SQueued~`Icon~`Size^N40^SPvP~`-~`Target~`Alpha^N1^SEnabled^B^SDefault^B^SFont^SArial~`Narrow^SAOE~`-~`Minimum^N3^SPrimary~`Caption^Stargets^SSpecialization^N66^SIcons~`Shown^N4^STalent~`Group^N0^SSingle~`-~`Maximum^N1^SPvE~`-~`Target~`Alpha^N1^SName^SProt:~`Primary^SPvE~`-~`Combat~`Alpha^N1^SPvP~`-~`Combat~`Alpha^N1^SAuto~`-~`Minimum^N0^SPvE~`-~`Default~`Alpha^N1^SPvP~`-~`Default~`Alpha^N1^t^^]] )

    storeDefault( 'Prot: AOE', 'displays', 20160203.1, [[^1^T^SQueued~`Font~`Size^N12^SPrimary~`Font~`Size^N12^SPrimary~`Caption~`Aura^S^Srel^SCENTER^SUse~`SpellFlash^b^SSpacing^N5^SPvE~`-~`Default^B^SPvE~`-~`Combat^b^SMaximum~`Time^N30^SQueues^T^N1^T^SEnabled^B^SAction~`List^SProt:~`Precombat^SName^SProt:~`Precombat^SRelease^N201506.051^SScript^Stime=0^t^N2^T^SEnabled^B^SAction~`List^SProt:~`Default^SName^SProt:~`Default^SRelease^N201506.051^t^t^SPvP~`-~`Default~`Alpha^N1^SPvP~`-~`Combat^b^SPvP~`-~`Default^B^Sy^N-225^SAOE~`-~`Maximum^N0^SRelease^N20160203.1^SRange~`Checking^Sability^SPvE~`-~`Combat~`Alpha^N1^SPrimary~`Icon~`Size^N40^SPvP~`-~`Combat~`Alpha^N1^SScript^S^SPvE~`-~`Default~`Alpha^N1^SSpellFlash~`Color^T^Sa^N1^Sb^N1^Sg^N1^Sr^N1^t^SCopy~`To^SProt:~`AOE^SSingle~`-~`Minimum^N3^SQueue~`Direction^SRIGHT^SAuto~`-~`Maximum^N0^SQueued~`Icon~`Size^N40^SAuto~`-~`Minimum^N3^SEnabled^B^SName^SProt:~`AOE^SPvE~`-~`Target~`Alpha^N1^SAOE~`-~`Minimum^N3^SSingle~`-~`Maximum^N0^STalent~`Group^N0^SIcons~`Shown^N4^SPvE~`-~`Target^b^SPrimary~`Caption^Stargets^SFont^SArial~`Narrow^SDefault^B^SPvP~`-~`Target~`Alpha^N1^SPvP~`-~`Target^b^Sx^N0^SAction~`Captions^B^SSpecialization^N66^t^^]] )


  end

end
