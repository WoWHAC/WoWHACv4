# [5.20.2](https://github.com/WeakAuras/WeakAuras2/tree/5.20.2) (2025-08-15)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/5.20.1...5.20.2)

## Highlights

bugfix release for some broken textures

## Commits

Pewtro (2):

- Re-export the .blp files
- Add Celestial Dungeon load option instance type

emptyrivers (1):

- some more difficulty ids

