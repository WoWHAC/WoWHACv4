# Hekili

## [v11.1.5-1.0.7](https://github.com/Hekili/hekili/tree/v11.1.5-1.0.7) (2025-05-03)
[Full Changelog](https://github.com/Hekili/hekili/compare/v11.1.5-1.0.6a...v11.1.5-1.0.7) [Previous Releases](https://github.com/Hekili/hekili/releases)

- Frost DK: DnD  
- Fire: Talent/Auras  
- Merge pull request #4835 from IIeTpoc/patch-7  
    Fix the Snapshot info on Roll the bones  
- Fix the Snapshot info on Roll the bones  
    Fix the Snapshot info on Roll the bones.  
    Old snapshot was not labling "normal", "shorter", "longer" appropriately  
- Add feature #4834  
