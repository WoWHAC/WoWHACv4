# LibRangeCheck-3.0

A library to determine estimated range in World of Warcraft
