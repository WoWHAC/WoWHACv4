# MaxDps_Monk

## [v8.3.0](https://github.com/kaminaris/MaxDps-Monk/tree/v8.3.0) (2020-08-25)
[Full Changelog](https://github.com/kaminaris/MaxDps-Monk/compare/v8.2.5...v8.3.0) [Previous Releases](https://github.com/kaminaris/MaxDps-Monk/releases)

- v8.3.0 - Interface version bump  
