local _, addonTable = ...;

--- @type MaxDps
if not MaxDps then return end

local MaxDps = MaxDps;
local Monk = addonTable.Monk;

function Monk:Mistweaver()
	return nil;
end