# MaxDps_DeathKnight

## [v8.3.0](https://github.com/kaminaris/MaxDps-DeathKnight/tree/v8.3.0) (2020-08-25)
[Full Changelog](https://github.com/kaminaris/MaxDps-DeathKnight/compare/v8.2.6...v8.3.0) [Previous Releases](https://github.com/kaminaris/MaxDps-DeathKnight/releases)

- v8.3.0 - Frostscythe update  
