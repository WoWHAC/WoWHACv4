# MaxDps_DemonHunter

## [v8.3.0](https://github.com/kaminaris/MaxDps-DemonHunter/tree/v8.3.0) (2020-02-25)
[Full Changelog](https://github.com/kaminaris/MaxDps-DemonHunter/compare/v8.2.5...v8.3.0)

- v8.3.0 - Vengeance fixes  
- Merge pull request #4 from Delsorou/patch-1  
    Fix spell not found bug, improve CD utilization  
- Fix spell not found bug, improve CD utilization  
    This fixes spell not found bug when using Concentrated Sigils and Charred Flesh at the same time, and improves short CD utilization in the normal rotation.  