# MaxDps_Hunter

## [v8.3.0.1](https://github.com/kaminaris/MaxDps-Hunter/tree/v8.3.0.1) (2020-08-25)
[Full Changelog](https://github.com/kaminaris/MaxDps-Hunter/compare/v8.3.0...v8.3.0.1) [Previous Releases](https://github.com/kaminaris/MaxDps-Hunter/releases)

- v8.3.0.1 - Small fix  
