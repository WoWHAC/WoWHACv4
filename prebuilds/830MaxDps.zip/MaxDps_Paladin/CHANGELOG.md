# MaxDps_Paladin

## [v8.3.0](https://github.com/kaminaris/MaxDps-Paladin/tree/v8.3.0) (2020-08-25)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/compare/v8.2.5...v8.3.0) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- v8.3.0 - HoW fix  
