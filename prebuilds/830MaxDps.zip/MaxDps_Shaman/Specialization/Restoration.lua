local _, addonTable = ...;

--- @type MaxDps
if not MaxDps then return end

local Shaman = addonTable.Shaman;

local RT = {
	FlameShock    = 188838,
	LightningBolt = 403,
};

function Shaman:Restoration()

end