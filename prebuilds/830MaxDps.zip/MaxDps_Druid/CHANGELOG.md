# MaxDps_Druid

## [v8.3.0.2](https://github.com/kaminaris/MaxDps-Druid/tree/v8.3.0.2) (2020-08-25)
[Full Changelog](https://github.com/kaminaris/MaxDps-Druid/compare/v8.3.0.1...v8.3.0.2) [Previous Releases](https://github.com/kaminaris/MaxDps-Druid/releases)

- v8.3.0.2 - Swipe fix  
