# MaxDps_Warrior

## [v11.1.4](https://github.com/kaminaris/MaxDps-Warrior/tree/v11.1.4) (2025-05-19)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warrior/compare/v11.1.3...v11.1.4) [Previous Releases](https://github.com/kaminaris/MaxDps-Warrior/releases)

- Update Fury  
- Update Arms  
- Update Prot  
