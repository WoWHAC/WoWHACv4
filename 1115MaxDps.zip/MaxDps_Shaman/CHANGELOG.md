# MaxDps_Shaman

## [v11.1.5](https://github.com/kaminaris/MaxDps-Shaman/tree/v11.1.5) (2025-06-17)
[Full Changelog](https://github.com/kaminaris/MaxDps-Shaman/compare/v11.1.4...v11.1.5) [Previous Releases](https://github.com/kaminaris/MaxDps-Shaman/releases)

- Update Retail Enhancement  
