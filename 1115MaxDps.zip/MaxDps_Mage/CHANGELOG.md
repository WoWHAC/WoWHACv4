# MaxDps_Mage

## [v11.1.15](https://github.com/kaminaris/MaxDps-Mage/tree/v11.1.15) (2025-06-07)
[Full Changelog](https://github.com/kaminaris/MaxDps-Mage/compare/v11.1.14...v11.1.15) [Previous Releases](https://github.com/kaminaris/MaxDps-Mage/releases)

- Update Classic Arcane  
