# MaxDps_Hunter

## [v11.1.7](https://github.com/kaminaris/MaxDps-Hunter/tree/v11.1.7) (2025-04-22)
[Full Changelog](https://github.com/kaminaris/MaxDps-Hunter/compare/v11.1.6...v11.1.7) [Previous Releases](https://github.com/kaminaris/MaxDps-Hunter/releases)

- Update TOC  
