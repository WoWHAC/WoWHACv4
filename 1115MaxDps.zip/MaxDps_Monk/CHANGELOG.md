# MaxDps_Monk

## [v11.1.1](https://github.com/kaminaris/MaxDps-Monk/tree/v11.1.1) (2025-04-22)
[Full Changelog](https://github.com/kaminaris/MaxDps-Monk/compare/v11.1.0...v11.1.1) [Previous Releases](https://github.com/kaminaris/MaxDps-Monk/releases)

- Update TOC  
