# MaxDps_DeathKnight

## [v11.1.40](https://github.com/kaminaris/MaxDps-DeathKnight/tree/v11.1.40) (2025-08-12)
[Full Changelog](https://github.com/kaminaris/MaxDps-DeathKnight/compare/v11.1.39...v11.1.40) [Previous Releases](https://github.com/kaminaris/MaxDps-DeathKnight/releases)

- Update Retail Frost  
